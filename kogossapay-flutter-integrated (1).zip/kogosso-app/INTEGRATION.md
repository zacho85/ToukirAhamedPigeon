# Intégration API – état d'avancement (20/11/2026)

Backend : https://sandbox-api.kongossapay.com (override : `--dart-define=API_URL=...`)
Les formes de réponse ont été vérifiées sur de vraies réponses du sandbox.

## Réel (branché sur l'API)
| Écran | Source |
|---|---|
| Connexion | POST /auth/login (envoie l'OTP) -> POST /auth/verify-otp (jeton + cookie refresh) |
| Session | refresh auto via cookie `refreshToken` (POST /auth/refresh-token), logout POST /auth/logout |
| Accueil | /auth/me (solde, nom), /tontines, POST /transactions/history |
| History | POST /transactions/history (50 dernières, groupées par jour) |
| E-Tontine | /tontines + /dashboard (stats) |
| Settings | /auth/me ; bouton Logout |

Devise affichée : XAF (l'ancien « $ » codé en dur est supprimé).
Montants : l'API mêle chaînes et nombres -> toujours `parseNum()` (lib/core/utils/formatters.dart).

## Ce qui n'existe pas côté API (donc retiré / masqué, pas inventé)
- Carte bancaire (numéro, expiration) -> la carte d'accueil montre le portefeuille.
- Téléphone et niveau KYC -> l'email est affiché, le niveau est masqué.
- Contacts « Quick pay » -> réservés aux agents ; seule la tuile « Add » reste.
- Cercles publics « Discover » -> section masquée.
- Bouton « Pay Contribution » -> masqué tant que le paiement n'est pas branché.
- Exchange / crypto -> retiré du produit.

## Encore factice (mock) – à brancher ensuite
send_money · receive_money · add_funds · payment_link · budget · contribute · project_details · portfolio · subscription
(subscription : l'API n'a pas de route de plans)

## Build
flutter pub get && flutter run
Android : flutter build appbundle --release   |   iOS : flutter build ipa (Mac + Xcode requis)
Contrôle automatique : `.github/workflows/build.yml` (onglet Actions de GitHub).
