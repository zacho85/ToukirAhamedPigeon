package com.kogosso.kogosso_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
