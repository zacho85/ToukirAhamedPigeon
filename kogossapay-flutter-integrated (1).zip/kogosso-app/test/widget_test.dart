import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';

import 'package:kogosso_app/main.dart';

void main() {
  testWidgets('Home screen renders app bar title', (WidgetTester tester) async {
    await tester.pumpWidget(const ProviderScope(child: KogossoApp()));
    await tester.pumpAndSettle();

    expect(find.text('KongossaPay'), findsOneWidget);
  });
}
