# KongossaPay — Setup & Run Instructions

This document explains how to get the project running on your own machine.

## 1. Requirements

Install these before doing anything else:

| Tool | Version used to build this project | Notes |
|---|---|---|
| Flutter SDK | 3.41.4 (stable channel) | Includes Dart automatically |
| Dart SDK | 3.11.1 | Bundled with the Flutter version above |
| Xcode | Latest, with an iOS Simulator | Only needed to run on iOS |
| Android Studio | Latest, with an Android emulator/SDK | Only needed to run on Android |
| A code editor | VS Code or Android Studio (recommended: VS Code with the Flutter extension) | |

Check your install:

```bash
flutter --version
```

If the Dart version reported is older than `3.11.1`, upgrade Flutter first (see step 2) — this project's dependencies (Riverpod 3.x with code generation) will not resolve on an older SDK.

## 2. Get the Flutter SDK (if not already installed)

Follow Flutter's official install guide for your OS: https://docs.flutter.dev/get-started/install

After installing, run:

```bash
flutter doctor
```

Resolve any ❌ items it reports (missing Xcode command-line tools, missing Android SDK licenses, etc.) before continuing.

## 3. Unzip / clone the project

Place the project folder anywhere on your machine, then open a terminal in it:

```bash
cd kogosso-app
```

## 4. Install dependencies

```bash
flutter pub get
```

## 5. Generate the Riverpod code (required — do this every time before running)

This project uses **Riverpod with code generation** for state management. The generated `*.g.dart` files are **not included** in the source (they're regenerated locally, kept out of version control). You must generate them once before the app will compile:

```bash
dart run build_runner build --delete-conflicting-outputs
```

You should see output ending with something like `Built with build_runner ... wrote 28 outputs.` If you later pull new changes or edit any file under `presentation/providers/`, re-run this command (or use the watcher below).

Optional — auto-regenerate while you're actively editing provider files:

```bash
dart run build_runner watch --delete-conflicting-outputs
```

## 6. Run the app

List available devices/simulators:

```bash
flutter devices
```

Then run:

```bash
flutter run
```

Or target a specific platform directly:

```bash
flutter run -d ios       # iOS Simulator
flutter run -d android   # Android emulator
flutter run -d chrome    # Web (Chrome)
flutter run -d macos     # macOS desktop
```

## 7. Building a release version

```bash
flutter build apk --release        # Android APK
flutter build appbundle --release  # Android App Bundle (for Play Store)
flutter build ios --release        # iOS (requires Xcode + signing setup)
flutter build web --release        # Web
```

## Project overview (for orientation)

- **Architecture**: Clean Architecture per feature — each feature under `lib/features/<name>/` has its own `domain/` (entities, repositories, usecases), `data/` (local data sources, repository implementations — currently all mock/local data, no backend wired up), and `presentation/` (Riverpod providers, screens, widgets) layers.
- **State management**: Riverpod 3.x with `riverpod_generator` (`@riverpod` annotated notifiers). Each feature's provider folder has `<feature>_status.dart` (enum), `<feature>_state.dart` (immutable state class), and `<feature>_provider.dart` (the notifier).
- **Navigation**: `go_router`, configured in `lib/core/router/`. Route paths are in `app_routes.dart`.
- **Design system**: shared colors, text styles, and icons under `lib/core/theme/`.

## Troubleshooting

- **"version solving failed" on `flutter pub get`**: your Flutter/Dart SDK is likely older than what's required. Run `flutter upgrade` and try again.
- **Build errors mentioning missing `.g.dart` files or `part 'xxx.g.dart'` not found**: you skipped step 5 — run the `build_runner build` command above.
- **`flutter doctor` shows issues you can't resolve**: those are usually platform-tooling issues (Xcode/Android SDK), not project issues — the Flutter docs linked in step 2 cover fixes per OS.
