import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  // Primary & Accent Palette
  static const Color primaryGreen = Color(0xFF006D43);
  static const Color primaryGreenLight = Color(0xFF56FBAB);
  static const Color darkNavy = Color(0xFF000B25);
  static const Color darkNavy2 = Color(0xFF0B2147);
  static const Color greyText = Color(0xFF44474E);
  static const Color errorRed = Color(0xFFBA1A1A);
  static const Color gold = Color(0xFF705D00);
  static const Color goldLight = Color(0xFFFFE16D);
  static const Color goldAccent = Color(0xFFC9A900);

  // Surfaces & Backgrounds
  static const Color surfaceWhite = Color(0xFFFFFFFF);
  static const Color background = Color(0xFFF7F9FB);
  static const Color borderGrey = Color(0xFFECEEF0);
  static const Color progressTrack = Color(0xFFE0E3E5);
  static const Color divider = Color(0x1AC5C6CF); // 10% opacity

  // Legacy mappings for backwards compatibility
  static const Color card = surfaceWhite;
  static const Color border = borderGrey;
  static const Color textPrimary = darkNavy;
  static const Color textSecondary = greyText;
  static const Color textMuted = greyText;
  static const Color textOnDark = surfaceWhite;
  static const Color textOnDarkMuted = Color(0xCCFFFFFF);
  static const Color success = primaryGreen;
  static const Color danger = errorRed;
  static const Color pending = gold;
  static const Color accentBlue = primaryGreen;
  static const Color accentOrange = gold;
  static const Color primaryGreenDark = primaryGreen;
  static const Color heroCard = darkNavy;
  static const Color heroCardAlt = darkNavy2;


  // Gradients
  static const LinearGradient balanceCardGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [darkNavy, darkNavy2],
  );

  static const LinearGradient heroCardGradient = balanceCardGradient;

  static const LinearGradient primaryCreditCardGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [primaryGreen, primaryGreenLight],
  );

  static const LinearGradient visaCardGradient = primaryCreditCardGradient;

  static const List<Color> avatarPalette = [
    Color(0xFF8C7BF6),
    Color(0xFF2FBF9F),
    Color(0xFFFF9F6B),
    Color(0xFF4C7EFF),
  ];
}

