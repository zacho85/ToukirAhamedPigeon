import 'package:flutter/material.dart';
import 'app_colors.dart';

class AppTextStyles {
  AppTextStyles._();

  // Typography Styles from Figma Design System

  static const TextStyle appTitle = TextStyle(
    fontFamily: 'PlusJakartaSans',
    fontWeight: FontWeight.w700,
    fontSize: 16,
    height: 24 / 16,
    color: AppColors.darkNavy,
  );

  static const TextStyle balanceAmount = TextStyle(
    fontFamily: 'PlusJakartaSans',
    fontWeight: FontWeight.w700,
    fontSize: 48,
    height: 56 / 48,
    letterSpacing: -0.96,
    color: Colors.white,
  );

  static const TextStyle sectionHeading = TextStyle(
    fontFamily: 'PlusJakartaSans',
    fontWeight: FontWeight.w600,
    fontSize: 20,
    height: 28 / 20,
    color: AppColors.darkNavy,
  );

  static const TextStyle transactionTitle = TextStyle(
    fontFamily: 'PlusJakartaSans',
    fontWeight: FontWeight.w600,
    fontSize: 16,
    height: 24 / 16,
    color: AppColors.darkNavy,
  );

  static const TextStyle transactionAmount = TextStyle(
    fontFamily: 'PlusJakartaSans',
    fontWeight: FontWeight.w700,
    fontSize: 16,
    height: 24 / 16,
  );

  static const TextStyle cardLabel = TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
    fontSize: 14,
    height: 20 / 14,
    letterSpacing: 0.35,
    color: Colors.white,
  );

  static const TextStyle quickActionLabel = TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
    fontSize: 14,
    height: 20 / 14,
    letterSpacing: 0.14,
    color: AppColors.greyText,
  );

  static const TextStyle badge = TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w600,
    fontSize: 12,
    height: 16 / 12,
    letterSpacing: 0.3,
  );

  static const TextStyle navLabel = TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w600,
    fontSize: 12,
    height: 16 / 12,
  );

  static const TextStyle smallLabel = TextStyle(
    fontFamily: 'PlusJakartaSans',
    fontWeight: FontWeight.w400,
    fontSize: 10,
    height: 15 / 10,
    color: Colors.white,
  );

  static const TextStyle cardNumber = TextStyle(
    fontFamily: 'LiberationMono',
    fontWeight: FontWeight.w400,
    fontSize: 14,
    height: 20 / 14,
    letterSpacing: 2.8,
    color: Colors.white,
  );

  static const TextStyle cardMeta = TextStyle(
    fontFamily: 'PlusJakartaSans',
    fontWeight: FontWeight.w400,
    fontSize: 8,
    height: 12 / 8,
    color: Colors.white,
  );

  static const TextStyle cardHolderName = TextStyle(
    fontFamily: 'PlusJakartaSans',
    fontWeight: FontWeight.w600,
    fontSize: 12,
    height: 18 / 12,
    color: Colors.white,
  );

  // Legacy mappings for backwards compatibility
  static const TextStyle h1 = balanceAmount;
  static const TextStyle h2 = sectionHeading;
  static const TextStyle body = transactionTitle;
  static const TextStyle bodySecondary = quickActionLabel;
  static const TextStyle caption = badge;
  static const TextStyle label = cardLabel;

  static const TextStyle h1OnDark = balanceAmount;
  static const TextStyle bodyOnDark = cardLabel;
  static const TextStyle captionOnDark = smallLabel;
  static const TextStyle labelOnDark = cardLabel;
}

