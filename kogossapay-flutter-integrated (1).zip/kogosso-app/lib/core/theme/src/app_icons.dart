class AppIcons {
  AppIcons._();

  static const String _icons = 'assets/icons';

  static const String eye = '$_icons/eye.svg';
  static const String add = '$_icons/add.svg';
  static const String arrowRight = '$_icons/arrow-right.svg';
  static const String deposit = '$_icons/deposit.svg';
  static const String eTontine = '$_icons/e-tontine.svg';
  static const String exchange = '$_icons/exchange.svg';
  static const String history = '$_icons/history.svg';
  static const String home = '$_icons/home.svg';
  static const String logout = '$_icons/logout.svg';
  static const String logoutAlt = '$_icons/logout-1.svg';
  static const String purchase = '$_icons/purchase.svg';
  static const String qrPay = '$_icons/qr-pay.svg';
  static const String receive = '$_icons/receive.svg';
  static const String reward = '$_icons/reward.svg';
  static const String salary = '$_icons/salary.svg';
  static const String security = '$_icons/security.svg';
  static const String send = '$_icons/send.svg';
  static const String settings = '$_icons/settings.svg';
  static const String user = '$_icons/user.svg';
  static const String verification = '$_icons/verification.svg';
  static const String verified = '$_icons/verified.svg';
  static const String withdraw = '$_icons/withdraw.svg';
}
