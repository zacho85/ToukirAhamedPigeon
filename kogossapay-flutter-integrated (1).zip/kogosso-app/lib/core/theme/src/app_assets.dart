class AppAssets {
  AppAssets._();

  static const String _images = 'assets/images';
  static const String user = '$_images/user.jpg';
}