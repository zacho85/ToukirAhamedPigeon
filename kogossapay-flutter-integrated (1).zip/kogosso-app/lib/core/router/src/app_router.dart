import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/features/auth/presentation/presentation.dart';
import 'package:kogosso_app/features/add_funds/presentation/presentation.dart';
import 'package:kogosso_app/features/budget/presentation/presentation.dart';
import 'package:kogosso_app/features/contribute/presentation/presentation.dart';
import 'package:kogosso_app/features/history/presentation/presentation.dart';
import 'package:kogosso_app/features/home/presentation/presentation.dart';
import 'package:kogosso_app/features/payment_link/presentation/presentation.dart';
import 'package:kogosso_app/features/portfolio/presentation/presentation.dart';
import 'package:kogosso_app/features/project_details/presentation/presentation.dart';
import 'package:kogosso_app/features/receive_money/presentation/presentation.dart';
import 'package:kogosso_app/features/send_money/presentation/presentation.dart';
import 'package:kogosso_app/features/settings/presentation/presentation.dart';
import 'package:kogosso_app/features/subscription/presentation/presentation.dart';
import 'package:kogosso_app/features/tontine/presentation/presentation.dart';

import 'app_routes.dart';
import 'scaffold_with_nav_bar.dart';

final GlobalKey<NavigatorState> rootNavigatorKey = GlobalKey<NavigatorState>();

/// App-wide [GoRouter] configuration.
///
/// The five bottom-nav tabs live inside a [StatefulShellRoute] so each tab
/// keeps its own scroll/nav state. Detail screens (Portfolio, Send Money,
/// Contribute, ...) are declared as top-level routes with
/// `parentNavigatorKey: rootNavigatorKey` so they push full-screen above the
/// shell, hiding the bottom nav bar.
final routerProvider = Provider<GoRouter>((ref) {
  final refresh = ValueNotifier<int>(0);
  ref.listen(authProvider, (_, __) => refresh.value++);
  ref.onDispose(refresh.dispose);

  return GoRouter(
  navigatorKey: rootNavigatorKey,
  initialLocation: AppRoutes.home,
  refreshListenable: refresh,
  redirect: (context, state) {
    final status = ref.read(authProvider).status;
    final loc = state.matchedLocation;
    switch (status) {
      case AuthStatus.unknown:
        return null; // restauration de session en cours
      case AuthStatus.unauthenticated:
        return loc == AppRoutes.login ? null : AppRoutes.login;
      case AuthStatus.awaitingOtp:
        return loc == AppRoutes.otp ? null : AppRoutes.otp;
      case AuthStatus.authenticated:
        return (loc == AppRoutes.login || loc == AppRoutes.otp) ? AppRoutes.home : null;
    }
  },
  routes: [
    GoRoute(path: AppRoutes.login, builder: (context, state) => const LoginScreen()),
    GoRoute(path: AppRoutes.otp, builder: (context, state) => const OtpScreen()),
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) => ScaffoldWithNavBar(navigationShell: navigationShell),
      branches: [
        StatefulShellBranch(
          routes: [GoRoute(path: AppRoutes.home, builder: (context, state) => const HomeScreen())],
        ),
        StatefulShellBranch(
          routes: [GoRoute(path: AppRoutes.history, builder: (context, state) => const HistoryScreen())],
        ),
        StatefulShellBranch(
          routes: [GoRoute(path: AppRoutes.tontine, builder: (context, state) => const TontineScreen())],
        ),
        StatefulShellBranch(
          routes: [GoRoute(path: AppRoutes.settings, builder: (context, state) => const SettingsScreen())],
        ),
      ],
    ),
    GoRoute(
      path: AppRoutes.portfolio,
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const PortfolioScreen(),
    ),
    GoRoute(
      path: AppRoutes.sendMoney,
      parentNavigatorKey: rootNavigatorKey,
      pageBuilder: (context, state) => const MaterialPage(fullscreenDialog: true, child: SendMoneyScreen()),
    ),
    GoRoute(
      path: AppRoutes.receiveMoney,
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const ReceiveMoneyScreen(),
    ),
    GoRoute(
      path: AppRoutes.addFunds,
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const AddFundsScreen(),
    ),
    GoRoute(
      path: AppRoutes.paymentLink,
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const PaymentLinkScreen(),
    ),
    GoRoute(path: AppRoutes.budget, parentNavigatorKey: rootNavigatorKey, builder: (context, state) => const BudgetScreen()),
    GoRoute(
      path: AppRoutes.subscription,
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const SubscriptionScreen(),
    ),
    GoRoute(
      path: AppRoutes.contribute,
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) {
        final args = state.extra as ContributeRouteArgs;
        return ContributeScreen(
          circleTitle: args.circleTitle,
          badgeLabel: args.badgeLabel,
          progress: args.progress,
          progressLabel: args.progressLabel,
          scheduledAmount: args.scheduledAmount,
        );
      },
    ),
    GoRoute(
      path: AppRoutes.projectDetails,
      parentNavigatorKey: rootNavigatorKey,
      builder: (context, state) => const ProjectDetailsScreen(),
    ),
  ],
  );
});
