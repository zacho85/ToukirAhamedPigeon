/// Centralized route path constants for [AppRouter].
class AppRoutes {
  AppRoutes._();

  // Auth
  static const String login = '/login';
  static const String otp = '/otp';

  // Bottom-nav tabs
  static const String home = '/home';
  static const String history = '/history';
  static const String tontine = '/tontine';
  static const String settings = '/settings';

  // Full-screen routes pushed above the tab shell
  static const String portfolio = '/portfolio';
  static const String sendMoney = '/send-money';
  static const String receiveMoney = '/receive-money';
  static const String addFunds = '/add-funds';
  static const String paymentLink = '/payment-link';
  static const String budget = '/budget';
  static const String subscription = '/subscription';
  static const String contribute = '/contribute';
  static const String projectDetails = '/project-details';
}
