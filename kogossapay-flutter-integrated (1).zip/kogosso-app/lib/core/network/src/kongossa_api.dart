import 'package:dio/dio.dart';

/// Appels de lecture partagés par plusieurs écrans (formes vérifiées sur le
/// sandbox le 20/11/2026).
class KongossaApi {
  KongossaApi(this._dio);
  final Dio _dio;

  /// GET /auth/me -> {id, email, fullName, walletBalance, profileImage, currency, rewardsPoints}
  Future<Map<String, dynamic>> me() async => _map((await _dio.get('/auth/me')).data);

  /// GET /dashboard -> {budgets{}, tontines{total,active,totalContributed,totalReceived,pendingInvites}, ...}
  Future<Map<String, dynamic>> dashboard() async => _map((await _dio.get('/dashboard')).data);

  /// GET /tontines -> {data:[...], current_page, last_page, per_page, total}
  Future<List<Map<String, dynamic>>> tontines() async {
    final d = (await _dio.get('/tontines')).data;
    return _list(d is Map ? d['data'] : d);
  }

  /// POST /transactions/history -> {data:[...], meta{total,page,limit,totalPages}}
  Future<List<Map<String, dynamic>>> transactions({int page = 1, int limit = 20}) async {
    final d = (await _dio.post('/transactions/history', data: {'page': page, 'limit': limit})).data;
    return _list(d is Map ? d['data'] : d);
  }

  static Map<String, dynamic> _map(dynamic d) => d is Map ? Map<String, dynamic>.from(d) : <String, dynamic>{};

  static List<Map<String, dynamic>> _list(dynamic d) =>
      d is List ? [for (final e in d) if (e is Map) Map<String, dynamic>.from(e)] : const [];
}
