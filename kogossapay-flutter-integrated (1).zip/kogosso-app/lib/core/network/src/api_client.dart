import 'dart:async';

import 'package:dio/dio.dart';

import 'api_config.dart';
import 'token_storage.dart';

/// Client HTTP unique de l'application.
///
/// - Ajoute `Authorization: Bearer <token>` automatiquement.
/// - Sur un 401, tente UN refresh (`POST /auth/refresh-token`) puis rejoue la
///   requête ; si le refresh échoue, vide la session et notifie [onSessionExpired].
class ApiClient {
  ApiClient({required this.tokens, this.onSessionExpired})
      : dio = Dio(
          BaseOptions(
            baseUrl: ApiConfig.baseUrl,
            connectTimeout: ApiConfig.connectTimeout,
            receiveTimeout: ApiConfig.receiveTimeout,
            contentType: Headers.jsonContentType,
            headers: {'Accept': 'application/json'},
          ),
        ) {
    dio.interceptors.add(
      QueuedInterceptorsWrapper(onRequest: _onRequest, onError: _onError),
    );
  }

  final Dio dio;
  final TokenStorage tokens;
  final void Function()? onSessionExpired;

  static const _noAuthPaths = <String>{
    '/auth/login',
    '/auth/register',
    '/auth/send-otp',
    '/auth/resend-otp',
    '/auth/verify-otp',
    '/auth/forgot-password',
    '/auth/reset-password',
    '/auth/refresh-token',
  };

  Future<void> _onRequest(RequestOptions o, RequestInterceptorHandler h) async {
    if (!_noAuthPaths.contains(o.path)) {
      final t = await tokens.readAccess();
      if (t != null) o.headers['Authorization'] = 'Bearer $t';
    }
    h.next(o);
  }

  Future<void> _onError(DioException e, ErrorInterceptorHandler h) async {
    final req = e.requestOptions;
    final retried = req.extra['retried'] == true;
    if (e.response?.statusCode != 401 || retried || _noAuthPaths.contains(req.path)) {
      return h.next(e);
    }
    final ok = await _refresh();
    if (!ok) {
      await tokens.clear();
      onSessionExpired?.call();
      return h.next(e);
    }
    try {
      req.extra['retried'] = true;
      req.headers['Authorization'] = 'Bearer ${await tokens.readAccess()}';
      h.resolve(await dio.fetch(req));
    } on DioException catch (err) {
      h.next(err);
    }
  }

  Future<bool> _refresh() async {
    final refresh = await tokens.readRefresh();
    if (refresh == null) return false;
    try {
      // Client "nu" pour éviter de repasser dans l'intercepteur.
      final bare = Dio(BaseOptions(baseUrl: ApiConfig.baseUrl, connectTimeout: ApiConfig.connectTimeout));
      // Le refresh token voyage dans un cookie httpOnly, pas dans le corps.
      final res = await bare.post(
        '/auth/refresh-token',
        data: const <String, dynamic>{},
        options: Options(headers: {'Cookie': 'refreshToken=$refresh'}),
      );
      final pair = TokenPair.fromJson(res.data);
      if (pair == null) return false;
      await tokens.save(access: pair.access, refresh: refreshCookieFrom(res.headers) ?? refresh);
      return true;
    } catch (_) {
      return false;
    }
  }

  /// Extrait la valeur du cookie `refreshToken` d'une réponse (en-tête Set-Cookie).
  static String? refreshCookieFrom(Headers headers) {
    for (final c in headers.map['set-cookie'] ?? const <String>[]) {
      final m = RegExp(r'(?:^|[\s;])refreshToken=([^;]+)').firstMatch(c);
      if (m != null) return m.group(1);
    }
    return null;
  }
}

/// Jeton d'accès renvoyé par l'API (`accessToken` dans le corps ; le refresh
/// token arrive séparément par cookie).
class TokenPair {
  final String access;
  final String? refresh;
  const TokenPair(this.access, this.refresh);

  static TokenPair? fromJson(dynamic json) {
    if (json is! Map) return null;
    Map src = json;
    if (json['data'] is Map) src = json['data'] as Map;
    String? pick(List<String> keys) {
      for (final k in keys) {
        final v = src[k];
        if (v is String && v.isNotEmpty) return v;
      }
      return null;
    }

    final access = pick(['accessToken', 'access_token', 'token']);
    if (access == null) return null;
    return TokenPair(access, pick(['refreshToken', 'refresh_token']));
  }
}
