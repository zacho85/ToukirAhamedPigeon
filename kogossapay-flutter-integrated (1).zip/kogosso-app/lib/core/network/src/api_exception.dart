import 'package:dio/dio.dart';

/// Erreur applicative lisible par l'UI (message déjà prêt à afficher).
class ApiException implements Exception {
  final String message;
  final int? statusCode;

  const ApiException(this.message, {this.statusCode});

  bool get isUnauthorized => statusCode == 401;

  factory ApiException.from(Object error) {
    if (error is ApiException) return error;
    if (error is DioException) {
      final code = error.response?.statusCode;
      final data = error.response?.data;
      String? msg;
      if (data is Map) {
        final m = data['message'] ?? data['error'];
        msg = m is List ? m.join('\n') : m?.toString();
      }
      if (msg == null || msg.isEmpty) {
        switch (error.type) {
          case DioExceptionType.connectionTimeout:
          case DioExceptionType.receiveTimeout:
          case DioExceptionType.sendTimeout:
            msg = 'Le serveur met trop de temps à répondre. Réessayez.';
          case DioExceptionType.connectionError:
            msg = 'Pas de connexion internet.';
          default:
            msg = 'Une erreur est survenue. Réessayez.';
        }
      }
      return ApiException(msg, statusCode: code);
    }
    return const ApiException('Une erreur est survenue. Réessayez.');
  }

  @override
  String toString() => message;
}
