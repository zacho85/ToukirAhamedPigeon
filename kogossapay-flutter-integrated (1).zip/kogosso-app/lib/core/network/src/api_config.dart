/// Configuration de l'API, surchargeable au build :
/// `flutter run --dart-define=API_URL=https://sandbox-api.kongossapay.com`
class ApiConfig {
  ApiConfig._();

  static const String baseUrl = String.fromEnvironment(
    'API_URL',
    defaultValue: 'https://sandbox-api.kongossapay.com',
  );

  static const Duration connectTimeout = Duration(seconds: 15);
  static const Duration receiveTimeout = Duration(seconds: 30);
}
