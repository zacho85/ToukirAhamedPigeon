/// Conversions et formats partagés. L'API renvoie parfois les montants en
/// chaîne ("10000") et parfois en nombre (10000) : toujours passer par [parseNum].
num parseNum(dynamic v, [num fallback = 0]) {
  if (v is num) return v;
  if (v is String) return num.tryParse(v) ?? fallback;
  return fallback;
}

DateTime? parseDate(dynamic v) => v is String ? DateTime.tryParse(v)?.toLocal() : null;

/// 75000 -> "75 000 XAF" (espace fine insécable entre les milliers).
String formatXaf(num v) {
  final s = v.abs().round().toString();
  final b = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) b.write('\u202F');
    b.write(s[i]);
  }
  return '${v < 0 ? '-' : ''}$b XAF';
}

const _months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

String formatTime(DateTime d) {
  final h = d.hour % 12 == 0 ? 12 : d.hour % 12;
  final m = d.minute.toString().padLeft(2, '0');
  return '$h:$m ${d.hour < 12 ? 'AM' : 'PM'}';
}

bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

String _short(DateTime d, DateTime now) =>
    '${_months[d.month - 1]} ${d.day}${d.year == now.year ? '' : ', ${d.year}'}';

/// "Today • 2:45 PM", "Yesterday • 10:15 AM", "Aug 23 • 4:43 AM".
String formatWhen(DateTime d, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final day = _sameDay(d, n)
      ? 'Today'
      : _sameDay(d, n.subtract(const Duration(days: 1)))
          ? 'Yesterday'
          : _short(d, n);
  return '$day • ${formatTime(d)}';
}

/// "TODAY, NOV 20", "YESTERDAY, NOV 19", "AUG 23".
String formatDayLabel(DateTime d, {DateTime? now}) {
  final n = now ?? DateTime.now();
  final s = _short(d, n).toUpperCase();
  if (_sameDay(d, n)) return 'TODAY, $s';
  if (_sameDay(d, n.subtract(const Duration(days: 1)))) return 'YESTERDAY, $s';
  return s;
}
