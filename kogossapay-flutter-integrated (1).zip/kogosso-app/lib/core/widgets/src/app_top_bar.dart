import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/src/app_assets.dart';

import '../../theme/src/app_colors.dart';
import '../../theme/src/app_text_styles.dart';

class AppTopBar extends StatelessWidget {
  const AppTopBar({super.key});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
          decoration: BoxDecoration(
            color: AppColors.background.withValues(alpha: 0.7),
            border: .all(color: Color(0xffC5C6CF).withValues(alpha: 0.2)),
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 2, offset: const Offset(0, 1))],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.borderGrey,
                      boxShadow: [
                        BoxShadow(color: Colors.black.withValues(alpha: 0.05), offset: const Offset(0, 1), blurRadius: 2),
                      ],
                      image: DecorationImage(image: AssetImage(AppAssets.user)),
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Text('KongossaPay', style: AppTextStyles.appTitle),
                ],
              ),
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(color: Colors.black.withValues(alpha: 0.05), offset: const Offset(0, 1), blurRadius: 2),
                  ],
                ),
                child: const Icon(Icons.notifications_outlined, size: 20, color: AppColors.darkNavy),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
