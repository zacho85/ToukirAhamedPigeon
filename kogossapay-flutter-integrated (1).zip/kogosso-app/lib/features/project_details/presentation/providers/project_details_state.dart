import 'package:kogosso_app/features/project_details/domain/domain.dart';

import 'project_details_status.dart';

export 'project_details_status.dart';

class ProjectDetailsState {
  final ProjectDetailsStatus status;
  final ProjectDetailsEntity? project;
  final bool isFavorited;

  const ProjectDetailsState({
    this.status = ProjectDetailsStatus.initial,
    this.project,
    this.isFavorited = false,
  });

  ProjectDetailsState copyWith({
    ProjectDetailsStatus? status,
    ProjectDetailsEntity? project,
    bool? isFavorited,
  }) {
    return ProjectDetailsState(
      status: status ?? this.status,
      project: project ?? this.project,
      isFavorited: isFavorited ?? this.isFavorited,
    );
  }
}
