import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/project_details/data/data.dart';
import 'package:kogosso_app/features/project_details/domain/domain.dart';

import 'project_details_state.dart';

export 'project_details_state.dart';

part 'project_details_provider.g.dart';

@riverpod
class ProjectDetails extends _$ProjectDetails {
  GetProjectDetails get _getProjectDetails =>
      GetProjectDetails(ProjectDetailsRepositoryImpl(ProjectDetailsLocalDataSourceImpl()));

  @override
  ProjectDetailsState build() => const ProjectDetailsState();

  Future<void> load() async {
    state = state.copyWith(status: ProjectDetailsStatus.loading);
    try {
      final project = await _getProjectDetails();
      state = state.copyWith(status: ProjectDetailsStatus.loaded, project: project);
    } catch (_) {
      state = state.copyWith(status: ProjectDetailsStatus.error);
    }
  }

  void toggleFavorite() {
    state = state.copyWith(isFavorited: !state.isFavorited);
  }
}
