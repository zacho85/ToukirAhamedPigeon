enum ProjectDetailsStatus { initial, loading, loaded, error }
