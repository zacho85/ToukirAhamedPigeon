// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'project_details_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(ProjectDetails)
final projectDetailsProvider = ProjectDetailsProvider._();

final class ProjectDetailsProvider
    extends $NotifierProvider<ProjectDetails, ProjectDetailsState> {
  ProjectDetailsProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'projectDetailsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$projectDetailsHash();

  @$internal
  @override
  ProjectDetails create() => ProjectDetails();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ProjectDetailsState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ProjectDetailsState>(value),
    );
  }
}

String _$projectDetailsHash() => r'cca10b93e0432737a14b3982da9796b0aeee430e';

abstract class _$ProjectDetails extends $Notifier<ProjectDetailsState> {
  ProjectDetailsState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<ProjectDetailsState, ProjectDetailsState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<ProjectDetailsState, ProjectDetailsState>,
              ProjectDetailsState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
