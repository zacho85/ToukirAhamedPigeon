import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/theme/theme.dart';

import '../providers/project_details_provider.dart';
import '../widgets/funding_progress_card.dart';
import '../widgets/project_hero_gallery.dart';
import '../widgets/project_team_row.dart';
import '../widgets/spread_the_word_row.dart';

class ProjectDetailsScreen extends ConsumerStatefulWidget {
  const ProjectDetailsScreen({super.key});

  @override
  ConsumerState<ProjectDetailsScreen> createState() => _ProjectDetailsScreenState();
}

class _ProjectDetailsScreenState extends ConsumerState<ProjectDetailsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(projectDetailsProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(projectDetailsProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 18,
                      color: AppColors.darkNavy,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(child: Text('Project Details', style: AppTextStyles.appTitle)),
                  // TODO: replace with the downloaded Figma overflow-menu icon and hook up its action.
                  const Icon(Icons.more_vert_rounded, size: 20, color: AppColors.darkNavy),
                ],
              ),
            ),
            Expanded(child: _buildBody(state)),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(ProjectDetailsState state) {
    if (state.status == ProjectDetailsStatus.loading ||
        state.status == ProjectDetailsStatus.initial) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryGreen));
    }

    if (state.status == ProjectDetailsStatus.error || state.project == null) {
      return const Center(
        child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
      );
    }

    final project = state.project!;
    final notifier = ref.read(projectDetailsProvider.notifier);

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ProjectHeroGallery(extraCount: project.galleryExtraCount),
          const SizedBox(height: 20),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppColors.primaryGreenLight.withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(9999),
                  ),
                  child: Text(
                    project.category,
                    style: AppTextStyles.badge.copyWith(
                      color: AppColors.primaryGreen,
                      fontSize: 11,
                    ),
                  ),
                ),
              ),
              GestureDetector(
                onTap: notifier.toggleFavorite,
                child: Icon(
                  state.isFavorited ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                  size: 22,
                  color: state.isFavorited ? AppColors.errorRed : AppColors.greyText,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            project.title,
            style: const TextStyle(
              fontFamily: 'PlusJakartaSans',
              fontWeight: FontWeight.w700,
              fontSize: 22,
              color: AppColors.darkNavy,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            project.description,
            style: TextStyle(
              fontFamily: 'Inter',
              fontSize: 13,
              height: 1.5,
              color: AppColors.darkNavy.withValues(alpha: 0.7),
            ),
          ),
          const SizedBox(height: 20),
          FundingProgressCard(
            amountRaised: project.amountRaised,
            goalAmount: project.goalAmount,
            progress: project.progress,
            contributorsCount: project.contributorsCount,
            daysLeft: project.daysLeft,
          ),
          const SizedBox(height: 28),
          ProjectTeamRow(team: project.team, extraCount: project.extraTeamCount),
          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {},
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.darkNavy,
                side: BorderSide(color: Colors.grey.withValues(alpha: 0.3)),
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.contacts_outlined, size: 18),
                  const SizedBox(width: 8),
                  const Text(
                    'Invite from Contacts',
                    style: TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          const SpreadTheWordRow(),
          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                elevation: 0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.volunteer_activism_outlined, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'Contribute Now',
                    style: AppTextStyles.transactionTitle.copyWith(color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
