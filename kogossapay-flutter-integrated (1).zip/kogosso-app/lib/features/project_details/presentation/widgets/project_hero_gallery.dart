import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class ProjectHeroGallery extends StatelessWidget {
  final int extraCount;

  const ProjectHeroGallery({super.key, required this.extraCount});

  // TODO: replace with the downloaded Figma project photos.
  static const _heroColors = [AppColors.primaryGreen, AppColors.darkNavy];
  static const _thumbColors = [Color(0xFF8C7BF6), AppColors.gold, Color(0xFF2FA8BF)];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(24),
          child: AspectRatio(
            aspectRatio: 16 / 10,
            child: Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: _heroColors,
                    ),
                  ),
                  child: const Center(
                    child: Icon(Icons.water_drop_outlined, size: 48, color: Colors.white38),
                  ),
                ),
                Positioned(
                  bottom: 12,
                  right: 12,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.5),
                      borderRadius: BorderRadius.circular(9999),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.play_circle_outline_rounded, size: 16, color: Colors.white),
                        const SizedBox(width: 6),
                        Text(
                          'View Video',
                          style: AppTextStyles.badge.copyWith(color: Colors.white, letterSpacing: 0),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            for (var i = 0; i < _thumbColors.length; i++) ...[
              Expanded(
                child: AspectRatio(
                  aspectRatio: 1,
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        Container(color: _thumbColors[i]),
                        if (i == _thumbColors.length - 1 && extraCount > 0)
                          Container(
                            color: Colors.black.withValues(alpha: 0.45),
                            child: Center(
                              child: Text(
                                '+$extraCount',
                                style: const TextStyle(
                                  fontFamily: 'PlusJakartaSans',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 16,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
              if (i < _thumbColors.length - 1) const SizedBox(width: 8),
            ],
          ],
        ),
      ],
    );
  }
}
