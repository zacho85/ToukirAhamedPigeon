import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class FundingProgressCard extends StatelessWidget {
  final double amountRaised;
  final double goalAmount;
  final double progress;
  final int contributorsCount;
  final int daysLeft;

  const FundingProgressCard({
    super.key,
    required this.amountRaised,
    required this.goalAmount,
    required this.progress,
    required this.contributorsCount,
    required this.daysLeft,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${amountRaised.toStringAsFixed(0)} XAF',
                style: const TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontWeight: FontWeight.w700,
                  fontSize: 20,
                  color: AppColors.primaryGreen,
                ),
              ),
              const Spacer(),
              Text(
                'Goal ${goalAmount.toStringAsFixed(0)} XAF',
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'Amount Raised',
            style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.3),
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              backgroundColor: AppColors.progressTrack,
              valueColor: const AlwaysStoppedAnimation(AppColors.primaryGreen),
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              const Icon(Icons.groups_outlined, size: 14, color: AppColors.greyText),
              const SizedBox(width: 6),
              Text(
                '$contributorsCount Contributors',
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
              ),
              const SizedBox(width: 16),
              const Icon(Icons.schedule_rounded, size: 14, color: AppColors.greyText),
              const SizedBox(width: 6),
              Text(
                '$daysLeft Days Left',
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
