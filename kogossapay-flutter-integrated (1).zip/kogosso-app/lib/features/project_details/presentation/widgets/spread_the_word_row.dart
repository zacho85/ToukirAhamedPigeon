import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class SpreadTheWordRow extends StatelessWidget {
  const SpreadTheWordRow({super.key});

  // TODO: replace with the downloaded Figma brand icons (WhatsApp, Facebook, X, ...).
  static const _channels = [
    (icon: Icons.chat_bubble_rounded, color: Color(0xFF25D366)),
    (icon: Icons.facebook_rounded, color: Color(0xFF1877F2)),
    (icon: Icons.alternate_email_rounded, color: Color(0xFF1DA1F2)),
    (icon: Icons.link_rounded, color: AppColors.darkNavy),
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'SPREAD THE WORD',
          style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.6),
        ),
        const SizedBox(height: 16),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            for (final channel in _channels) ...[
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(color: channel.color, shape: BoxShape.circle),
                child: Icon(channel.icon, size: 20, color: Colors.white),
              ),
              const SizedBox(width: 16),
            ],
          ],
        ),
      ],
    );
  }
}
