import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/project_details/domain/domain.dart';

class ProjectTeamRow extends StatelessWidget {
  final List<TeamMemberEntity> team;
  final int extraCount;

  const ProjectTeamRow({super.key, required this.team, required this.extraCount});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Project Team', style: AppTextStyles.sectionHeading),
            Text(
              'View All',
              style: AppTextStyles.quickActionLabel.copyWith(color: AppColors.primaryGreen),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            for (final member in team) ...[
              _MemberAvatar(member: member),
              const SizedBox(width: 16),
            ],
            if (extraCount > 0) _ExtraAvatar(count: extraCount),
          ],
        ),
      ],
    );
  }
}

class _MemberAvatar extends StatelessWidget {
  final TeamMemberEntity member;

  const _MemberAvatar({required this.member});

  @override
  Widget build(BuildContext context) {
    final color = AppColors.avatarPalette[member.colorIndex % AppColors.avatarPalette.length];

    return Column(
      children: [
        // TODO: replace with the downloaded Figma team member photo.
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          child: Center(
            child: Text(
              member.initials,
              style: const TextStyle(
                fontFamily: 'PlusJakartaSans',
                fontWeight: FontWeight.w700,
                fontSize: 13,
                color: Colors.white,
              ),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          member.name,
          style: AppTextStyles.badge.copyWith(color: AppColors.darkNavy, letterSpacing: 0, fontSize: 11),
        ),
      ],
    );
  }
}

class _ExtraAvatar extends StatelessWidget {
  final int count;

  const _ExtraAvatar({required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: AppColors.background,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.grey.withValues(alpha: 0.2)),
      ),
      child: Center(
        child: Text(
          '+$count',
          style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
        ),
      ),
    );
  }
}
