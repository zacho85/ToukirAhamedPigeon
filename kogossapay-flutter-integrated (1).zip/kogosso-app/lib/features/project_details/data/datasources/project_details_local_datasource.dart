import 'package:kogosso_app/features/project_details/domain/domain.dart';

abstract class ProjectDetailsLocalDataSource {
  Future<ProjectDetailsEntity> fetchProjectDetails();
}

class ProjectDetailsLocalDataSourceImpl implements ProjectDetailsLocalDataSource {
  @override
  Future<ProjectDetailsEntity> fetchProjectDetails() async => const ProjectDetailsEntity(
    category: 'Community & Environment',
    title: 'Clean Water for Kribi',
    description:
        'Providing sustainable, solar-powered filtration systems to 5 villages in the Kribi '
        'coastal region. Our mission is to eliminate waterborne diseases and empower 2,000+ '
        'residents with consistent access to safe drinking water.',
    amountRaised: 3750000,
    goalAmount: 5000000,
    contributorsCount: 142,
    daysLeft: 12,
    galleryExtraCount: 12,
    team: [
      TeamMemberEntity(name: 'Dr. Amadou', initials: 'DA', colorIndex: 0),
      TeamMemberEntity(name: 'Sarah J.', initials: 'SJ', colorIndex: 1),
      TeamMemberEntity(name: 'Kevin M.', initials: 'KM', colorIndex: 2),
      TeamMemberEntity(name: 'Evelyne B.', initials: 'EB', colorIndex: 3),
    ],
    extraTeamCount: 5,
  );
}
