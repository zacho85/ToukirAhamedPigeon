import 'package:kogosso_app/features/project_details/domain/domain.dart';

import '../datasources/project_details_local_datasource.dart';

class ProjectDetailsRepositoryImpl implements ProjectDetailsRepository {
  final ProjectDetailsLocalDataSource localDataSource;

  const ProjectDetailsRepositoryImpl(this.localDataSource);

  @override
  Future<ProjectDetailsEntity> getProjectDetails() => localDataSource.fetchProjectDetails();
}
