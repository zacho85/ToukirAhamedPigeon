library;

export 'datasources/project_details_local_datasource.dart';
export 'repositories/project_details_repository_impl.dart';
