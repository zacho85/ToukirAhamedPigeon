import '../entities/project_details_entity.dart';
import '../repositories/project_details_repository.dart';

class GetProjectDetails {
  final ProjectDetailsRepository repository;

  const GetProjectDetails(this.repository);

  Future<ProjectDetailsEntity> call() => repository.getProjectDetails();
}
