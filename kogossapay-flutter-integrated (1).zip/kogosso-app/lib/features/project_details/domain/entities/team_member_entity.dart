class TeamMemberEntity {
  final String name;
  final String initials;
  final int colorIndex;

  const TeamMemberEntity({required this.name, required this.initials, required this.colorIndex});
}
