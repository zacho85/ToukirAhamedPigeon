import 'team_member_entity.dart';

class ProjectDetailsEntity {
  final String category;
  final String title;
  final String description;
  final double amountRaised;
  final double goalAmount;
  final int contributorsCount;
  final int daysLeft;
  final int galleryExtraCount;
  final List<TeamMemberEntity> team;
  final int extraTeamCount;

  const ProjectDetailsEntity({
    required this.category,
    required this.title,
    required this.description,
    required this.amountRaised,
    required this.goalAmount,
    required this.contributorsCount,
    required this.daysLeft,
    required this.galleryExtraCount,
    required this.team,
    required this.extraTeamCount,
  });

  double get progress => goalAmount <= 0 ? 0 : (amountRaised / goalAmount).clamp(0.0, 1.0);
}
