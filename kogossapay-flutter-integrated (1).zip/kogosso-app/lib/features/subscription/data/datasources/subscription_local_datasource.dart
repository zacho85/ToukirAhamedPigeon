import 'package:kogosso_app/features/subscription/domain/domain.dart';

abstract class SubscriptionLocalDataSource {
  Future<List<PlanEntity>> fetchPlans();
}

class SubscriptionLocalDataSourceImpl implements SubscriptionLocalDataSource {
  @override
  Future<List<PlanEntity>> fetchPlans() async => const [
    PlanEntity(
      id: 'basic',
      eyebrow: 'THE START',
      title: 'Basic',
      monthlyPrice: 0,
      isFree: true,
      isCurrent: true,
      ctaLabel: 'Current Plan',
      features: [
        PlanFeatureEntity(label: 'Standard Tontine Access'),
        PlanFeatureEntity(label: '1% Exchange Fees'),
        PlanFeatureEntity(label: 'Community Support'),
        PlanFeatureEntity(label: 'Premium Card', isIncluded: false),
      ],
    ),
    PlanEntity(
      id: 'pro',
      eyebrow: 'ACCELERATOR',
      title: 'Pro',
      monthlyPrice: 12,
      isFree: false,
      isFeatured: true,
      badgeLabel: 'BEST VALUE',
      ctaLabel: 'Upgrade Now',
      features: [
        PlanFeatureEntity(label: 'Higher Tontine Limits'),
        PlanFeatureEntity(label: '0.4% Exchange Fees'),
        PlanFeatureEntity(label: 'Priority 24/7 Support'),
        PlanFeatureEntity(label: 'Exclusive Metal Card'),
      ],
    ),
    PlanEntity(
      id: 'enterprise',
      eyebrow: 'THE ELITE',
      title: 'Enterprise',
      monthlyPrice: 49,
      isFree: false,
      ctaLabel: 'Contact Sales',
      features: [
        PlanFeatureEntity(label: 'Unlimited Tontine Groups'),
        PlanFeatureEntity(label: '0.1% Exchange Fees'),
        PlanFeatureEntity(label: 'Personal Concierge'),
        PlanFeatureEntity(label: 'Multi-User Team Wallets'),
      ],
    ),
  ];
}
