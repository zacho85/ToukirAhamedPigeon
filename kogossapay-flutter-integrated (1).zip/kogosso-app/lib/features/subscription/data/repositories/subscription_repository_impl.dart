import 'package:kogosso_app/features/subscription/domain/domain.dart';

import '../datasources/subscription_local_datasource.dart';

class SubscriptionRepositoryImpl implements SubscriptionRepository {
  final SubscriptionLocalDataSource localDataSource;

  const SubscriptionRepositoryImpl(this.localDataSource);

  @override
  Future<List<PlanEntity>> getPlans() => localDataSource.fetchPlans();
}
