import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/core/widgets/widgets.dart';

import '../providers/subscription_provider.dart';
import '../widgets/billing_cycle_toggle.dart';
import '../widgets/plan_card.dart';

class SubscriptionScreen extends ConsumerStatefulWidget {
  const SubscriptionScreen({super.key});

  @override
  ConsumerState<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends ConsumerState<SubscriptionScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(subscriptionProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(subscriptionProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(bottom: false, child: _buildBody(state)),
    );
  }

  Widget _buildBody(SubscriptionState state) {
    if (state.status == SubscriptionStatus.loading ||
        state.status == SubscriptionStatus.initial) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryGreen));
    }

    if (state.status == SubscriptionStatus.error) {
      return const Center(
        child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
      );
    }

    final notifier = ref.read(subscriptionProvider.notifier);

    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 32),
      child: Column(
        children: [
          const AppTopBar(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 28),
            child: Column(
              children: [
                const Text(
                  'Elevate Your Finances',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'PlusJakartaSans',
                    fontWeight: FontWeight.w700,
                    fontSize: 28,
                    height: 1.2,
                    color: AppColors.darkNavy,
                  ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Choose the plan that fits your growth. From casual savings to elite '
                  'tontine management.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 13,
                    height: 1.5,
                    color: AppColors.greyText,
                  ),
                ),
                const SizedBox(height: 24),
                BillingCycleToggle(
                  cycle: state.billingCycle,
                  onChanged: notifier.setBillingCycle,
                ),
                const SizedBox(height: 28),
                for (final plan in state.plans) ...[
                  PlanCard(plan: plan, billingCycle: state.billingCycle),
                  const SizedBox(height: 20),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
