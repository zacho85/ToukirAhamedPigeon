import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/subscription/presentation/providers/subscription_provider.dart';

class BillingCycleToggle extends StatelessWidget {
  final BillingCycle cycle;
  final ValueChanged<BillingCycle> onChanged;

  const BillingCycleToggle({super.key, required this.cycle, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final isYearly = cycle == BillingCycle.yearly;

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          'Monthly',
          style: AppTextStyles.transactionTitle.copyWith(
            fontSize: 14,
            color: isYearly ? AppColors.greyText : AppColors.darkNavy,
          ),
        ),
        const SizedBox(width: 12),
        GestureDetector(
          onTap: () => onChanged(isYearly ? BillingCycle.monthly : BillingCycle.yearly),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            width: 48,
            height: 28,
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              color: AppColors.primaryGreen,
              borderRadius: BorderRadius.circular(9999),
            ),
            child: AnimatedAlign(
              duration: const Duration(milliseconds: 150),
              alignment: isYearly ? Alignment.centerRight : Alignment.centerLeft,
              child: Container(
                width: 22,
                height: 22,
                decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Text(
          'Yearly',
          style: AppTextStyles.transactionTitle.copyWith(
            fontSize: 14,
            color: isYearly ? AppColors.darkNavy : AppColors.greyText,
          ),
        ),
        const SizedBox(width: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: AppColors.primaryGreenLight.withValues(alpha: 0.3),
            borderRadius: BorderRadius.circular(9999),
          ),
          child: Text(
            'SAVE 20%',
            style: AppTextStyles.badge.copyWith(color: AppColors.primaryGreen, fontSize: 10),
          ),
        ),
      ],
    );
  }
}
