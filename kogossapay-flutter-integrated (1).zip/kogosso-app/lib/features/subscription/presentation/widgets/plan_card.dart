import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/subscription/domain/domain.dart';

import '../providers/subscription_provider.dart';

class PlanCard extends StatelessWidget {
  final PlanEntity plan;
  final BillingCycle billingCycle;

  const PlanCard({super.key, required this.plan, required this.billingCycle});

  @override
  Widget build(BuildContext context) {
    final isDark = plan.isFeatured;
    final fgColor = isDark ? Colors.white : AppColors.darkNavy;
    final mutedColor = isDark ? Colors.white.withValues(alpha: 0.6) : AppColors.greyText;

    final isYearly = billingCycle == BillingCycle.yearly;
    final displayPrice = plan.isFree
        ? '0'
        : (isYearly ? (plan.monthlyPrice * 12 * 0.8).round().toString() : plan.monthlyPrice.toStringAsFixed(0));
    final period = plan.isFree ? 'forever' : (isYearly ? 'year' : 'month');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: isDark ? AppColors.darkNavy : Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: isDark ? 0.2 : 0.05),
            offset: const Offset(0, 4),
            blurRadius: isDark ? 20 : 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (plan.badgeLabel != null) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.primaryGreenLight,
                borderRadius: BorderRadius.circular(9999),
              ),
              child: Text(
                plan.badgeLabel!,
                style: AppTextStyles.badge.copyWith(color: AppColors.darkNavy, fontSize: 10),
              ),
            ),
            const SizedBox(height: 12),
          ],
          Text(
            plan.eyebrow,
            style: AppTextStyles.badge.copyWith(color: mutedColor, letterSpacing: 0.6),
          ),
          const SizedBox(height: 4),
          Text(
            plan.title,
            style: TextStyle(
              fontFamily: 'PlusJakartaSans',
              fontWeight: FontWeight.w700,
              fontSize: 24,
              color: fgColor,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '\$$displayPrice',
                style: TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontWeight: FontWeight.w700,
                  fontSize: 36,
                  color: fgColor,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 6, left: 4),
                child: Text(
                  '/$period',
                  style: AppTextStyles.badge.copyWith(color: mutedColor, letterSpacing: 0),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          for (final feature in plan.features) ...[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                children: [
                  Icon(
                    Icons.check_circle,
                    size: 18,
                    color: feature.isIncluded
                        ? AppColors.primaryGreen
                        : mutedColor.withValues(alpha: 0.4),
                  ),
                  const SizedBox(width: 10),
                  Text(
                    feature.label,
                    style: TextStyle(
                      fontFamily: 'Inter',
                      fontSize: 13,
                      color: feature.isIncluded ? fgColor : mutedColor.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
            ),
          ],
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: plan.isCurrent
                ? OutlinedButton(
                    onPressed: () {},
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.darkNavy,
                      side: BorderSide(color: Colors.grey.withValues(alpha: 0.3)),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                    ),
                    child: Text(
                      plan.ctaLabel,
                      style: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600, fontSize: 14),
                    ),
                  )
                : ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isDark ? AppColors.primaryGreenLight : AppColors.darkNavy,
                      foregroundColor: isDark ? AppColors.darkNavy : Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                      elevation: 0,
                    ),
                    child: Text(
                      plan.ctaLabel,
                      style: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600, fontSize: 14),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
