import 'package:kogosso_app/features/subscription/domain/domain.dart';

import 'billing_cycle.dart';
import 'subscription_status.dart';

export 'billing_cycle.dart';
export 'subscription_status.dart';

class SubscriptionState {
  final SubscriptionStatus status;
  final List<PlanEntity> plans;
  final BillingCycle billingCycle;

  const SubscriptionState({
    this.status = SubscriptionStatus.initial,
    this.plans = const [],
    this.billingCycle = BillingCycle.monthly,
  });

  SubscriptionState copyWith({
    SubscriptionStatus? status,
    List<PlanEntity>? plans,
    BillingCycle? billingCycle,
  }) {
    return SubscriptionState(
      status: status ?? this.status,
      plans: plans ?? this.plans,
      billingCycle: billingCycle ?? this.billingCycle,
    );
  }
}
