enum SubscriptionStatus { initial, loading, loaded, error }
