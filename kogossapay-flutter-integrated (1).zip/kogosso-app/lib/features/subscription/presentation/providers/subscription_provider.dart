import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/subscription/data/data.dart';
import 'package:kogosso_app/features/subscription/domain/domain.dart';

import 'subscription_state.dart';

export 'subscription_state.dart';

part 'subscription_provider.g.dart';

@riverpod
class Subscription extends _$Subscription {
  GetPlans get _getPlans =>
      GetPlans(SubscriptionRepositoryImpl(SubscriptionLocalDataSourceImpl()));

  @override
  SubscriptionState build() => const SubscriptionState();

  Future<void> load() async {
    state = state.copyWith(status: SubscriptionStatus.loading);
    try {
      final plans = await _getPlans();
      state = state.copyWith(status: SubscriptionStatus.loaded, plans: plans);
    } catch (_) {
      state = state.copyWith(status: SubscriptionStatus.error);
    }
  }

  void setBillingCycle(BillingCycle cycle) {
    state = state.copyWith(billingCycle: cycle);
  }
}
