class PlanFeatureEntity {
  final String label;
  final bool isIncluded;

  const PlanFeatureEntity({required this.label, this.isIncluded = true});
}

class PlanEntity {
  final String id;
  final String eyebrow;
  final String title;
  final double monthlyPrice;
  final bool isFree;
  final String? badgeLabel;
  final bool isFeatured;
  final bool isCurrent;
  final List<PlanFeatureEntity> features;
  final String ctaLabel;

  const PlanEntity({
    required this.id,
    required this.eyebrow,
    required this.title,
    required this.monthlyPrice,
    required this.isFree,
    required this.features,
    required this.ctaLabel,
    this.badgeLabel,
    this.isFeatured = false,
    this.isCurrent = false,
  });
}
