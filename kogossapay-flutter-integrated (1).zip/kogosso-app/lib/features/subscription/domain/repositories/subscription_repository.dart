import '../entities/plan_entity.dart';

abstract class SubscriptionRepository {
  Future<List<PlanEntity>> getPlans();
}
