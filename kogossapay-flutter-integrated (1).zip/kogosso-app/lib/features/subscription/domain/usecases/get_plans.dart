import '../entities/plan_entity.dart';
import '../repositories/subscription_repository.dart';

class GetPlans {
  final SubscriptionRepository repository;

  const GetPlans(this.repository);

  Future<List<PlanEntity>> call() => repository.getPlans();
}
