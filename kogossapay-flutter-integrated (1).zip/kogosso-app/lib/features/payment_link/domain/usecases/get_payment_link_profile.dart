import '../entities/payment_link_profile_entity.dart';
import '../repositories/payment_link_repository.dart';

class GetPaymentLinkProfile {
  final PaymentLinkRepository repository;

  const GetPaymentLinkProfile(this.repository);

  Future<PaymentLinkProfileEntity> call() => repository.getProfile();
}
