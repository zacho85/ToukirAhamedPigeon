class PaymentLinkProfileEntity {
  final String displayName;

  const PaymentLinkProfileEntity({required this.displayName});
}
