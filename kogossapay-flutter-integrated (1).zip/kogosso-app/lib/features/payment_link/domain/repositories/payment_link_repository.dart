import '../entities/payment_link_profile_entity.dart';

abstract class PaymentLinkRepository {
  Future<PaymentLinkProfileEntity> getProfile();
}
