import 'package:kogosso_app/features/payment_link/domain/domain.dart';

abstract class PaymentLinkLocalDataSource {
  Future<PaymentLinkProfileEntity> fetchProfile();
}

class PaymentLinkLocalDataSourceImpl implements PaymentLinkLocalDataSource {
  @override
  Future<PaymentLinkProfileEntity> fetchProfile() async =>
      const PaymentLinkProfileEntity(displayName: 'Felix');
}
