import 'package:kogosso_app/features/payment_link/domain/domain.dart';

import '../datasources/payment_link_local_datasource.dart';

class PaymentLinkRepositoryImpl implements PaymentLinkRepository {
  final PaymentLinkLocalDataSource localDataSource;

  const PaymentLinkRepositoryImpl(this.localDataSource);

  @override
  Future<PaymentLinkProfileEntity> getProfile() => localDataSource.fetchProfile();
}
