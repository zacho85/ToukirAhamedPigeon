// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'payment_link_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(PaymentLink)
final paymentLinkProvider = PaymentLinkProvider._();

final class PaymentLinkProvider
    extends $NotifierProvider<PaymentLink, PaymentLinkState> {
  PaymentLinkProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'paymentLinkProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$paymentLinkHash();

  @$internal
  @override
  PaymentLink create() => PaymentLink();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PaymentLinkState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PaymentLinkState>(value),
    );
  }
}

String _$paymentLinkHash() => r'fc8aac33ba5edeab769d59588503fbdae5d7a70b';

abstract class _$PaymentLink extends $Notifier<PaymentLinkState> {
  PaymentLinkState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<PaymentLinkState, PaymentLinkState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<PaymentLinkState, PaymentLinkState>,
              PaymentLinkState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
