enum PaymentLinkStatus { initial, loading, loaded, error }
