import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/payment_link/data/data.dart';
import 'package:kogosso_app/features/payment_link/domain/domain.dart';

import 'payment_link_state.dart';

export 'payment_link_state.dart';

part 'payment_link_provider.g.dart';

@riverpod
class PaymentLink extends _$PaymentLink {
  GetPaymentLinkProfile get _getPaymentLinkProfile =>
      GetPaymentLinkProfile(PaymentLinkRepositoryImpl(PaymentLinkLocalDataSourceImpl()));

  @override
  PaymentLinkState build() => const PaymentLinkState();

  Future<void> load() async {
    state = state.copyWith(status: PaymentLinkStatus.loading);
    try {
      final profile = await _getPaymentLinkProfile();
      state = state.copyWith(status: PaymentLinkStatus.loaded, profile: profile);
    } catch (_) {
      state = state.copyWith(status: PaymentLinkStatus.error);
    }
  }

  void setTitle(String value) {
    state = state.copyWith(title: value);
  }

  void setAmount(double value) {
    state = state.copyWith(amount: value);
  }

  void toggleAdvancedOptions() {
    state = state.copyWith(isAdvancedOptionsExpanded: !state.isAdvancedOptionsExpanded);
  }
}
