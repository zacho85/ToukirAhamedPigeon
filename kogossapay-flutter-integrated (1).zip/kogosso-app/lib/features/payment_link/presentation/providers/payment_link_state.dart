import 'package:kogosso_app/features/payment_link/domain/domain.dart';

import 'payment_link_status.dart';

export 'payment_link_status.dart';

class PaymentLinkState {
  final PaymentLinkStatus status;
  final PaymentLinkProfileEntity? profile;
  final String title;
  final double amount;
  final bool isAdvancedOptionsExpanded;

  const PaymentLinkState({
    this.status = PaymentLinkStatus.initial,
    this.profile,
    this.title = '',
    this.amount = 0,
    this.isAdvancedOptionsExpanded = false,
  });

  PaymentLinkState copyWith({
    PaymentLinkStatus? status,
    PaymentLinkProfileEntity? profile,
    String? title,
    double? amount,
    bool? isAdvancedOptionsExpanded,
  }) {
    return PaymentLinkState(
      status: status ?? this.status,
      profile: profile ?? this.profile,
      title: title ?? this.title,
      amount: amount ?? this.amount,
      isAdvancedOptionsExpanded: isAdvancedOptionsExpanded ?? this.isAdvancedOptionsExpanded,
    );
  }
}
