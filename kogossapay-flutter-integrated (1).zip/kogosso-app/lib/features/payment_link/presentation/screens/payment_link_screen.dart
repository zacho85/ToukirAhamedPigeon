import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/core/widgets/widgets.dart';

import '../providers/payment_link_provider.dart';
import '../widgets/payment_link_form.dart';
import '../widgets/payment_link_preview_card.dart';

class PaymentLinkScreen extends ConsumerStatefulWidget {
  const PaymentLinkScreen({super.key});

  @override
  ConsumerState<PaymentLinkScreen> createState() => _PaymentLinkScreenState();
}

class _PaymentLinkScreenState extends ConsumerState<PaymentLinkScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(paymentLinkProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(paymentLinkProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(bottom: false, child: _buildBody(state)),
    );
  }

  Widget _buildBody(PaymentLinkState state) {
    if (state.status == PaymentLinkStatus.loading || state.status == PaymentLinkStatus.initial) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryGreen));
    }

    if (state.status == PaymentLinkStatus.error || state.profile == null) {
      return const Center(
        child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
      );
    }

    final notifier = ref.read(paymentLinkProvider.notifier);

    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 32),
      child: Column(
        children: [
          const AppTopBar(),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Create Payment Link',
                  style: TextStyle(
                    fontFamily: 'PlusJakartaSans',
                    fontWeight: FontWeight.w700,
                    fontSize: 22,
                    color: AppColors.darkNavy,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Generate a unique link to get paid instantly by anyone, anywhere.',
                  style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                ),
                const SizedBox(height: 24),
                PaymentLinkForm(
                  isAdvancedOptionsExpanded: state.isAdvancedOptionsExpanded,
                  onTitleChanged: notifier.setTitle,
                  onAmountChanged: notifier.setAmount,
                  onToggleAdvancedOptions: notifier.toggleAdvancedOptions,
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryGreen,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                      elevation: 0,
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.link_rounded, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          'Generate Payment Link',
                          style: AppTextStyles.transactionTitle.copyWith(color: Colors.white),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 28),
                Row(
                  children: [
                    Text(
                      'LIVE PREVIEW',
                      style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.6),
                    ),
                    const Spacer(),
                    _Dot(color: AppColors.primaryGreen),
                    const SizedBox(width: 4),
                    _Dot(color: AppColors.greyText.withValues(alpha: 0.3)),
                  ],
                ),
                const SizedBox(height: 16),
                PaymentLinkPreviewCard(
                  senderName: state.profile!.displayName,
                  title: state.title,
                  amount: state.amount,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _Dot extends StatelessWidget {
  final Color color;

  const _Dot({required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 6,
      height: 6,
      decoration: BoxDecoration(color: color, shape: BoxShape.circle),
    );
  }
}
