import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class PaymentLinkForm extends StatelessWidget {
  final bool isAdvancedOptionsExpanded;
  final ValueChanged<String> onTitleChanged;
  final ValueChanged<double> onAmountChanged;
  final VoidCallback onToggleAdvancedOptions;

  const PaymentLinkForm({
    super.key,
    required this.isAdvancedOptionsExpanded,
    required this.onTitleChanged,
    required this.onAmountChanged,
    required this.onToggleAdvancedOptions,
  });

  InputDecoration _decoration(String hint) => InputDecoration(
    hintText: hint,
    hintStyle: AppTextStyles.quickActionLabel,
    filled: true,
    fillColor: Colors.white,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.15)),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: BorderSide(color: Colors.grey.withValues(alpha: 0.15)),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: const BorderSide(color: AppColors.primaryGreen),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Purpose / Title',
          style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.3),
        ),
        const SizedBox(height: 8),
        TextField(
          onChanged: onTitleChanged,
          decoration: _decoration('e.g. Freelance Design Work'),
        ),
        const SizedBox(height: 20),
        Text(
          'Requested Amount',
          style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.3),
        ),
        const SizedBox(height: 8),
        TextField(
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          style: const TextStyle(
            fontFamily: 'PlusJakartaSans',
            fontWeight: FontWeight.w700,
            fontSize: 24,
            color: AppColors.darkNavy,
          ),
          onChanged: (value) => onAmountChanged(double.tryParse(value) ?? 0),
          decoration: _decoration('0.00'),
        ),
        const SizedBox(height: 20),
        GestureDetector(
          onTap: onToggleAdvancedOptions,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey.withValues(alpha: 0.15)),
            ),
            child: Row(
              children: [
                const Icon(Icons.tune_rounded, size: 18, color: AppColors.greyText),
                const SizedBox(width: 10),
                Expanded(
                  child: Text('Advanced Options', style: AppTextStyles.transactionTitle.copyWith(fontSize: 14)),
                ),
                Icon(
                  isAdvancedOptionsExpanded ? Icons.expand_less_rounded : Icons.expand_more_rounded,
                  size: 20,
                  color: AppColors.greyText,
                ),
              ],
            ),
          ),
        ),
        if (isAdvancedOptionsExpanded) ...[
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey.withValues(alpha: 0.15)),
            ),
            child: Text(
              'Set an expiry date, allow partial payments, or add a custom note. '
              'These options will be available once payment links go live.',
              style: TextStyle(fontFamily: 'Inter', fontSize: 12, height: 1.4, color: AppColors.greyText),
            ),
          ),
        ],
      ],
    );
  }
}
