import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class PaymentLinkPreviewCard extends StatelessWidget {
  final String senderName;
  final String title;
  final double amount;

  const PaymentLinkPreviewCard({
    super.key,
    required this.senderName,
    required this.title,
    required this.amount,
  });

  @override
  Widget build(BuildContext context) {
    return DottedBorderContainer(
      child: Column(
        children: [
          // TODO: replace with the downloaded Figma brand mark icon.
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.primaryGreen,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(Icons.bolt_rounded, size: 22, color: Colors.white),
          ),
          const SizedBox(height: 12),
          Text(
            'REQUEST FROM ${senderName.toUpperCase()}',
            style: AppTextStyles.badge.copyWith(color: AppColors.primaryGreen, letterSpacing: 0.5),
          ),
          const SizedBox(height: 8),
          Text(
            title.isEmpty ? 'Payment Request' : title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              fontFamily: 'PlusJakartaSans',
              fontWeight: FontWeight.w700,
              fontSize: 18,
              color: AppColors.darkNavy,
            ),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                'XAF',
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
              ),
              const SizedBox(width: 6),
              Text(
                amount.toStringAsFixed(0),
                style: const TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontWeight: FontWeight.w700,
                  fontSize: 32,
                  color: AppColors.darkNavy,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              'Sender name',
              style: AppTextStyles.quickActionLabel.copyWith(color: AppColors.greyText.withValues(alpha: 0.5)),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 14),
            decoration: BoxDecoration(
              color: AppColors.progressTrack,
              borderRadius: BorderRadius.circular(9999),
            ),
            child: Center(
              child: Text(
                'Pay Now',
                style: AppTextStyles.transactionTitle.copyWith(
                  fontSize: 14,
                  color: AppColors.greyText,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class DottedBorderContainer extends StatelessWidget {
  final Widget child;

  const DottedBorderContainer({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _DashedBorderPainter(),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.background,
          borderRadius: BorderRadius.circular(20),
        ),
        child: child,
      ),
    );
  }
}

class _DashedBorderPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.grey.withValues(alpha: 0.35)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;

    final rrect = RRect.fromRectAndRadius(
      Rect.fromLTWH(0, 0, size.width, size.height),
      const Radius.circular(20),
    );
    final path = Path()..addRRect(rrect);

    const dashWidth = 6.0;
    const dashSpace = 4.0;
    for (final metric in path.computeMetrics()) {
      var distance = 0.0;
      while (distance < metric.length) {
        canvas.drawPath(
          metric.extractPath(distance, distance + dashWidth),
          paint,
        );
        distance += dashWidth + dashSpace;
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DashedBorderPainter oldDelegate) => false;
}
