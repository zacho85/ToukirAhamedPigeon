import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/auth/presentation/providers/auth_provider.dart';

class OtpScreen extends ConsumerStatefulWidget {
  const OtpScreen({super.key});

  @override
  ConsumerState<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends ConsumerState<OtpScreen> {
  final _code = TextEditingController();

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  void _submit() {
    final c = _code.text.trim();
    if (c.length < 4) return;
    FocusScope.of(context).unfocus();
    ref.read(authProvider.notifier).verifyOtp(c);
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authProvider);
    final text = Theme.of(context).textTheme;
    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: BackButton(onPressed: () => ref.read(authProvider.notifier).backToLogin()),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Vérification', style: text.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text('Entrez le code envoyé à ${auth.pendingEmail ?? 'votre email'}.', style: text.bodyMedium?.copyWith(color: AppColors.greyText)),
              const SizedBox(height: 24),
              TextField(
                controller: _code,
                autofocus: true,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                maxLength: 6,
                autofillHints: const [AutofillHints.oneTimeCode],
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                style: text.headlineSmall?.copyWith(letterSpacing: 8),
                decoration: const InputDecoration(border: OutlineInputBorder(), counterText: ''),
                onChanged: (v) {
                  if (v.length == 6) _submit();
                },
              ),
              if (auth.error != null) ...[
                const SizedBox(height: 8),
                Text(auth.error!, style: const TextStyle(color: AppColors.errorRed)),
              ],
              const SizedBox(height: 16),
              FilledButton(
                onPressed: auth.loading ? null : _submit,
                style: FilledButton.styleFrom(backgroundColor: AppColors.primaryGreen, minimumSize: const Size.fromHeight(52)),
                child: auth.loading
                    ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('Valider'),
              ),
              TextButton(
                onPressed: auth.loading ? null : () => ref.read(authProvider.notifier).resendOtp(),
                child: const Text('Renvoyer le code'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
