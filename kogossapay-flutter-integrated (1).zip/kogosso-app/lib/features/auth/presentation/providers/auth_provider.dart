import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:kogosso_app/core/network/network.dart';
import 'package:kogosso_app/features/auth/data/data.dart';

final tokenStorageProvider = Provider<TokenStorage>((ref) => TokenStorage());

final apiClientProvider = Provider<ApiClient>((ref) {
  return ApiClient(
    tokens: ref.watch(tokenStorageProvider),
    // Lecture paresseuse : évite la dépendance circulaire avec authProvider.
    onSessionExpired: () => ref.read(authProvider.notifier).sessionExpired(),
  );
});

/// Dio authentifié, à injecter dans tous les RemoteDataSource.
final dioProvider = Provider<Dio>((ref) => ref.watch(apiClientProvider).dio);

final kongossaApiProvider = Provider<KongossaApi>((ref) => KongossaApi(ref.watch(dioProvider)));

final authRemoteProvider = Provider<AuthRemoteDataSource>((ref) => AuthRemoteDataSource(ref.watch(dioProvider)));

enum AuthStatus { unknown, unauthenticated, awaitingOtp, authenticated }

class AuthState {
  final AuthStatus status;
  final bool loading;
  final String? error;
  final String? pendingEmail;

  const AuthState({
    this.status = AuthStatus.unknown,
    this.loading = false,
    this.error,
    this.pendingEmail,
  });

  AuthState copyWith({AuthStatus? status, bool? loading, String? error, String? pendingEmail, bool clearError = false}) =>
      AuthState(
        status: status ?? this.status,
        loading: loading ?? this.loading,
        error: clearError ? null : (error ?? this.error),
        pendingEmail: pendingEmail ?? this.pendingEmail,
      );
}

final authProvider = NotifierProvider<AuthNotifier, AuthState>(AuthNotifier.new);

class AuthNotifier extends Notifier<AuthState> {
  AuthRemoteDataSource get _remote => ref.read(authRemoteProvider);
  TokenStorage get _tokens => ref.read(tokenStorageProvider);

  @override
  AuthState build() {
    Future.microtask(_restore);
    return const AuthState();
  }

  Future<void> _restore() async {
    final t = await _tokens.readAccess();
    state = state.copyWith(status: t == null ? AuthStatus.unauthenticated : AuthStatus.authenticated);
  }

  /// Étape 1 : identifiant + mot de passe. Le serveur envoie le code OTP.
  Future<void> login({required String identifier, required String password}) async {
    state = state.copyWith(loading: true, clearError: true);
    try {
      final body = await _remote.login(identifier: identifier, password: password);
      final direct = TokenPair.fromJson(body);
      if (body['otp_required'] != true && direct != null) {
        // Appareil déjà reconnu : pas de code demandé.
        await _tokens.save(access: direct.access, refresh: direct.refresh);
        state = state.copyWith(loading: false, status: AuthStatus.authenticated);
        return;
      }
      final email = (body['email'] is String ? body['email'] as String : null) ?? (identifier.contains('@') ? identifier : null);
      if (email == null) {
        throw const ApiException('Réponse de connexion inattendue.');
      }
      state = state.copyWith(loading: false, status: AuthStatus.awaitingOtp, pendingEmail: email);
    } catch (e) {
      state = state.copyWith(loading: false, error: ApiException.from(e).message);
    }
  }

  Future<void> resendOtp() async {
    final email = state.pendingEmail;
    if (email == null) return;
    state = state.copyWith(loading: true, clearError: true);
    try {
      await _remote.sendOtp(email: email);
      state = state.copyWith(loading: false);
    } catch (e) {
      state = state.copyWith(loading: false, error: ApiException.from(e).message);
    }
  }

  /// Étape 3 : vérification du code, émission des jetons.
  Future<void> verifyOtp(String code) async {
    final email = state.pendingEmail;
    if (email == null) return;
    state = state.copyWith(loading: true, clearError: true);
    try {
      final pair = await _remote.verifyOtp(email: email, code: code);
      await _tokens.save(access: pair.access, refresh: pair.refresh);
      state = state.copyWith(loading: false, status: AuthStatus.authenticated);
    } catch (e) {
      state = state.copyWith(loading: false, error: ApiException.from(e).message);
    }
  }

  Future<void> logout() async {
    try {
      await _remote.logout();
    } catch (_) {/* déconnexion locale quoi qu'il arrive */}
    await _tokens.clear();
    state = const AuthState(status: AuthStatus.unauthenticated);
  }

  void sessionExpired() => state = const AuthState(status: AuthStatus.unauthenticated);

  void backToLogin() => state = state.copyWith(status: AuthStatus.unauthenticated, clearError: true);
}
