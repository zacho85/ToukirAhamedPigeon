import 'package:dio/dio.dart';

import 'package:kogosso_app/core/network/network.dart';

/// Appels HTTP d'authentification (contrat : OpenAPI sandbox, tag « Auth »).
class AuthRemoteDataSource {
  AuthRemoteDataSource(this._dio);
  final Dio _dio;

  /// POST /auth/login — identifiant + mot de passe. Le serveur envoie lui-même
  /// le code OTP par email et répond {otp_required: true, email, ...}.
  Future<Map<String, dynamic>> login({required String identifier, required String password}) async {
    final res = await _dio.post('/auth/login', data: {'identifier': identifier, 'password': password});
    return _asMap(res.data);
  }

  /// POST /auth/send-otp — renvoi du code (le login l'envoie déjà la 1re fois).
  Future<void> sendOtp({required String email, String purpose = 'login'}) =>
      _dio.post('/auth/send-otp', data: {'email': email, 'purpose': purpose});

  /// POST /auth/verify-otp — étape 3 : le jeton d'accès n'est émis qu'ici.
  Future<TokenPair> verifyOtp({required String email, required String code, String purpose = 'login'}) async {
    final res = await _dio.post('/auth/verify-otp', data: {'email': email, 'code': code, 'purpose': purpose});
    final pair = TokenPair.fromJson(res.data);
    if (pair == null) {
      throw const ApiException('Réponse de connexion inattendue.');
    }
    return TokenPair(pair.access, ApiClient.refreshCookieFrom(res.headers));
  }

  Future<void> logout() => _dio.post('/auth/logout');

  Future<Map<String, dynamic>> me() async => _asMap((await _dio.get('/auth/me')).data);

  static Map<String, dynamic> _asMap(dynamic d) {
    if (d is Map) {
      final m = Map<String, dynamic>.from(d);
      if (m['data'] is Map) return Map<String, dynamic>.from(m['data'] as Map);
      return m;
    }
    return <String, dynamic>{};
  }
}
