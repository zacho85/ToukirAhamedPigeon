import 'history_entry_entity.dart';

class HistoryGroupEntity {
  final String label;
  final List<HistoryEntryEntity> entries;

  const HistoryGroupEntity({required this.label, required this.entries});
}
