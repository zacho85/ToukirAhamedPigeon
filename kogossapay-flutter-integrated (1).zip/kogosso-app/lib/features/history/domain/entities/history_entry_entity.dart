enum HistoryStatus { completed, pending, failed }

enum HistoryCategory { tontine, purchase, walletTopUp, transfer }

enum HistoryBadgeType { verified, error }

class HistoryEntryEntity {
  final String id;
  final String title;
  final String time;
  final double amount;
  final bool isCredit;
  final HistoryStatus status;
  final HistoryCategory category;
  final String? badgeLabel;
  final HistoryBadgeType? badgeType;

  const HistoryEntryEntity({
    required this.id,
    required this.title,
    required this.time,
    required this.amount,
    required this.isCredit,
    required this.status,
    required this.category,
    this.badgeLabel,
    this.badgeType,
  });
}
