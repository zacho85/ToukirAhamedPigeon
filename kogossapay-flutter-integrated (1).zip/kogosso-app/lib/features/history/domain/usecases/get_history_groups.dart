import '../entities/history_group_entity.dart';
import '../repositories/history_repository.dart';

class GetHistoryGroups {
  final HistoryRepository repository;

  const GetHistoryGroups(this.repository);

  Future<List<HistoryGroupEntity>> call() => repository.getHistoryGroups();
}
