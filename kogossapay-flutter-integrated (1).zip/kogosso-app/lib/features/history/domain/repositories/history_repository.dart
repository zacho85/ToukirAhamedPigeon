import '../entities/history_group_entity.dart';

abstract class HistoryRepository {
  Future<List<HistoryGroupEntity>> getHistoryGroups();
}
