enum HistoryStatusState { initial, loading, loaded, error }
