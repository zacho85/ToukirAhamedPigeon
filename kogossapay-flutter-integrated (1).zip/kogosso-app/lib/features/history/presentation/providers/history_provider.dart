import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/auth/presentation/providers/auth_provider.dart';

import 'package:kogosso_app/features/history/data/data.dart';
import 'package:kogosso_app/features/history/domain/domain.dart';

import 'history_state.dart';

export 'history_state.dart';

part 'history_provider.g.dart';

@riverpod
class History extends _$History {
  GetHistoryGroups get _getHistoryGroups =>
      GetHistoryGroups(HistoryRepositoryImpl(HistoryRemoteDataSource(ref.read(kongossaApiProvider))));

  @override
  HistoryState build() => const HistoryState();

  Future<void> load() async {
    state = state.copyWith(status: HistoryStatusState.loading);
    try {
      final groups = await _getHistoryGroups();
      state = state.copyWith(status: HistoryStatusState.loaded, groups: groups);
    } catch (_) {
      state = state.copyWith(status: HistoryStatusState.error);
    }
  }
}
