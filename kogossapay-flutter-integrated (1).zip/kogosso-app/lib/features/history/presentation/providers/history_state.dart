import 'package:kogosso_app/features/history/domain/domain.dart';

import 'history_status.dart';

export 'history_status.dart';

class HistoryState {
  final HistoryStatusState status;
  final List<HistoryGroupEntity> groups;

  const HistoryState({this.status = HistoryStatusState.initial, this.groups = const []});

  HistoryState copyWith({HistoryStatusState? status, List<HistoryGroupEntity>? groups}) {
    return HistoryState(status: status ?? this.status, groups: groups ?? this.groups);
  }
}
