import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/history/domain/domain.dart';

class HistoryGroupList extends StatelessWidget {
  final List<HistoryGroupEntity> groups;

  const HistoryGroupList({super.key, required this.groups});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (final group in groups) ...[
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Text(
              group.label,
              style: const TextStyle(
                fontFamily: 'Inter',
                fontWeight: FontWeight.w600,
                fontSize: 12,
                letterSpacing: 0.6,
                color: AppColors.greyText,
              ),
            ),
          ),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  offset: const Offset(0, 1),
                  blurRadius: 2,
                ),
              ],
            ),
            child: Column(
              children: [
                for (int i = 0; i < group.entries.length; i++) ...[
                  _HistoryEntryTile(entry: group.entries[i]),
                  if (i < group.entries.length - 1)
                    Container(height: 1, color: AppColors.divider),
                ],
              ],
            ),
          ),
          const SizedBox(height: 24),
        ],
      ],
    );
  }
}

class _HistoryEntryTile extends StatelessWidget {
  final HistoryEntryEntity entry;

  const _HistoryEntryTile({required this.entry});

  @override
  Widget build(BuildContext context) {
    final isFailed = entry.status == HistoryStatus.failed;
    final amountColor = isFailed
        ? AppColors.greyText
        : (entry.isCredit ? AppColors.primaryGreen : AppColors.errorRed);
    final sign = entry.isCredit ? '+' : '-';

    final categoryStyle = switch (entry.category) {
      HistoryCategory.tontine => (
        icon: AppIcons.salary,
        bgColor: AppColors.primaryGreen.withValues(alpha: 0.1),
        iconColor: AppColors.primaryGreen,
      ),
      HistoryCategory.purchase => (
        icon: AppIcons.purchase,
        bgColor: AppColors.errorRed.withValues(alpha: 0.1),
        iconColor: AppColors.errorRed,
      ),
      HistoryCategory.walletTopUp => (
        icon: AppIcons.deposit,
        bgColor: AppColors.darkNavy.withValues(alpha: 0.1),
        iconColor: AppColors.darkNavy,
      ),
      HistoryCategory.transfer => (
        icon: AppIcons.exchange,
        bgColor: AppColors.progressTrack,
        iconColor: AppColors.greyText,
      ),
    };

    return Opacity(
      opacity: isFailed ? 0.6 : 1,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: categoryStyle.bgColor,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Center(
                child: SvgPicture.asset(
                  categoryStyle.icon,
                  width: 22,
                  height: 22,
                  colorFilter: ColorFilter.mode(categoryStyle.iconColor, BlendMode.srcIn),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(entry.title, style: AppTextStyles.transactionTitle),
                  const SizedBox(height: 4),
                  Text(
                    isFailed ? entry.time : '${entry.time} • ${_statusLabel(entry.status)}',
                    style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                  ),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  '$sign${entry.amount.toStringAsFixed(0)} FCFA',
                  style: AppTextStyles.transactionAmount.copyWith(color: amountColor),
                ),
                if (entry.badgeLabel != null) ...[
                  const SizedBox(height: 4),
                  _StatusBadge(label: entry.badgeLabel!, type: entry.badgeType!),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }

  String _statusLabel(HistoryStatus status) => switch (status) {
    HistoryStatus.completed => 'Completed',
    HistoryStatus.pending => 'Pending',
    HistoryStatus.failed => 'Failed',
  };
}

class _StatusBadge extends StatelessWidget {
  final String label;
  final HistoryBadgeType type;

  const _StatusBadge({required this.label, required this.type});

  @override
  Widget build(BuildContext context) {
    final isVerified = type == HistoryBadgeType.verified;
    final bgColor = isVerified
        ? AppColors.primaryGreenLight.withValues(alpha: 0.3)
        : AppColors.errorRed.withValues(alpha: 0.1);
    final textColor = isVerified ? AppColors.primaryGreen : AppColors.errorRed;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(color: bgColor, borderRadius: BorderRadius.circular(9999)),
      child: Text(label, style: AppTextStyles.badge.copyWith(color: textColor, fontSize: 10)),
    );
  }
}
