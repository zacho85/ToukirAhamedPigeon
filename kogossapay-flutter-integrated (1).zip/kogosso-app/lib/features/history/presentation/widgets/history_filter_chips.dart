import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class HistoryFilterChips extends StatelessWidget {
  const HistoryFilterChips({super.key});

  static const _filters = [
    (icon: Icons.calendar_today_outlined, label: 'Date'),
    (icon: Icons.tune_rounded, label: 'Type'),
    (icon: Icons.check_circle_outline, label: 'Status'),
  ];

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        for (final filter in _filters) ...[
          _FilterChip(icon: filter.icon, label: filter.label),
          const SizedBox(width: 12),
        ],
      ],
    );
  }
}

class _FilterChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _FilterChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(9999),
        border: Border.all(color: Colors.grey.withValues(alpha: 0.15)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: AppColors.greyText),
          const SizedBox(width: 6),
          Text(
            label,
            style: const TextStyle(
              fontFamily: 'Inter',
              fontWeight: FontWeight.w500,
              fontSize: 13,
              color: AppColors.darkNavy,
            ),
          ),
        ],
      ),
    );
  }
}
