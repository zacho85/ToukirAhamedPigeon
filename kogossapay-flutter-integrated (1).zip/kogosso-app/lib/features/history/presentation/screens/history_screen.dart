import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/router/router.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/core/widgets/widgets.dart';

import '../providers/history_provider.dart';
import '../widgets/history_filter_chips.dart';
import '../widgets/history_group_list.dart';
import '../widgets/history_settings_toggle.dart';

class HistoryScreen extends ConsumerStatefulWidget {
  const HistoryScreen({super.key});

  @override
  ConsumerState<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends ConsumerState<HistoryScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(historyProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(historyProvider);

    if (state.status == HistoryStatusState.loading ||
        state.status == HistoryStatusState.initial) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: CircularProgressIndicator(color: AppColors.primaryGreen)),
      );
    }

    if (state.status == HistoryStatusState.error) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 96),
          child: Column(
            children: [
              const AppTopBar(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    HistorySettingsToggle(
                      onSettingsTap: () => context.go(AppRoutes.settings),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      'Transaction History',
                      style: TextStyle(
                        fontFamily: 'PlusJakartaSans',
                        fontWeight: FontWeight.w700,
                        fontSize: 24,
                        color: AppColors.darkNavy,
                      ),
                    ),
                    const SizedBox(height: 16),
                    const HistoryFilterChips(),
                    const SizedBox(height: 24),
                    HistoryGroupList(groups: state.groups),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
