import 'package:kogosso_app/features/history/domain/domain.dart';

import '../datasources/history_local_datasource.dart';

class HistoryRepositoryImpl implements HistoryRepository {
  final HistoryLocalDataSource localDataSource;

  const HistoryRepositoryImpl(this.localDataSource);

  @override
  Future<List<HistoryGroupEntity>> getHistoryGroups() =>
      localDataSource.fetchHistoryGroups();
}
