import 'package:kogosso_app/features/history/domain/domain.dart';

abstract class HistoryLocalDataSource {
  Future<List<HistoryGroupEntity>> fetchHistoryGroups();
}

class HistoryLocalDataSourceImpl implements HistoryLocalDataSource {
  @override
  Future<List<HistoryGroupEntity>> fetchHistoryGroups() async => const [
    HistoryGroupEntity(
      label: 'TODAY, OCT 24',
      entries: [
        HistoryEntryEntity(
          id: 'h1',
          title: 'Tontine Contribution',
          time: '4:30 PM',
          amount: 25000,
          isCredit: true,
          status: HistoryStatus.completed,
          category: HistoryCategory.tontine,
          badgeLabel: 'VERIFIED',
          badgeType: HistoryBadgeType.verified,
        ),
        HistoryEntryEntity(
          id: 'h2',
          title: 'Supermarket Purchase',
          time: '11:15 AM',
          amount: 12400,
          isCredit: false,
          status: HistoryStatus.completed,
          category: HistoryCategory.purchase,
        ),
      ],
    ),
    HistoryGroupEntity(
      label: 'YESTERDAY, OCT 23',
      entries: [
        HistoryEntryEntity(
          id: 'h3',
          title: 'Wallet Top-up',
          time: '09:00 AM',
          amount: 50000,
          isCredit: true,
          status: HistoryStatus.completed,
          category: HistoryCategory.walletTopUp,
        ),
        HistoryEntryEntity(
          id: 'h4',
          title: 'Transfer to Mom',
          time: 'Oct 23',
          amount: 5000,
          isCredit: false,
          status: HistoryStatus.failed,
          category: HistoryCategory.transfer,
          badgeLabel: 'SYSTEM ERROR',
          badgeType: HistoryBadgeType.error,
        ),
      ],
    ),
  ];
}
