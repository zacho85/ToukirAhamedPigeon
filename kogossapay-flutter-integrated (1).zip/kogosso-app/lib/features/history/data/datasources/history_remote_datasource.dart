import 'package:kogosso_app/core/network/network.dart';
import 'package:kogosso_app/core/utils/formatters.dart';
import 'package:kogosso_app/features/history/domain/domain.dart';

import 'history_local_datasource.dart';

/// Historique alimenté par POST /transactions/history (transactions de l'utilisateur).
class HistoryRemoteDataSource implements HistoryLocalDataSource {
  HistoryRemoteDataSource(this._api);
  final KongossaApi _api;

  @override
  Future<List<HistoryGroupEntity>> fetchHistoryGroups() async {
    final meId = parseNum((await _api.me())['id']);
    final txs = await _api.transactions(limit: 50);
    txs.sort((a, b) => (parseDate(b['createdAt']) ?? DateTime(1970)).compareTo(parseDate(a['createdAt']) ?? DateTime(1970)));

    final groups = <String, List<HistoryEntryEntity>>{};
    for (final t in txs) {
      final created = parseDate(t['createdAt']);
      final isCredit = parseNum(t['recipientId']) == meId;
      final status = switch (t['status']) {
        'completed' => HistoryStatus.completed,
        'failed' => HistoryStatus.failed,
        _ => HistoryStatus.pending,
      };
      final entry = HistoryEntryEntity(
        id: '${t['id']}',
        title: _title(t, isCredit),
        time: created == null ? '' : formatTime(created),
        amount: parseNum(t['amount']).toDouble(),
        isCredit: isCredit,
        status: status,
        category: _category(t['type'] as String? ?? ''),
        badgeLabel: status == HistoryStatus.failed ? 'FAILED' : null,
        badgeType: status == HistoryStatus.failed ? HistoryBadgeType.error : null,
      );
      (groups[created == null ? 'UNKNOWN DATE' : formatDayLabel(created)] ??= []).add(entry);
    }
    return [for (final e in groups.entries) HistoryGroupEntity(label: e.key, entries: e.value)];
  }

  static HistoryCategory _category(String type) {
    if (type.contains('topup')) return HistoryCategory.walletTopUp;
    if (type.contains('tontine') || type.contains('contribution')) return HistoryCategory.tontine;
    if (type.contains('payment_link') || type.contains('purchase') || type.contains('qr')) return HistoryCategory.purchase;
    return HistoryCategory.transfer;
  }

  static String _title(Map<String, dynamic> t, bool isCredit) {
    final d = t['description'];
    if (d is String && d.trim().isNotEmpty) return d;
    final other = (isCredit ? t['senderName'] : t['recipientName']) as String?;
    return other == null ? 'Transaction' : (isCredit ? 'From $other' : 'To $other');
  }
}
