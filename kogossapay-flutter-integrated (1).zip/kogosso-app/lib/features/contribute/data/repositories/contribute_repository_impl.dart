import 'package:kogosso_app/features/contribute/domain/domain.dart';

import '../datasources/contribute_local_datasource.dart';

class ContributeRepositoryImpl implements ContributeRepository {
  final ContributeLocalDataSource localDataSource;

  const ContributeRepositoryImpl(this.localDataSource);

  @override
  Future<ContributeOptionsEntity> getContributeOptions() =>
      localDataSource.fetchContributeOptions();
}
