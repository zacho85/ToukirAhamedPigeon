import 'package:kogosso_app/features/contribute/domain/domain.dart';

abstract class ContributeLocalDataSource {
  Future<ContributeOptionsEntity> fetchContributeOptions();
}

class ContributeLocalDataSourceImpl implements ContributeLocalDataSource {
  @override
  Future<ContributeOptionsEntity> fetchContributeOptions() async => const ContributeOptionsEntity(
    paymentMethods: [
      ContributionPaymentMethodEntity(
        id: 'main_wallet',
        title: 'Main Wallet',
        subtitle: 'Balance: FCFA 450,000',
        type: ContributionPaymentType.wallet,
      ),
      ContributionPaymentMethodEntity(
        id: 'mobile_money',
        title: 'Mobile Money',
        subtitle: 'Orange or MTN',
        type: ContributionPaymentType.mobileMoney,
      ),
    ],
    transactionFee: 0,
    payoutScheduleNote:
        'Your next expected payout date is October 15, 2023 if all contributions are met.',
  );
}
