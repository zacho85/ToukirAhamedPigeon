import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class ContributeSummaryCard extends StatelessWidget {
  final String circleTitle;
  final String badgeLabel;
  final double progress;
  final String progressLabel;
  final double scheduledAmount;

  const ContributeSummaryCard({
    super.key,
    required this.circleTitle,
    required this.badgeLabel,
    required this.progress,
    required this.progressLabel,
    required this.scheduledAmount,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: AppColors.balanceCardGradient,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Active Tontine',
                style: AppTextStyles.badge.copyWith(
                  color: Colors.white.withValues(alpha: 0.6),
                  letterSpacing: 0.3,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.primaryGreenLight.withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(9999),
                ),
                child: Text(
                  badgeLabel,
                  style: AppTextStyles.badge.copyWith(color: AppColors.primaryGreenLight, fontSize: 11),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            circleTitle,
            style: const TextStyle(
              fontFamily: 'PlusJakartaSans',
              fontWeight: FontWeight.w700,
              fontSize: 20,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Progress',
                style: AppTextStyles.badge.copyWith(
                  color: Colors.white.withValues(alpha: 0.6),
                  letterSpacing: 0,
                ),
              ),
              Text(
                progressLabel,
                style: AppTextStyles.badge.copyWith(color: AppColors.primaryGreenLight, letterSpacing: 0),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: progress.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: Colors.white.withValues(alpha: 0.15),
              valueColor: const AlwaysStoppedAnimation(AppColors.primaryGreenLight),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Scheduled Contribution',
                    style: AppTextStyles.badge.copyWith(
                      color: Colors.white.withValues(alpha: 0.6),
                      letterSpacing: 0,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${scheduledAmount.toStringAsFixed(0)} XAF',
                    style: const TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontWeight: FontWeight.w700,
                      fontSize: 18,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              // TODO: replace with the downloaded Figma info icon and hook up its action.
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: AppColors.goldLight.withValues(alpha: 0.3),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.info_outline_rounded, size: 14, color: AppColors.goldLight),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
