import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class AmountSelectorCard extends StatelessWidget {
  final double amount;
  final double defaultAmount;
  final ValueChanged<double> onChanged;

  const AmountSelectorCard({
    super.key,
    required this.amount,
    required this.defaultAmount,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Amount to contribute',
          style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.3),
        ),
        const SizedBox(height: 12),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.grey.withValues(alpha: 0.15)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                offset: const Offset(0, 1),
                blurRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.baseline,
                textBaseline: TextBaseline.alphabetic,
                children: [
                  Text(
                    amount.toStringAsFixed(0),
                    style: const TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontWeight: FontWeight.w700,
                      fontSize: 32,
                      color: AppColors.darkNavy,
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'XAF',
                    style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _AmountChip(
                    label: '+25k',
                    isActive: amount == defaultAmount + 25000,
                    onTap: () => onChanged(defaultAmount + 25000),
                  ),
                  const SizedBox(width: 8),
                  _AmountChip(
                    label: 'Default',
                    isActive: amount == defaultAmount,
                    onTap: () => onChanged(defaultAmount),
                  ),
                  const SizedBox(width: 8),
                  _AmountChip(
                    label: '+50k',
                    isActive: amount == defaultAmount + 50000,
                    onTap: () => onChanged(defaultAmount + 50000),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _AmountChip extends StatelessWidget {
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _AmountChip({required this.label, required this.isActive, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? AppColors.primaryGreen : AppColors.background,
          borderRadius: BorderRadius.circular(9999),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontFamily: 'Inter',
            fontWeight: FontWeight.w600,
            fontSize: 13,
            color: isActive ? Colors.white : AppColors.darkNavy,
          ),
        ),
      ),
    );
  }
}
