import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/contribute/domain/domain.dart';

class ContributePaymentMethodList extends StatelessWidget {
  final List<ContributionPaymentMethodEntity> methods;
  final String? selectedId;
  final ValueChanged<String> onSelect;

  const ContributePaymentMethodList({
    super.key,
    required this.methods,
    required this.selectedId,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Payment Method', style: AppTextStyles.sectionHeading),
            Text(
              'Change',
              style: AppTextStyles.quickActionLabel.copyWith(color: AppColors.primaryGreen),
            ),
          ],
        ),
        const SizedBox(height: 16),
        for (final method in methods) ...[
          _MethodTile(
            method: method,
            isSelected: method.id == selectedId,
            onTap: () => onSelect(method.id),
          ),
          const SizedBox(height: 12),
        ],
      ],
    );
  }
}

class _MethodTile extends StatelessWidget {
  final ContributionPaymentMethodEntity method;
  final bool isSelected;
  final VoidCallback onTap;

  const _MethodTile({required this.method, required this.isSelected, required this.onTap});

  // TODO: replace with the downloaded Figma payment-method icons.
  static const _icons = {
    ContributionPaymentType.wallet: Icons.account_balance_wallet_outlined,
    ContributionPaymentType.mobileMoney: Icons.phone_iphone_rounded,
  };

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppColors.primaryGreen : Colors.grey.withValues(alpha: 0.15),
            width: isSelected ? 1.5 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AppColors.primaryGreen.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(_icons[method.type], size: 18, color: AppColors.primaryGreen),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(method.title, style: AppTextStyles.transactionTitle.copyWith(fontSize: 14)),
                  const SizedBox(height: 2),
                  Text(
                    method.subtitle,
                    style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                  ),
                ],
              ),
            ),
            Icon(
              isSelected ? Icons.radio_button_checked : Icons.radio_button_off,
              size: 20,
              color: isSelected ? AppColors.primaryGreen : AppColors.greyText,
            ),
          ],
        ),
      ),
    );
  }
}
