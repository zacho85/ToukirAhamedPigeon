import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/theme/theme.dart';

import '../providers/contribute_provider.dart';
import '../widgets/amount_selector_card.dart';
import '../widgets/contribute_payment_method_list.dart';
import '../widgets/contribute_summary_card.dart';

/// Data passed via `extra` when routing to [ContributeScreen].
class ContributeRouteArgs {
  final String circleTitle;
  final String badgeLabel;
  final double progress;
  final String progressLabel;
  final double scheduledAmount;

  const ContributeRouteArgs({
    required this.circleTitle,
    required this.badgeLabel,
    required this.progress,
    required this.progressLabel,
    required this.scheduledAmount,
  });
}

class ContributeScreen extends ConsumerStatefulWidget {
  final String circleTitle;
  final String badgeLabel;
  final double progress;
  final String progressLabel;
  final double scheduledAmount;

  const ContributeScreen({
    super.key,
    required this.circleTitle,
    required this.badgeLabel,
    required this.progress,
    required this.progressLabel,
    required this.scheduledAmount,
  });

  @override
  ConsumerState<ContributeScreen> createState() => _ContributeScreenState();
}

class _ContributeScreenState extends ConsumerState<ContributeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(contributeProvider.notifier).load(widget.scheduledAmount);
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(contributeProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 18,
                      color: AppColors.darkNavy,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(child: Text('Contribute', style: AppTextStyles.appTitle)),
                  const Icon(Icons.notifications_outlined, size: 20, color: AppColors.darkNavy),
                  const SizedBox(width: 12),
                  Container(
                    width: 32,
                    height: 32,
                    decoration: const BoxDecoration(color: AppColors.darkNavy, shape: BoxShape.circle),
                    child: const Icon(Icons.person, size: 16, color: Colors.white),
                  ),
                ],
              ),
            ),
            Expanded(child: _buildBody(state)),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(ContributeState state) {
    if (state.status == ContributeStatus.loading || state.status == ContributeStatus.initial) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryGreen));
    }

    if (state.status == ContributeStatus.error || state.options == null) {
      return const Center(
        child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
      );
    }

    final options = state.options!;
    final notifier = ref.read(contributeProvider.notifier);

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ContributeSummaryCard(
            circleTitle: widget.circleTitle,
            badgeLabel: widget.badgeLabel,
            progress: widget.progress,
            progressLabel: widget.progressLabel,
            scheduledAmount: widget.scheduledAmount,
          ),
          const SizedBox(height: 28),
          AmountSelectorCard(
            amount: state.amount,
            defaultAmount: state.defaultAmount,
            onChanged: notifier.setAmount,
          ),
          const SizedBox(height: 28),
          ContributePaymentMethodList(
            methods: options.paymentMethods,
            selectedId: state.selectedMethodId,
            onSelect: notifier.selectPaymentMethod,
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Transaction Fee',
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
              ),
              Text(
                '${options.transactionFee.toStringAsFixed(0)} XAF',
                style: AppTextStyles.transactionTitle.copyWith(fontSize: 14),
              ),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                elevation: 0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Confirm Contribution',
                    style: AppTextStyles.transactionTitle.copyWith(color: Colors.white),
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.arrow_forward_rounded, size: 18, color: Colors.white),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.goldLight.withValues(alpha: 0.25),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(Icons.event_available_outlined, size: 18, color: AppColors.gold),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Payout Schedule',
                        style: AppTextStyles.transactionTitle.copyWith(fontSize: 13),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        options.payoutScheduleNote,
                        style: TextStyle(
                          fontFamily: 'Inter',
                          fontSize: 12,
                          height: 1.4,
                          color: AppColors.darkNavy.withValues(alpha: 0.7),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
