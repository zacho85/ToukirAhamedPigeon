import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/contribute/data/data.dart';
import 'package:kogosso_app/features/contribute/domain/domain.dart';

import 'contribute_state.dart';

export 'contribute_state.dart';

part 'contribute_provider.g.dart';

@riverpod
class Contribute extends _$Contribute {
  GetContributeOptions get _getContributeOptions =>
      GetContributeOptions(ContributeRepositoryImpl(ContributeLocalDataSourceImpl()));

  @override
  ContributeState build() => const ContributeState();

  Future<void> load(double scheduledAmount) async {
    state = state.copyWith(
      status: ContributeStatus.loading,
      defaultAmount: scheduledAmount,
      amount: scheduledAmount,
    );
    try {
      final options = await _getContributeOptions();
      state = state.copyWith(
        status: ContributeStatus.loaded,
        options: options,
        selectedMethodId: options.paymentMethods.first.id,
      );
    } catch (_) {
      state = state.copyWith(status: ContributeStatus.error);
    }
  }

  void setAmount(double value) {
    state = state.copyWith(amount: value);
  }

  void selectPaymentMethod(String id) {
    state = state.copyWith(selectedMethodId: id);
  }
}
