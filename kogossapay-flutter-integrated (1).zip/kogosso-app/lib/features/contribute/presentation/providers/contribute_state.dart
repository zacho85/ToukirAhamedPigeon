import 'package:kogosso_app/features/contribute/domain/domain.dart';

import 'contribute_status.dart';

export 'contribute_status.dart';

class ContributeState {
  final ContributeStatus status;
  final ContributeOptionsEntity? options;
  final double defaultAmount;
  final double amount;
  final String? selectedMethodId;

  const ContributeState({
    this.status = ContributeStatus.initial,
    this.options,
    this.defaultAmount = 0,
    this.amount = 0,
    this.selectedMethodId,
  });

  ContributeState copyWith({
    ContributeStatus? status,
    ContributeOptionsEntity? options,
    double? defaultAmount,
    double? amount,
    String? selectedMethodId,
  }) {
    return ContributeState(
      status: status ?? this.status,
      options: options ?? this.options,
      defaultAmount: defaultAmount ?? this.defaultAmount,
      amount: amount ?? this.amount,
      selectedMethodId: selectedMethodId ?? this.selectedMethodId,
    );
  }
}
