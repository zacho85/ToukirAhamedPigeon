// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contribute_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(Contribute)
final contributeProvider = ContributeProvider._();

final class ContributeProvider
    extends $NotifierProvider<Contribute, ContributeState> {
  ContributeProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'contributeProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$contributeHash();

  @$internal
  @override
  Contribute create() => Contribute();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ContributeState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ContributeState>(value),
    );
  }
}

String _$contributeHash() => r'6c2c7aeae6a336320a633a4908bf29bdc3c13549';

abstract class _$Contribute extends $Notifier<ContributeState> {
  ContributeState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<ContributeState, ContributeState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<ContributeState, ContributeState>,
              ContributeState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
