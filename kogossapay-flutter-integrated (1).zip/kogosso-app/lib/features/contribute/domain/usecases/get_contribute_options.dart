import '../entities/contribute_options_entity.dart';
import '../repositories/contribute_repository.dart';

class GetContributeOptions {
  final ContributeRepository repository;

  const GetContributeOptions(this.repository);

  Future<ContributeOptionsEntity> call() => repository.getContributeOptions();
}
