import 'contribution_payment_method_entity.dart';

class ContributeOptionsEntity {
  final List<ContributionPaymentMethodEntity> paymentMethods;
  final double transactionFee;
  final String payoutScheduleNote;

  const ContributeOptionsEntity({
    required this.paymentMethods,
    required this.transactionFee,
    required this.payoutScheduleNote,
  });
}
