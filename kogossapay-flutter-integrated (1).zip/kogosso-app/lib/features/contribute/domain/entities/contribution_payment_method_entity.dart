enum ContributionPaymentType { wallet, mobileMoney }

class ContributionPaymentMethodEntity {
  final String id;
  final String title;
  final String subtitle;
  final ContributionPaymentType type;

  const ContributionPaymentMethodEntity({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.type,
  });
}
