import '../entities/contribute_options_entity.dart';

abstract class ContributeRepository {
  Future<ContributeOptionsEntity> getContributeOptions();
}
