import '../entities/payment_method_entity.dart';

abstract class AddFundsRepository {
  Future<List<PaymentMethodEntity>> getPaymentMethods();
}
