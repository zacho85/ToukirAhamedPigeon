enum PaymentMethodType { mobileMoney, bankTransfer, cardPayment, nearbyAgent }

class PaymentMethodEntity {
  final String id;
  final String title;
  final String subtitle;
  final PaymentMethodType type;

  const PaymentMethodEntity({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.type,
  });
}
