import '../entities/payment_method_entity.dart';
import '../repositories/add_funds_repository.dart';

class GetPaymentMethods {
  final AddFundsRepository repository;

  const GetPaymentMethods(this.repository);

  Future<List<PaymentMethodEntity>> call() => repository.getPaymentMethods();
}
