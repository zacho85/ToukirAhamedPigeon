// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'add_funds_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(AddFunds)
final addFundsProvider = AddFundsProvider._();

final class AddFundsProvider
    extends $NotifierProvider<AddFunds, AddFundsState> {
  AddFundsProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'addFundsProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$addFundsHash();

  @$internal
  @override
  AddFunds create() => AddFunds();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AddFundsState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AddFundsState>(value),
    );
  }
}

String _$addFundsHash() => r'b360f417b5c54097a263373a61034c2d38665b2b';

abstract class _$AddFunds extends $Notifier<AddFundsState> {
  AddFundsState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<AddFundsState, AddFundsState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AddFundsState, AddFundsState>,
              AddFundsState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
