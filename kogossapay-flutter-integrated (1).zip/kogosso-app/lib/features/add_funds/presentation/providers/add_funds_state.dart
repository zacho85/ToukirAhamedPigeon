import 'package:kogosso_app/features/add_funds/domain/domain.dart';

import 'add_funds_status.dart';

export 'add_funds_status.dart';

class AddFundsState {
  final AddFundsStatus status;
  final List<PaymentMethodEntity> paymentMethods;

  const AddFundsState({this.status = AddFundsStatus.initial, this.paymentMethods = const []});

  AddFundsState copyWith({AddFundsStatus? status, List<PaymentMethodEntity>? paymentMethods}) {
    return AddFundsState(status: status ?? this.status, paymentMethods: paymentMethods ?? this.paymentMethods);
  }
}
