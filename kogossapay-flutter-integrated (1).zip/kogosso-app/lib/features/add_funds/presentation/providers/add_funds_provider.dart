import 'package:kogosso_app/features/add_funds/data/data.dart';
import 'package:kogosso_app/features/add_funds/domain/domain.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'add_funds_state.dart';

export 'add_funds_state.dart';

part 'add_funds_provider.g.dart';

@riverpod
class AddFunds extends _$AddFunds {
  GetPaymentMethods get _getPaymentMethods => GetPaymentMethods(AddFundsRepositoryImpl(AddFundsLocalDataSourceImpl()));

  @override
  AddFundsState build() => const AddFundsState();

  Future<void> load() async {
    state = state.copyWith(status: AddFundsStatus.loading);
    try {
      final paymentMethods = await _getPaymentMethods();
      state = state.copyWith(status: AddFundsStatus.loaded, paymentMethods: paymentMethods);
    } catch (_) {
      state = state.copyWith(status: AddFundsStatus.error);
    }
  }
}
