enum AddFundsStatus { initial, loading, loaded, error }
