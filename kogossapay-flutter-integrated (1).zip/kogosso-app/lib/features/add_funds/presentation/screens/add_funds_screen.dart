import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/theme/theme.dart';

import '../providers/add_funds_provider.dart';
import '../widgets/payment_method_list.dart';

class AddFundsScreen extends ConsumerStatefulWidget {
  const AddFundsScreen({super.key});

  @override
  ConsumerState<AddFundsScreen> createState() => _AddFundsScreenState();
}

class _AddFundsScreenState extends ConsumerState<AddFundsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(addFundsProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(addFundsProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: const Icon(Icons.arrow_back_ios_new_rounded, size: 18, color: AppColors.darkNavy),
                  ),
                  const SizedBox(width: 16),
                  const Expanded(child: Text('KongossoPay', style: AppTextStyles.appTitle)),
                  // TODO: replace with the downloaded Figma security-status icons.
                  Container(
                    width: 28,
                    height: 28,
                    decoration: BoxDecoration(
                      color: AppColors.primaryGreenLight.withValues(alpha: 0.3),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.verified_user_outlined, size: 14, color: AppColors.primaryGreen),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    width: 28,
                    height: 28,
                    decoration: const BoxDecoration(color: AppColors.darkNavy, shape: BoxShape.circle),
                    child: const Icon(Icons.person, size: 14, color: Colors.white),
                  ),
                ],
              ),
            ),
            Expanded(child: _buildBody(state)),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(AddFundsState state) {
    if (state.status == AddFundsStatus.loading || state.status == AddFundsStatus.initial) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryGreen));
    }

    if (state.status == AddFundsStatus.error) {
      return const Center(
        child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Add Funds',
            style: TextStyle(
              fontFamily: 'PlusJakartaSans',
              fontWeight: FontWeight.w700,
              fontSize: 24,
              color: AppColors.darkNavy,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Select your preferred secure payment method.',
            style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
          ),
          const SizedBox(height: 24),
          PaymentMethodList(methods: state.paymentMethods),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock_outline_rounded, size: 14, color: AppColors.greyText),
              const SizedBox(width: 6),
              Text(
                'Secured by 256-bit AES Encryption',
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
