import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/add_funds/domain/domain.dart';

class PaymentMethodList extends StatelessWidget {
  final List<PaymentMethodEntity> methods;

  const PaymentMethodList({super.key, required this.methods});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        for (final method in methods) ...[_PaymentMethodTile(method: method), const SizedBox(height: 16)],
      ],
    );
  }
}

class _PaymentMethodTile extends StatelessWidget {
  final PaymentMethodEntity method;

  const _PaymentMethodTile({required this.method});

  // TODO: replace with the downloaded Figma payment-method icons.
  static const _styles = {
    PaymentMethodType.mobileMoney: (icon: Icons.phone_iphone_rounded, color: AppColors.primaryGreen),
    PaymentMethodType.bankTransfer: (icon: Icons.account_balance_outlined, color: AppColors.darkNavy),
    PaymentMethodType.cardPayment: (icon: Icons.credit_card_rounded, color: AppColors.gold),
    PaymentMethodType.nearbyAgent: (icon: Icons.storefront_outlined, color: AppColors.primaryGreen),
  };

  @override
  Widget build(BuildContext context) {
    final style = _styles[method.type]!;

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.05), offset: const Offset(0, 1), blurRadius: 2)],
      ),
      child: InkWell(
        onTap: () {},
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: style.color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(style.icon, size: 20, color: style.color),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(method.title, style: AppTextStyles.transactionTitle),
                    const SizedBox(height: 4),
                    Text(method.subtitle, style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0)),
                  ],
                ),
              ),
              const Icon(Icons.chevron_right, size: 18, color: AppColors.greyText),
            ],
          ),
        ),
      ),
    );
  }
}
