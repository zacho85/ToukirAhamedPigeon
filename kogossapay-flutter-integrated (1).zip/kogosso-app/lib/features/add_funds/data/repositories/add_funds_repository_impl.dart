import 'package:kogosso_app/features/add_funds/domain/domain.dart';

import '../datasources/add_funds_local_datasource.dart';

class AddFundsRepositoryImpl implements AddFundsRepository {
  final AddFundsLocalDataSource localDataSource;

  const AddFundsRepositoryImpl(this.localDataSource);

  @override
  Future<List<PaymentMethodEntity>> getPaymentMethods() => localDataSource.fetchPaymentMethods();
}
