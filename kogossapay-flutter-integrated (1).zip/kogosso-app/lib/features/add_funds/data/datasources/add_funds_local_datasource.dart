import 'package:kogosso_app/features/add_funds/domain/domain.dart';

abstract class AddFundsLocalDataSource {
  Future<List<PaymentMethodEntity>> fetchPaymentMethods();
}

class AddFundsLocalDataSourceImpl implements AddFundsLocalDataSource {
  @override
  Future<List<PaymentMethodEntity>> fetchPaymentMethods() async => const [
    PaymentMethodEntity(
      id: 'mobile_money',
      title: 'Mobile Money',
      subtitle: 'Instant • Fee: 0.5%',
      type: PaymentMethodType.mobileMoney,
    ),
    PaymentMethodEntity(
      id: 'bank_transfer',
      title: 'Bank Transfer',
      subtitle: '1-2 Hours • Fee: Free',
      type: PaymentMethodType.bankTransfer,
    ),
    PaymentMethodEntity(
      id: 'card_payment',
      title: 'Card Payment',
      subtitle: 'Instant • Fee: 1.2%',
      type: PaymentMethodType.cardPayment,
    ),
    PaymentMethodEntity(
      id: 'nearby_agent',
      title: 'Nearby Agent',
      subtitle: 'Local Cash • Fee: Free',
      type: PaymentMethodType.nearbyAgent,
    ),
  ];
}
