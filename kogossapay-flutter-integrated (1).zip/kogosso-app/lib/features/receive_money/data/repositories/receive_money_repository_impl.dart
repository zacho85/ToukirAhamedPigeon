import 'package:kogosso_app/features/receive_money/domain/domain.dart';

import '../datasources/receive_money_local_datasource.dart';

class ReceiveMoneyRepositoryImpl implements ReceiveMoneyRepository {
  final ReceiveMoneyLocalDataSource localDataSource;

  const ReceiveMoneyRepositoryImpl(this.localDataSource);

  @override
  Future<WalletEntity> getWallet() => localDataSource.fetchWallet();
}
