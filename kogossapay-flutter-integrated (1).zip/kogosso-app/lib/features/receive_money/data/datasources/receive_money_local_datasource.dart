import 'package:kogosso_app/features/receive_money/domain/domain.dart';

abstract class ReceiveMoneyLocalDataSource {
  Future<WalletEntity> fetchWallet();
}

class ReceiveMoneyLocalDataSourceImpl implements ReceiveMoneyLocalDataSource {
  @override
  Future<WalletEntity> fetchWallet() async =>
      const WalletEntity(address: 'KP-7742-9901-XL01', isVerified: true);
}
