import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/theme/theme.dart';

import '../providers/receive_money_provider.dart';
import '../widgets/amount_request_card.dart';
import '../widgets/wallet_address_row.dart';
import '../widgets/wallet_qr_card.dart';

class ReceiveMoneyScreen extends ConsumerStatefulWidget {
  const ReceiveMoneyScreen({super.key});

  @override
  ConsumerState<ReceiveMoneyScreen> createState() => _ReceiveMoneyScreenState();
}

class _ReceiveMoneyScreenState extends ConsumerState<ReceiveMoneyScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(receiveMoneyProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(receiveMoneyProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 18,
                      color: AppColors.darkNavy,
                    ),
                  ),
                  const SizedBox(width: 12),
                  const Expanded(child: Text('Receive Money', style: AppTextStyles.appTitle)),
                  // TODO: replace with the downloaded Figma info/help icon and hook up its action.
                  const Icon(Icons.info_outline_rounded, size: 20, color: AppColors.greyText),
                  const SizedBox(width: 12),
                  Container(
                    width: 32,
                    height: 32,
                    decoration: const BoxDecoration(color: AppColors.darkNavy, shape: BoxShape.circle),
                    child: const Icon(Icons.person, size: 16, color: Colors.white),
                  ),
                ],
              ),
            ),
            Expanded(child: _buildBody(state)),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(ReceiveMoneyState state) {
    if (state.status == ReceiveMoneyStatus.loading || state.status == ReceiveMoneyStatus.initial) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryGreen));
    }

    if (state.status == ReceiveMoneyStatus.error || state.wallet == null) {
      return const Center(
        child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
      );
    }

    final wallet = state.wallet!;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      child: Column(
        children: [
          WalletQrCard(isVerified: wallet.isVerified),
          WalletAddressRow(address: wallet.address),
          const SizedBox(height: 32),
          AmountRequestCard(onChanged: ref.read(receiveMoneyProvider.notifier).setRequestedAmount),
          const SizedBox(height: 24),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryGreen,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                elevation: 0,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.ios_share_rounded, size: 18),
                  const SizedBox(width: 8),
                  Text(
                    'Share Payment Link',
                    style: AppTextStyles.transactionTitle.copyWith(color: Colors.white),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text(
            'Send this link to anyone. They can pay via KongossaPay, bank transfer, or card.',
            textAlign: TextAlign.center,
            style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
          ),
        ],
      ),
    );
  }
}
