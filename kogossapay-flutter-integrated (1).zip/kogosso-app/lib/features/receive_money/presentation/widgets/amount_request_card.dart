import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class AmountRequestCard extends StatefulWidget {
  final ValueChanged<double> onChanged;

  const AmountRequestCard({super.key, required this.onChanged});

  @override
  State<AmountRequestCard> createState() => _AmountRequestCardState();
}

class _AmountRequestCardState extends State<AmountRequestCard> {
  final _controller = TextEditingController(text: '0.00');

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Request Specific Amount', style: AppTextStyles.sectionHeading),
        const SizedBox(height: 16),
        Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(vertical: 20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.grey.withValues(alpha: 0.15)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                offset: const Offset(0, 1),
                blurRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              Text(
                'AMOUNT TO RECEIVE',
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.3),
              ),
              const SizedBox(height: 8),
              IntrinsicWidth(
                child: TextField(
                  controller: _controller,
                  textAlign: TextAlign.center,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  style: const TextStyle(
                    fontFamily: 'PlusJakartaSans',
                    fontWeight: FontWeight.w700,
                    fontSize: 36,
                    color: AppColors.darkNavy,
                  ),
                  decoration: const InputDecoration(
                    prefixText: r'$',
                    prefixStyle: TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontWeight: FontWeight.w700,
                      fontSize: 36,
                      color: AppColors.darkNavy,
                    ),
                    border: InputBorder.none,
                    isDense: true,
                  ),
                  onChanged: (value) => widget.onChanged(double.tryParse(value) ?? 0),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
