import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class WalletQrCard extends StatelessWidget {
  final bool isVerified;

  const WalletQrCard({super.key, required this.isVerified});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                offset: const Offset(0, 1),
                blurRadius: 2,
              ),
            ],
          ),
          child: Stack(
            clipBehavior: Clip.none,
            alignment: Alignment.center,
            children: [
              // TODO: replace with a real QR code (e.g. qr_flutter) encoding the wallet address.
              AspectRatio(aspectRatio: 1, child: _QrPlaceholder()),
              if (isVerified)
                Positioned(
                  bottom: -16,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                    decoration: BoxDecoration(
                      color: AppColors.darkNavy,
                      borderRadius: BorderRadius.circular(9999),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withValues(alpha: 0.15),
                          blurRadius: 8,
                          offset: const Offset(0, 2),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.verified, size: 14, color: AppColors.primaryGreenLight),
                        const SizedBox(width: 6),
                        Text(
                          'Verified Wallet',
                          style: AppTextStyles.badge.copyWith(
                            color: Colors.white,
                            fontSize: 11,
                            letterSpacing: 0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 24),
      ],
    );
  }
}

class _QrPlaceholder extends StatelessWidget {
  const _QrPlaceholder();

  static const _pattern = [
    [1, 1, 1, 0, 1, 0, 1, 1, 1],
    [1, 0, 1, 0, 0, 1, 0, 0, 1],
    [1, 0, 1, 1, 1, 0, 1, 0, 1],
    [0, 0, 0, 0, 1, 1, 0, 1, 0],
    [1, 1, 0, 1, 0, 0, 1, 0, 1],
    [0, 1, 1, 0, 1, 1, 0, 1, 0],
    [1, 0, 1, 0, 0, 1, 1, 0, 1],
    [0, 0, 1, 1, 1, 0, 0, 1, 0],
    [1, 1, 0, 0, 1, 1, 1, 0, 1],
  ];

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: EdgeInsets.zero,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: _pattern.length * _pattern.first.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: _pattern.first.length),
      itemBuilder: (context, index) {
        final row = index ~/ _pattern.first.length;
        final col = index % _pattern.first.length;
        final isFilled = _pattern[row][col] == 1;
        return Padding(
          padding: const EdgeInsets.all(1.5),
          child: Container(
            decoration: BoxDecoration(
              color: isFilled ? AppColors.darkNavy : Colors.transparent,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        );
      },
    );
  }
}
