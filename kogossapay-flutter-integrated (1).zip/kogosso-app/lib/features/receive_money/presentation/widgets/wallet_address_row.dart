import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class WalletAddressRow extends StatelessWidget {
  final String address;

  const WalletAddressRow({super.key, required this.address});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'Your Wallet Address',
          style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.3),
        ),
        const SizedBox(height: 8),
        GestureDetector(
          onTap: () async {
            await Clipboard.setData(ClipboardData(text: address));
            if (context.mounted) {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Wallet address copied')),
              );
            }
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(9999),
              border: Border.all(color: Colors.grey.withValues(alpha: 0.15)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  address,
                  style: const TextStyle(
                    fontFamily: 'LiberationMono',
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                    letterSpacing: 1.2,
                    color: AppColors.darkNavy,
                  ),
                ),
                const SizedBox(width: 8),
                const Icon(Icons.copy_rounded, size: 16, color: AppColors.greyText),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
