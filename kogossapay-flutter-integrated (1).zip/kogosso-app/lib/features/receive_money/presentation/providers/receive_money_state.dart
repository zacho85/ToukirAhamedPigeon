import 'package:kogosso_app/features/receive_money/domain/domain.dart';

import 'receive_money_status.dart';

export 'receive_money_status.dart';

class ReceiveMoneyState {
  final ReceiveMoneyStatus status;
  final WalletEntity? wallet;
  final double requestedAmount;

  const ReceiveMoneyState({
    this.status = ReceiveMoneyStatus.initial,
    this.wallet,
    this.requestedAmount = 0,
  });

  ReceiveMoneyState copyWith({
    ReceiveMoneyStatus? status,
    WalletEntity? wallet,
    double? requestedAmount,
  }) {
    return ReceiveMoneyState(
      status: status ?? this.status,
      wallet: wallet ?? this.wallet,
      requestedAmount: requestedAmount ?? this.requestedAmount,
    );
  }
}
