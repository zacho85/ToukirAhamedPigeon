// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'receive_money_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(ReceiveMoney)
final receiveMoneyProvider = ReceiveMoneyProvider._();

final class ReceiveMoneyProvider
    extends $NotifierProvider<ReceiveMoney, ReceiveMoneyState> {
  ReceiveMoneyProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'receiveMoneyProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$receiveMoneyHash();

  @$internal
  @override
  ReceiveMoney create() => ReceiveMoney();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ReceiveMoneyState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ReceiveMoneyState>(value),
    );
  }
}

String _$receiveMoneyHash() => r'cf1618a95373e671e121769a6be2eee3783e6773';

abstract class _$ReceiveMoney extends $Notifier<ReceiveMoneyState> {
  ReceiveMoneyState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<ReceiveMoneyState, ReceiveMoneyState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<ReceiveMoneyState, ReceiveMoneyState>,
              ReceiveMoneyState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
