import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/receive_money/data/data.dart';
import 'package:kogosso_app/features/receive_money/domain/domain.dart';

import 'receive_money_state.dart';

export 'receive_money_state.dart';

part 'receive_money_provider.g.dart';

@riverpod
class ReceiveMoney extends _$ReceiveMoney {
  GetWallet get _getWallet =>
      GetWallet(ReceiveMoneyRepositoryImpl(ReceiveMoneyLocalDataSourceImpl()));

  @override
  ReceiveMoneyState build() => const ReceiveMoneyState();

  Future<void> load() async {
    state = state.copyWith(status: ReceiveMoneyStatus.loading);
    try {
      final wallet = await _getWallet();
      state = state.copyWith(status: ReceiveMoneyStatus.loaded, wallet: wallet);
    } catch (_) {
      state = state.copyWith(status: ReceiveMoneyStatus.error);
    }
  }

  void setRequestedAmount(double amount) {
    state = state.copyWith(requestedAmount: amount);
  }
}
