enum ReceiveMoneyStatus { initial, loading, loaded, error }
