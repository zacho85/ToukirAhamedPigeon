import '../entities/wallet_entity.dart';

abstract class ReceiveMoneyRepository {
  Future<WalletEntity> getWallet();
}
