class WalletEntity {
  final String address;
  final bool isVerified;

  const WalletEntity({required this.address, required this.isVerified});
}
