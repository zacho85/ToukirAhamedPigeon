import '../entities/wallet_entity.dart';
import '../repositories/receive_money_repository.dart';

class GetWallet {
  final ReceiveMoneyRepository repository;

  const GetWallet(this.repository);

  Future<WalletEntity> call() => repository.getWallet();
}
