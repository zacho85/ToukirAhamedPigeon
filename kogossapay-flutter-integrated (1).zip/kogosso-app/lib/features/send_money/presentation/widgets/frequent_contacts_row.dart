import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/send_money/domain/domain.dart';

class FrequentContactsRow extends StatelessWidget {
  final List<ContactEntity> contacts;

  const FrequentContactsRow({super.key, required this.contacts});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 84,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: contacts.length,
        separatorBuilder: (_, _) => const SizedBox(width: 16),
        itemBuilder: (context, index) => _ContactItem(contact: contacts[index]),
      ),
    );
  }
}

class _ContactItem extends StatelessWidget {
  final ContactEntity contact;

  const _ContactItem({required this.contact});

  @override
  Widget build(BuildContext context) {
    final color = AppColors.avatarPalette[contact.colorIndex % AppColors.avatarPalette.length];

    return Column(
      children: [
        // TODO: replace with the downloaded Figma contact photo (contact.avatarAsset).
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: contact.isAddNew ? Colors.transparent : color,
            border: contact.isAddNew
                ? Border.all(color: AppColors.greyText.withValues(alpha: 0.4), width: 1.5)
                : null,
          ),
          child: Center(
            child: contact.isAddNew
                ? const Icon(Icons.person_add_alt_1_outlined, size: 20, color: AppColors.greyText)
                : Text(
                    contact.initials,
                    style: const TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      color: Colors.white,
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 8),
        Text(
          contact.name,
          style: AppTextStyles.badge.copyWith(color: AppColors.darkNavy, letterSpacing: 0, fontSize: 11),
        ),
      ],
    );
  }
}
