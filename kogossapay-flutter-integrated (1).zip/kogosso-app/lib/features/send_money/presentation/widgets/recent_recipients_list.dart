import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/send_money/domain/domain.dart';

class RecentRecipientsList extends StatelessWidget {
  final List<RecentRecipientEntity> recipients;

  const RecentRecipientsList({super.key, required this.recipients});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Column(
        children: [
          for (int i = 0; i < recipients.length; i++) ...[
            _RecipientTile(recipient: recipients[i]),
            if (i < recipients.length - 1) Container(height: 1, color: AppColors.divider),
          ],
        ],
      ),
    );
  }
}

class _RecipientTile extends StatelessWidget {
  final RecentRecipientEntity recipient;

  const _RecipientTile({required this.recipient});

  @override
  Widget build(BuildContext context) {
    final color = AppColors.avatarPalette[recipient.colorIndex % AppColors.avatarPalette.length];

    return InkWell(
      onTap: () {},
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            // TODO: replace with the downloaded Figma contact photo.
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              child: Center(
                child: Text(
                  recipient.initials,
                  style: const TextStyle(
                    fontFamily: 'PlusJakartaSans',
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                    color: Colors.white,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(recipient.name, style: AppTextStyles.transactionTitle),
                  const SizedBox(height: 4),
                  Text(
                    recipient.lastSentLabel,
                    style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, size: 18, color: AppColors.greyText),
          ],
        ),
      ),
    );
  }
}
