import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/send_money/data/data.dart';
import 'package:kogosso_app/features/send_money/domain/domain.dart';

import 'send_money_state.dart';

export 'send_money_state.dart';

part 'send_money_provider.g.dart';

@riverpod
class SendMoney extends _$SendMoney {
  GetSendMoneyData get _getSendMoneyData =>
      GetSendMoneyData(SendMoneyRepositoryImpl(SendMoneyLocalDataSourceImpl()));

  @override
  SendMoneyState build() => const SendMoneyState();

  Future<void> load() async {
    state = state.copyWith(status: SendMoneyStatus.loading);
    try {
      final data = await _getSendMoneyData();
      state = state.copyWith(
        status: SendMoneyStatus.loaded,
        frequentContacts: data.frequentContacts,
        recentRecipients: data.recentRecipients,
      );
    } catch (_) {
      state = state.copyWith(status: SendMoneyStatus.error);
    }
  }

  void setQuery(String query) {
    state = state.copyWith(query: query.trim().toLowerCase());
  }
}
