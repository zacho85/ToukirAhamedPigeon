enum SendMoneyStatus { initial, loading, loaded, error }
