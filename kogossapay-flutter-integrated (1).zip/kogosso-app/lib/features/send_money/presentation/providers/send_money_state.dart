import 'package:kogosso_app/features/send_money/domain/domain.dart';

import 'send_money_status.dart';

export 'send_money_status.dart';

class SendMoneyState {
  final SendMoneyStatus status;
  final List<ContactEntity> frequentContacts;
  final List<RecentRecipientEntity> recentRecipients;
  final String query;

  const SendMoneyState({
    this.status = SendMoneyStatus.initial,
    this.frequentContacts = const [],
    this.recentRecipients = const [],
    this.query = '',
  });

  List<ContactEntity> get filteredFrequentContacts => frequentContacts
      .where((c) => c.isAddNew || c.name.toLowerCase().contains(query))
      .toList();

  List<RecentRecipientEntity> get filteredRecentRecipients =>
      recentRecipients.where((r) => r.name.toLowerCase().contains(query)).toList();

  SendMoneyState copyWith({
    SendMoneyStatus? status,
    List<ContactEntity>? frequentContacts,
    List<RecentRecipientEntity>? recentRecipients,
    String? query,
  }) {
    return SendMoneyState(
      status: status ?? this.status,
      frequentContacts: frequentContacts ?? this.frequentContacts,
      recentRecipients: recentRecipients ?? this.recentRecipients,
      query: query ?? this.query,
    );
  }
}
