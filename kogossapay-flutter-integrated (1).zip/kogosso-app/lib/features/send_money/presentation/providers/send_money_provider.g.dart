// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'send_money_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(SendMoney)
final sendMoneyProvider = SendMoneyProvider._();

final class SendMoneyProvider
    extends $NotifierProvider<SendMoney, SendMoneyState> {
  SendMoneyProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'sendMoneyProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$sendMoneyHash();

  @$internal
  @override
  SendMoney create() => SendMoney();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(SendMoneyState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<SendMoneyState>(value),
    );
  }
}

String _$sendMoneyHash() => r'e9e740797371194fb13fd839ee304d4ac82ebf80';

abstract class _$SendMoney extends $Notifier<SendMoneyState> {
  SendMoneyState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<SendMoneyState, SendMoneyState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<SendMoneyState, SendMoneyState>,
              SendMoneyState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
