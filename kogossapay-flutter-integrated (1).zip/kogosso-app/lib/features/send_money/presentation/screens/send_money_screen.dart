import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/theme/theme.dart';

import '../providers/send_money_provider.dart';
import '../widgets/frequent_contacts_row.dart';
import '../widgets/recent_recipients_list.dart';

class SendMoneyScreen extends ConsumerStatefulWidget {
  const SendMoneyScreen({super.key});

  @override
  ConsumerState<SendMoneyScreen> createState() => _SendMoneyScreenState();
}

class _SendMoneyScreenState extends ConsumerState<SendMoneyScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final notifier = ref.read(sendMoneyProvider.notifier);
      notifier.setQuery('');
      notifier.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(sendMoneyProvider);
    final notifier = ref.read(sendMoneyProvider.notifier);

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Align(
                    alignment: Alignment.centerLeft,
                    child: GestureDetector(
                      onTap: () => context.pop(),
                      child: const Icon(Icons.close_rounded, size: 24, color: AppColors.darkNavy),
                    ),
                  ),
                  const Text(
                    'Send Money',
                    style: TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontWeight: FontWeight.w700,
                      fontSize: 18,
                      color: AppColors.darkNavy,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(child: _buildBody(state, notifier)),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(SendMoneyState state, SendMoney notifier) {
    if (state.status == SendMoneyStatus.loading || state.status == SendMoneyStatus.initial) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryGreen));
    }

    if (state.status == SendMoneyStatus.error) {
      return const Center(
        child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'SEARCH RECIPIENT',
            style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.6),
          ),
          const SizedBox(height: 12),
          TextField(
            onChanged: notifier.setQuery,
            decoration: InputDecoration(
              hintText: 'Name, username, or phone',
              hintStyle: AppTextStyles.quickActionLabel,
              prefixIcon: const Icon(Icons.search, size: 20, color: AppColors.greyText),
              filled: true,
              fillColor: AppColors.background,
              contentPadding: const EdgeInsets.symmetric(vertical: 14),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 28),
          Text(
            'FREQUENT CONTACTS',
            style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.6),
          ),
          const SizedBox(height: 16),
          FrequentContactsRow(contacts: state.filteredFrequentContacts),
          const SizedBox(height: 28),
          Text(
            'RECENT TRANSACTIONS',
            style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.6),
          ),
          const SizedBox(height: 16),
          RecentRecipientsList(recipients: state.filteredRecentRecipients),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
