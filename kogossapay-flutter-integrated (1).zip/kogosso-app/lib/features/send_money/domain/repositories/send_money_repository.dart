import '../entities/contact_entity.dart';
import '../entities/recent_recipient_entity.dart';

abstract class SendMoneyRepository {
  Future<List<ContactEntity>> getFrequentContacts();
  Future<List<RecentRecipientEntity>> getRecentRecipients();
}
