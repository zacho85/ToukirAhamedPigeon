class ContactEntity {
  final String id;
  final String name;
  final String initials;
  final int colorIndex;
  final bool isAddNew;

  // TODO: replace with the downloaded Figma contact photo (asset path) once available.
  final String? avatarAsset;

  const ContactEntity({
    required this.id,
    required this.name,
    required this.initials,
    required this.colorIndex,
    this.isAddNew = false,
    this.avatarAsset,
  });
}
