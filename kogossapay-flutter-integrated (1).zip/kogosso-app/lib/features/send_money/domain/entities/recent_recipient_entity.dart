class RecentRecipientEntity {
  final String id;
  final String name;
  final String initials;
  final int colorIndex;
  final String lastSentLabel;

  const RecentRecipientEntity({
    required this.id,
    required this.name,
    required this.initials,
    required this.colorIndex,
    required this.lastSentLabel,
  });
}
