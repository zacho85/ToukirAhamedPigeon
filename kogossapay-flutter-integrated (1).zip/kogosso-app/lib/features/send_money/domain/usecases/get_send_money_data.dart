import '../entities/contact_entity.dart';
import '../entities/recent_recipient_entity.dart';
import '../repositories/send_money_repository.dart';

class SendMoneyData {
  final List<ContactEntity> frequentContacts;
  final List<RecentRecipientEntity> recentRecipients;

  const SendMoneyData({required this.frequentContacts, required this.recentRecipients});
}

class GetSendMoneyData {
  final SendMoneyRepository repository;

  const GetSendMoneyData(this.repository);

  Future<SendMoneyData> call() async {
    final results = await Future.wait([
      repository.getFrequentContacts(),
      repository.getRecentRecipients(),
    ]);

    return SendMoneyData(
      frequentContacts: results[0] as List<ContactEntity>,
      recentRecipients: results[1] as List<RecentRecipientEntity>,
    );
  }
}
