import 'package:kogosso_app/features/send_money/domain/domain.dart';

import '../datasources/send_money_local_datasource.dart';

class SendMoneyRepositoryImpl implements SendMoneyRepository {
  final SendMoneyLocalDataSource localDataSource;

  const SendMoneyRepositoryImpl(this.localDataSource);

  @override
  Future<List<ContactEntity>> getFrequentContacts() => localDataSource.fetchFrequentContacts();

  @override
  Future<List<RecentRecipientEntity>> getRecentRecipients() =>
      localDataSource.fetchRecentRecipients();
}
