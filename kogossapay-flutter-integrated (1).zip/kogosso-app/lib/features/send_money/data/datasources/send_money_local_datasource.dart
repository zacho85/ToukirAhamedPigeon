import 'package:kogosso_app/features/send_money/domain/domain.dart';

abstract class SendMoneyLocalDataSource {
  Future<List<ContactEntity>> fetchFrequentContacts();
  Future<List<RecentRecipientEntity>> fetchRecentRecipients();
}

class SendMoneyLocalDataSourceImpl implements SendMoneyLocalDataSource {
  // TODO: swap the initials/color placeholders below for the real contact
  // photos once they're downloaded from Figma (see AppIcons for the pattern).
  @override
  Future<List<ContactEntity>> fetchFrequentContacts() async => const [
    ContactEntity(id: 'sarah', name: 'Sarah J.', initials: 'SJ', colorIndex: 0),
    ContactEntity(id: 'marcus', name: 'Marcus C.', initials: 'MC', colorIndex: 1),
    ContactEntity(id: 'elena', name: 'Elena R.', initials: 'ER', colorIndex: 2),
    ContactEntity(id: 'new', name: 'New', initials: '', colorIndex: 3, isAddNew: true),
  ];

  @override
  Future<List<RecentRecipientEntity>> fetchRecentRecipients() async => const [
    RecentRecipientEntity(
      id: 'amina',
      name: 'Amina Bakari',
      initials: 'AB',
      colorIndex: 0,
      lastSentLabel: 'Last sent 2 days ago',
    ),
    RecentRecipientEntity(
      id: 'oluwaseun',
      name: 'Oluwaseun Ade',
      initials: 'OA',
      colorIndex: 1,
      lastSentLabel: 'Last sent 1 week ago',
    ),
  ];
}
