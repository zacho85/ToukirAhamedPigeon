import 'package:kogosso_app/features/home/domain/domain.dart';

import '../datasources/home_local_datasource.dart';

class HomeRepositoryImpl implements HomeRepository {
  final HomeLocalDataSource localDataSource;

  const HomeRepositoryImpl(this.localDataSource);

  @override
  Future<double> getTotalBalance() => localDataSource.fetchTotalBalance();

  @override
  Future<WalletCardEntity> getPrimaryCard() => localDataSource.fetchPrimaryCard();

  @override
  Future<TontinaEntity> getActiveTontina() => localDataSource.fetchActiveTontina();

  @override
  Future<List<TransactionEntity>> getRecentActivity() => localDataSource.fetchRecentActivity();

  @override
  Future<List<QuickPayContactEntity>> getQuickPayContacts() =>
      localDataSource.fetchQuickPayContacts();
}