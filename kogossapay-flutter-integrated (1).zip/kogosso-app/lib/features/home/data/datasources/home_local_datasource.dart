import 'package:kogosso_app/features/home/domain/domain.dart';

abstract class HomeLocalDataSource {
  Future<double> fetchTotalBalance();

  Future<WalletCardEntity> fetchPrimaryCard();

  Future<TontinaEntity> fetchActiveTontina();

  Future<List<TransactionEntity>> fetchRecentActivity();

  Future<List<QuickPayContactEntity>> fetchQuickPayContacts();
}

class HomeLocalDataSourceImpl implements HomeLocalDataSource {
  @override
  Future<double> fetchTotalBalance() async => 42650.00;

  @override
  Future<WalletCardEntity> fetchPrimaryCard() async => const WalletCardEntity(
    holderName: 'ADOM SHAFI',
    maskedNumber: '**** **** **** 2345',
    expiry: '02/30',
    balance: 12800.00,
    brand: 'VISA',
  );

  @override
  Future<TontinaEntity> fetchActiveTontina() async =>
      const TontinaEntity(title: 'Active E-Tontine', currentAmount: 3600, targetAmount: 5000);

  @override
  Future<List<TransactionEntity>> fetchRecentActivity() async => const [
    TransactionEntity(
      id: 't1',
      title: 'Apple Store Purchase',
      date: 'Today • 2:45 PM',
      amount: 999.00,
      type: TransactionType.debit,
      status: TransactionStatus.completed,
      category: TransactionCategory.shopping,
    ),
    TransactionEntity(
      id: 't2',
      title: 'Salary Deposit',
      date: 'Yesterday • 10:15 AM',
      amount: 4200.00,
      type: TransactionType.credit,
      status: TransactionStatus.completed,
      category: TransactionCategory.salary,
    ),
    TransactionEntity(
      id: 't3',
      title: 'Transfer from Amadou',
      date: 'Dec 20 • 08:30 PM',
      amount: 150.00,
      type: TransactionType.credit,
      status: TransactionStatus.pending,
      category: TransactionCategory.transfer,
    ),
  ];

  @override
  Future<List<QuickPayContactEntity>> fetchQuickPayContacts() async => const [
    QuickPayContactEntity(id: 'add', name: 'Add', initials: '', isAddNew: true),
    QuickPayContactEntity(id: 'c1', name: 'Robert', initials: 'R'),
    QuickPayContactEntity(id: 'c2', name: 'Adom', initials: 'AS'),
    QuickPayContactEntity(id: 'c3', name: 'Ronald', initials: 'RM'),
    QuickPayContactEntity(id: 'c4', name: 'Lane', initials: 'LA'),
  ];
}