import 'package:kogosso_app/core/network/network.dart';
import 'package:kogosso_app/core/utils/formatters.dart';
import 'package:kogosso_app/features/home/domain/domain.dart';
import 'package:kogosso_app/features/tontine/data/datasources/tontine_remote_datasource.dart';

import 'home_local_datasource.dart';

/// Accueil alimenté par l'API réelle (/auth/me, /tontines, /transactions/history).
class HomeRemoteDataSource implements HomeLocalDataSource {
  HomeRemoteDataSource(this._api);
  final KongossaApi _api;

  @override
  Future<double> fetchTotalBalance() async => parseNum((await _api.me())['walletBalance']).toDouble();

  /// L'API n'a pas de carte bancaire, seulement un portefeuille : on affiche le
  /// portefeuille (titulaire, numéro de compte, solde) sans inventer de carte.
  @override
  Future<WalletCardEntity> fetchPrimaryCard() async {
    final me = await _api.me();
    return WalletCardEntity(
      holderName: (me['fullName'] as String? ?? '').toUpperCase(),
      maskedNumber: 'ACCOUNT #${me['id']}',
      expiry: '',
      balance: parseNum(me['walletBalance']).toDouble(),
      brand: 'KONGOSSAPAY',
    );
  }

  @override
  Future<TontinaEntity> fetchActiveTontina() async {
    final meId = parseNum((await _api.me())['id']);
    final active = (await _api.tontines()).where((t) => t['status'] == 'active');
    if (active.isEmpty) return const TontinaEntity(title: 'No active tontine', currentAmount: 0, targetAmount: 0);
    final t = active.first;
    final p = myTontineProgress(t, meId);
    return TontinaEntity(title: t['name'] as String? ?? 'Tontine', currentAmount: p.paidAmount, targetAmount: p.target);
  }

  @override
  Future<List<TransactionEntity>> fetchRecentActivity() async {
    final meId = parseNum((await _api.me())['id']);
    final txs = await _api.transactions(limit: 10);
    final out = <TransactionEntity>[];
    for (final t in txs) {
      final status = t['status'];
      if (status != 'completed' && status != 'pending') continue; // les échecs sont dans History
      final type = (t['type'] as String? ?? '');
      final isCredit = parseNum(t['recipientId']) == meId;
      final created = parseDate(t['createdAt']);
      out.add(
        TransactionEntity(
          id: '${t['id']}',
          title: _title(t, isCredit),
          date: created == null ? '' : formatWhen(created),
          amount: parseNum(t['amount']).toDouble(),
          type: isCredit ? TransactionType.credit : TransactionType.debit,
          status: status == 'completed' ? TransactionStatus.completed : TransactionStatus.pending,
          category: type.contains('payment_link')
              ? TransactionCategory.shopping
              : (isCredit && (type.contains('payout') || type.contains('topup')))
                  ? TransactionCategory.salary
                  : TransactionCategory.transfer,
        ),
      );
      if (out.length == 5) break;
    }
    return out;
  }

  /// Aucun contact enregistré pour un utilisateur normal (les contacts
  /// appartiennent aux agents) : seule la tuile « Add » est réelle.
  @override
  Future<List<QuickPayContactEntity>> fetchQuickPayContacts() async =>
      const [QuickPayContactEntity(id: 'add', name: 'Add', initials: '', isAddNew: true)];

  static String _title(Map<String, dynamic> t, bool isCredit) {
    final d = t['description'];
    if (d is String && d.trim().isNotEmpty) return d;
    final other = (isCredit ? t['senderName'] : t['recipientName']) as String?;
    return other == null ? 'Transaction' : (isCredit ? 'From $other' : 'To $other');
  }
}
