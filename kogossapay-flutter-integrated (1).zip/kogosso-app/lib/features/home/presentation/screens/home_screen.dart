import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/router/router.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/core/widgets/widgets.dart';

import '../providers/home_provider.dart';
import '../widgets/balance_card.dart';
import '../widgets/quick_action_row.dart';
import '../widgets/recent_activity_list.dart';
import '../widgets/tontina_progress_card.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(homeProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(homeProvider);

    if (state.status == HomeStatus.loading || state.status == HomeStatus.initial) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: CircularProgressIndicator(color: AppColors.primaryGreen)),
      );
    }

    if (state.status == HomeStatus.error) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.only(bottom: 96),
          child: Column(
            children: [
              AppTopBar(),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 32),
                child: Column(
                  children: [
                    GestureDetector(
                      onTap: () => context.push(AppRoutes.portfolio),
                      child: BalanceCard(
                        totalBalance: state.totalBalance,
                        quickPayContacts: state.quickPayContacts,
                        primaryCard: state.primaryCard,
                      ),
                    ),
                    const SizedBox(height: 32),
                    QuickActionRow(
                      onSendTap: () => context.push(AppRoutes.sendMoney),
                      onReceiveTap: () => context.push(AppRoutes.receiveMoney),
                      onDepositTap: () => context.push(AppRoutes.addFunds),
                      onQrPayTap: () => context.push(AppRoutes.paymentLink),
                    ),
                    const SizedBox(height: 32),
                    if (state.activeTontina != null)
                      TontinaProgressCard(tontina: state.activeTontina!),
                    const SizedBox(height: 32),
                    RecentActivityList(transactions: state.recentActivity),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
