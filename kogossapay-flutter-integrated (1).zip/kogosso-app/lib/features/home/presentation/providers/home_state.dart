import 'package:kogosso_app/features/home/domain/domain.dart';

import 'home_status.dart';

export 'home_status.dart';

class HomeState {
  final HomeStatus status;
  final double totalBalance;
  final WalletCardEntity? primaryCard;
  final TontinaEntity? activeTontina;
  final List<TransactionEntity> recentActivity;
  final List<QuickPayContactEntity> quickPayContacts;

  const HomeState({
    this.status = HomeStatus.initial,
    this.totalBalance = 0,
    this.primaryCard,
    this.activeTontina,
    this.recentActivity = const [],
    this.quickPayContacts = const [],
  });

  HomeState copyWith({
    HomeStatus? status,
    double? totalBalance,
    WalletCardEntity? primaryCard,
    TontinaEntity? activeTontina,
    List<TransactionEntity>? recentActivity,
    List<QuickPayContactEntity>? quickPayContacts,
  }) {
    return HomeState(
      status: status ?? this.status,
      totalBalance: totalBalance ?? this.totalBalance,
      primaryCard: primaryCard ?? this.primaryCard,
      activeTontina: activeTontina ?? this.activeTontina,
      recentActivity: recentActivity ?? this.recentActivity,
      quickPayContacts: quickPayContacts ?? this.quickPayContacts,
    );
  }
}
