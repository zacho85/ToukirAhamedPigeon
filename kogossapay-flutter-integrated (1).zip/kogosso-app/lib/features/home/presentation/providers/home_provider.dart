import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/auth/presentation/providers/auth_provider.dart';

import 'package:kogosso_app/features/home/data/data.dart';
import 'package:kogosso_app/features/home/domain/domain.dart';

import 'home_state.dart';

export 'home_state.dart';

part 'home_provider.g.dart';

@riverpod
class Home extends _$Home {
  GetHomeDashboard get _getHomeDashboard =>
      GetHomeDashboard(HomeRepositoryImpl(HomeRemoteDataSource(ref.read(kongossaApiProvider))));

  @override
  HomeState build() => const HomeState();

  Future<void> load() async {
    state = state.copyWith(status: HomeStatus.loading);
    try {
      final dashboard = await _getHomeDashboard();
      state = state.copyWith(
        status: HomeStatus.loaded,
        totalBalance: dashboard.totalBalance,
        primaryCard: dashboard.primaryCard,
        activeTontina: dashboard.activeTontina,
        recentActivity: dashboard.recentActivity,
        quickPayContacts: dashboard.quickPayContacts,
      );
    } catch (_) {
      state = state.copyWith(status: HomeStatus.error);
    }
  }
}
