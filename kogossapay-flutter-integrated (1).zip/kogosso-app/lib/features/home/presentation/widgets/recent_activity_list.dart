import 'package:kogosso_app/core/utils/formatters.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/home/domain/domain.dart';

class RecentActivityList extends StatelessWidget {
  final List<TransactionEntity> transactions;

  const RecentActivityList({super.key, required this.transactions});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Recent Activity', style: AppTextStyles.sectionHeading),
            Text(
              'See all',
              style: AppTextStyles.quickActionLabel.copyWith(color: AppColors.primaryGreen),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                offset: const Offset(0, 1),
                blurRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              for (int i = 0; i < transactions.length; i++) ...[
                _TransactionItem(transaction: transactions[i]),
                if (i < transactions.length - 1) Container(height: 1, color: AppColors.divider),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _TransactionItem extends StatelessWidget {
  final TransactionEntity transaction;

  const _TransactionItem({required this.transaction});

  @override
  Widget build(BuildContext context) {
    final isCredit = transaction.type == TransactionType.credit;
    final isPending = transaction.status == TransactionStatus.pending;
    final amountColor = isCredit ? AppColors.primaryGreen : AppColors.errorRed;
    final sign = isCredit ? '+' : '-';

    final categoryStyle = switch (transaction.category) {
      TransactionCategory.shopping => (
        icon: AppIcons.purchase,
        bgColor: AppColors.darkNavy.withValues(alpha: 0.1),
        iconColor: AppColors.darkNavy,
      ),
      TransactionCategory.salary => (
        icon: AppIcons.salary,
        bgColor: AppColors.primaryGreen.withValues(alpha: 0.1),
        iconColor: AppColors.primaryGreen,
      ),
      TransactionCategory.transfer => (
        icon: AppIcons.exchange,
        bgColor: AppColors.goldAccent.withValues(alpha: 0.1),
        iconColor: AppColors.gold,
      ),
    };

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: categoryStyle.bgColor,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Center(
              child: SvgPicture.asset(
                categoryStyle.icon,
                width: 22,
                height: 22,
                colorFilter: ColorFilter.mode(categoryStyle.iconColor, BlendMode.srcIn),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(transaction.title, style: AppTextStyles.transactionTitle),
                const SizedBox(height: 4),
                Text(
                  transaction.date,
                  style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '$sign${formatXaf(transaction.amount)}',
                style: AppTextStyles.transactionAmount.copyWith(color: amountColor),
              ),
              const SizedBox(height: 4),
              Text(
                isPending ? 'Pending' : 'Completed',
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
              ),
            ],
          ),
        ],
      ),
    );
  }
}