import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class QuickActionRow extends StatelessWidget {
  final VoidCallback? onSendTap;
  final VoidCallback? onReceiveTap;
  final VoidCallback? onDepositTap;
  final VoidCallback? onQrPayTap;

  const QuickActionRow({
    super.key,
    this.onSendTap,
    this.onReceiveTap,
    this.onDepositTap,
    this.onQrPayTap,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _QuickActionItem(icon: AppIcons.send, label: 'Send', onTap: onSendTap),
        _QuickActionItem(icon: AppIcons.receive, label: 'Receive', onTap: onReceiveTap),
        _QuickActionItem(icon: AppIcons.deposit, label: 'Deposit', onTap: onDepositTap),
        const _QuickActionItem(icon: AppIcons.withdraw, label: 'Withdraw'),
        _QuickActionItem(icon: AppIcons.qrPay, label: 'QR Pay', onTap: onQrPayTap),
      ],
    );
  }
}

class _QuickActionItem extends StatelessWidget {
  final String icon;
  final String label;
  final VoidCallback? onTap;

  const _QuickActionItem({required this.icon, required this.label, this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 57,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withValues(alpha: 0.05),
                  offset: const Offset(0, 1),
                  blurRadius: 2,
                ),
              ],
            ),
            child: Center(
              child: SvgPicture.asset(
                icon,
                width: 22,
                height: 22,
                colorFilter: const ColorFilter.mode(AppColors.greyText, BlendMode.srcIn),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(label, style: AppTextStyles.quickActionLabel),
        ],
      ),
    );
  }
}
