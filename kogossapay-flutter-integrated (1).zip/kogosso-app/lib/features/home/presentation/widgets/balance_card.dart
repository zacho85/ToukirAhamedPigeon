import 'package:kogosso_app/core/utils/formatters.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/home/domain/domain.dart';

import 'wallet_card_widget.dart';

class BalanceCard extends StatelessWidget {
  final double totalBalance;
  final List<QuickPayContactEntity> quickPayContacts;
  final WalletCardEntity? primaryCard;

  const BalanceCard({super.key, required this.totalBalance, required this.quickPayContacts, required this.primaryCard});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(32),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: AppColors.balanceCardGradient,
        boxShadow: [
          BoxShadow(color: const Color(0xFF000B25).withValues(alpha: 0.15), offset: const Offset(0, 20), blurRadius: 40),
        ],
      ),
      child: Stack(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Total Balance header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('TOTAL BALANCE', style: AppTextStyles.cardLabel),
                  SvgPicture.asset(AppIcons.eye),
                ],
              ),
              const SizedBox(height: 12),
              // Amount
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(formatXaf(totalBalance).replaceAll(' XAF', ''), style: AppTextStyles.balanceAmount),
                  const SizedBox(height: 2),
                  const Text(
                    'XAF',
                    style: TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontWeight: FontWeight.w700,
                      fontSize: 20,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 36),
              Divider(color: Colors.white.withValues(alpha: 0.1), height: 1.0, thickness: 1.0),
              const SizedBox(height: 24),
              // Quick Pay section
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('QUICK PAY', style: AppTextStyles.badge.copyWith(color: Colors.white, letterSpacing: 0.3)),
                  Row(
                    children: [
                      SvgPicture.asset(AppIcons.add),
                      const SizedBox(width: 4),
                      Text('Add New', style: AppTextStyles.badge.copyWith(color: AppColors.primaryGreenLight)),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 12),
              // Contact avatars
              SizedBox(
                height: 80,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: quickPayContacts.length,
                  separatorBuilder: (_, _) => const SizedBox(width: 16),
                  itemBuilder: (context, index) {
                    final contact = quickPayContacts[index];
                    return _ContactAvatarItem(contact: contact, index: index);
                  },
                ),
              ),
              const SizedBox(height: 24),
              // My Cards section
              Text('MY CARDS', style: AppTextStyles.badge.copyWith(color: Colors.white, letterSpacing: 0.3)),
              const SizedBox(height: 12),
              // Cards stack
              if (primaryCard != null) WalletCardWidget(card: primaryCard!),
            ],
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              color: AppColors.primaryGreenLight.withValues(alpha: 0.2),
              border: Border.all(color: AppColors.primaryGreen.withValues(alpha: 0.3), width: 1),
            ),
            child: const Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.arrow_upward, size: 12, color: AppColors.primaryGreenLight),
                SizedBox(width: 4),
                Text(
                  '2.4%',
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontWeight: FontWeight.w600,
                    fontSize: 12,
                    color: AppColors.primaryGreenLight,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ContactAvatarItem extends StatelessWidget {
  final QuickPayContactEntity contact;
  final int index;

  const _ContactAvatarItem({required this.contact, required this.index});

  @override
  Widget build(BuildContext context) {
    Color avatarColor = Colors.white.withValues(alpha: 0.2);
    if (index == 2) avatarColor = AppColors.primaryGreenLight;
    if (index == 3) avatarColor = AppColors.goldLight;
    if (index == 4) avatarColor = Colors.white.withValues(alpha: 0.6);

    return Column(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: contact.isAddNew ? Colors.transparent : avatarColor,
            border: contact.isAddNew ? Border.all(color: Colors.white.withValues(alpha: 0.6), width: 1.5) : null,
          ),
          child: Center(
            child: contact.isAddNew
                ? Icon(Icons.add, size: 18, color: Colors.white.withValues(alpha: 0.6))
                : Text(
                    contact.initials,
                    style: const TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                      color: AppColors.darkNavy,
                    ),
                  ),
          ),
        ),
        const SizedBox(height: 8),
        Text(contact.name, style: AppTextStyles.smallLabel),
      ],
    );
  }
}
