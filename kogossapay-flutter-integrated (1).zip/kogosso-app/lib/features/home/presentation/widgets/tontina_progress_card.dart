import 'package:kogosso_app/core/utils/formatters.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/home/domain/domain.dart';

class TontinaProgressCard extends StatelessWidget {
  final TontinaEntity tontina;

  const TontinaProgressCard({super.key, required this.tontina});

  @override
  Widget build(BuildContext context) {
    final progressFactor = tontina.progress.clamp(0.0, 1.0);

    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 6, sigmaY: 6),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.all(21),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            color: Colors.white.withValues(alpha: 0.7),
            border: Border.all(color: Colors.white, width: 1),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                offset: const Offset(0, 1),
                blurRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(tontina.title, style: AppTextStyles.sectionHeading),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6),
                      color: AppColors.goldAccent.withValues(alpha: 0.2),
                      border: Border.all(color: AppColors.gold.withValues(alpha: 0.3), width: 1),
                    ),
                    child: Text(
                      'Goal: ${formatXaf(tontina.targetAmount)}',
                      style: AppTextStyles.badge.copyWith(color: AppColors.gold),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Progress bar
              Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: Stack(
                      children: [
                        Container(
                          height: 12,
                          width: double.infinity,
                          color: AppColors.progressTrack,
                        ),
                        FractionallySizedBox(
                          widthFactor: progressFactor,
                          child: Container(
                            height: 12,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(6),
                              gradient: const LinearGradient(
                                colors: [AppColors.primaryGreen, AppColors.primaryGreenLight],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: AppColors.primaryGreenLight.withValues(alpha: 0.5),
                                  blurRadius: 12,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '${formatXaf(tontina.currentAmount)} saved',
                        style: AppTextStyles.quickActionLabel,
                      ),
                      Text(
                        '${(progressFactor * 100).toStringAsFixed(0)}%',
                        style: AppTextStyles.badge.copyWith(
                          color: AppColors.primaryGreen,
                          fontSize: 14,
                          letterSpacing: 0.14,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}