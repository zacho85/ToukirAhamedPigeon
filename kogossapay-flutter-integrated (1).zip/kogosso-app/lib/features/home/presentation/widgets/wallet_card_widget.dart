import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/home/domain/domain.dart';

class WalletCardWidget extends StatelessWidget {
  final WalletCardEntity card;

  const WalletCardWidget({super.key, required this.card});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 180,
      child: Stack(
        children: [
          Positioned(
            top: 20,
            left: 10,
            right: 10,
            child: CreditCardItem(
              isSecondary: true,
              cardNumber: '**** **** **** 8892',
              holderName: card.holderName,
              expires: '11/28',
              brand: card.brand,
            ),
          ),
          CreditCardItem(
            isSecondary: false,
            cardNumber: card.maskedNumber,
            holderName: card.holderName,
            expires: card.expiry,
            brand: card.brand,
          ),
        ],
      ),
    );
  }
}

class CreditCardItem extends StatelessWidget {
  final bool isSecondary;
  final String cardNumber;
  final String holderName;
  final String expires;
  final String brand;

  const CreditCardItem({
    super.key,
    required this.isSecondary,
    required this.cardNumber,
    required this.holderName,
    required this.expires,
    this.brand = 'VISA',
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 160,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        gradient: isSecondary ? null : AppColors.primaryCreditCardGradient,
        color: isSecondary ? Colors.white.withValues(alpha: 0.1) : null,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            offset: const Offset(0, 4),
            blurRadius: 6,
            spreadRadius: -4,
          ),
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            offset: const Offset(0, 10),
            blurRadius: 15,
            spreadRadius: -3,
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: isSecondary
              ? ImageFilter.blur(sigmaX: 6, sigmaY: 6)
              : ImageFilter.blur(sigmaX: 0, sigmaY: 0),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                // Card brand
                Align(
                  alignment: Alignment.topRight,
                  child: Text(
                    brand.toUpperCase(),
                    style: const TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontWeight: FontWeight.w700,
                      fontStyle: FontStyle.italic,
                      fontSize: 18,
                      height: 28 / 18,
                      color: Colors.white,
                    ),
                  ),
                ),
                // Card number
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'WALLET',
                      style: AppTextStyles.cardMeta.copyWith(
                        color: Colors.white.withValues(alpha: 0.8),
                        letterSpacing: 1,
                        fontSize: 10,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(cardNumber, style: AppTextStyles.cardNumber),
                  ],
                ),
                // Bottom row
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('ACCOUNT HOLDER', style: AppTextStyles.cardMeta),
                        Text(holderName, style: AppTextStyles.cardHolderName),
                      ],
                    ),
                    if (expires.isNotEmpty) ...[
                      const Spacer(),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('EXPIRES', style: AppTextStyles.cardMeta),
                          Text(expires, style: AppTextStyles.cardHolderName),
                        ],
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}