import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class HomeBottomNav extends StatelessWidget {
  final int currentIndex;
  final ValueChanged<int> onTap;

  const HomeBottomNav({super.key, required this.currentIndex, required this.onTap});

  static const _tabs = [
    (icon: AppIcons.home, label: 'Home'),
    (icon: AppIcons.history, label: 'History'),
    (icon: AppIcons.eTontine, label: 'E-Tontine'),
    (icon: AppIcons.settings, label: 'Settings'),
  ];

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: Container(
          height: 61 + MediaQuery.of(context).padding.bottom,
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).padding.bottom,
            left: 16,
            right: 16,
            top: 7,
          ),
          decoration: BoxDecoration(
            color: Colors.white.withValues(alpha: 0.8),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF000B25).withValues(alpha: 0.08),
                offset: const Offset(0, -4),
                blurRadius: 20,
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: List.generate(_tabs.length, (i) {
              final isActive = i == currentIndex;
              return GestureDetector(
                onTap: () => onTap(i),
                behavior: HitTestBehavior.opaque,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    color: isActive
                        ? AppColors.primaryGreenLight.withValues(alpha: 0.2)
                        : Colors.transparent,
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SvgPicture.asset(
                        _tabs[i].icon,
                        width: 18,
                        height: 18,
                        colorFilter: ColorFilter.mode(
                          isActive ? AppColors.primaryGreen : AppColors.greyText,
                          BlendMode.srcIn,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _tabs[i].label,
                        style: AppTextStyles.navLabel.copyWith(
                          color: isActive ? AppColors.primaryGreen : AppColors.greyText,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}