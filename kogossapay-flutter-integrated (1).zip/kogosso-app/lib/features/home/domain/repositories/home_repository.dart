import '../entities/quick_pay_contact_entity.dart';
import '../entities/tontina_entity.dart';
import '../entities/transaction_entity.dart';
import '../entities/wallet_card_entity.dart';

abstract class HomeRepository {
  Future<double> getTotalBalance();
  Future<WalletCardEntity> getPrimaryCard();
  Future<TontinaEntity> getActiveTontina();
  Future<List<TransactionEntity>> getRecentActivity();
  Future<List<QuickPayContactEntity>> getQuickPayContacts();
}
