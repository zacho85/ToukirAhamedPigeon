import '../entities/quick_pay_contact_entity.dart';
import '../entities/tontina_entity.dart';
import '../entities/transaction_entity.dart';
import '../entities/wallet_card_entity.dart';
import '../repositories/home_repository.dart';

class HomeDashboard {
  final double totalBalance;
  final WalletCardEntity primaryCard;
  final TontinaEntity activeTontina;
  final List<TransactionEntity> recentActivity;
  final List<QuickPayContactEntity> quickPayContacts;

  const HomeDashboard({
    required this.totalBalance,
    required this.primaryCard,
    required this.activeTontina,
    required this.recentActivity,
    required this.quickPayContacts,
  });
}

class GetHomeDashboard {
  final HomeRepository repository;

  const GetHomeDashboard(this.repository);

  Future<HomeDashboard> call() async {
    final results = await Future.wait([
      repository.getTotalBalance(),
      repository.getPrimaryCard(),
      repository.getActiveTontina(),
      repository.getRecentActivity(),
      repository.getQuickPayContacts(),
    ]);

    return HomeDashboard(
      totalBalance: results[0] as double,
      primaryCard: results[1] as WalletCardEntity,
      activeTontina: results[2] as TontinaEntity,
      recentActivity: results[3] as List<TransactionEntity>,
      quickPayContacts: results[4] as List<QuickPayContactEntity>,
    );
  }
}
