enum TransactionType { debit, credit }

enum TransactionStatus { completed, pending }

enum TransactionCategory { shopping, salary, transfer }

class TransactionEntity {
  final String id;
  final String title;
  final String date;
  final double amount;
  final TransactionType type;
  final TransactionStatus status;
  final TransactionCategory category;

  const TransactionEntity({
    required this.id,
    required this.title,
    required this.date,
    required this.amount,
    required this.type,
    required this.status,
    required this.category,
  });
}
