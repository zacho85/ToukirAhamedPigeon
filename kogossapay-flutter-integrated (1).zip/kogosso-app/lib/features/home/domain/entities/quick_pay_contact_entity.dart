class QuickPayContactEntity {
  final String id;
  final String name;
  final String initials;
  final bool isAddNew;

  const QuickPayContactEntity({
    required this.id,
    required this.name,
    required this.initials,
    this.isAddNew = false,
  });
}
