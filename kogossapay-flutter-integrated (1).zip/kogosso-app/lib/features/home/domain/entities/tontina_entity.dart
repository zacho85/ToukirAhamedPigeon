class TontinaEntity {
  final String title;
  final double currentAmount;
  final double targetAmount;

  const TontinaEntity({
    required this.title,
    required this.currentAmount,
    required this.targetAmount,
  });

  double get progress => targetAmount == 0 ? 0 : currentAmount / targetAmount;
}
