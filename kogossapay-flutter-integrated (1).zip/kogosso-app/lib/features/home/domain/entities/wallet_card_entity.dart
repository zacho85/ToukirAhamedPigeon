class WalletCardEntity {
  final String holderName;
  final String maskedNumber;
  final String expiry;
  final double balance;
  final String brand;

  const WalletCardEntity({
    required this.holderName,
    required this.maskedNumber,
    required this.expiry,
    required this.balance,
    required this.brand,
  });
}
