import '../entities/budget_insight_entity.dart';
import '../entities/budget_summary_entity.dart';
import '../entities/savings_goal_entity.dart';
import '../entities/spending_category_entity.dart';
import '../repositories/budget_repository.dart';

class BudgetDashboard {
  final BudgetSummaryEntity summary;
  final BudgetInsightEntity insight;
  final List<SpendingCategoryEntity> spendingCategories;
  final List<SavingsGoalEntity> savingsGoals;

  const BudgetDashboard({
    required this.summary,
    required this.insight,
    required this.spendingCategories,
    required this.savingsGoals,
  });
}

class GetBudgetDashboard {
  final BudgetRepository repository;

  const GetBudgetDashboard(this.repository);

  Future<BudgetDashboard> call() async {
    final results = await Future.wait([
      repository.getSummary(),
      repository.getInsight(),
      repository.getSpendingCategories(),
      repository.getSavingsGoals(),
    ]);

    return BudgetDashboard(
      summary: results[0] as BudgetSummaryEntity,
      insight: results[1] as BudgetInsightEntity,
      spendingCategories: results[2] as List<SpendingCategoryEntity>,
      savingsGoals: results[3] as List<SavingsGoalEntity>,
    );
  }
}
