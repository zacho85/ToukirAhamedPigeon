class BudgetInsightEntity {
  final String message;
  final String ctaLabel;

  const BudgetInsightEntity({required this.message, required this.ctaLabel});
}
