class BudgetSummaryEntity {
  final double progress;
  final double spent;
  final double remaining;

  const BudgetSummaryEntity({required this.progress, required this.spent, required this.remaining});
}
