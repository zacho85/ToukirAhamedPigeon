class SavingsGoalEntity {
  final String title;
  final double savedAmount;
  final double targetAmount;

  const SavingsGoalEntity({required this.title, required this.savedAmount, required this.targetAmount});

  double get progress => targetAmount <= 0 ? 0 : (savedAmount / targetAmount).clamp(0.0, 1.0);
}
