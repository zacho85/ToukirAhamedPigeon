enum SpendingCategoryType { foodAndDining, transport, rentAndUtilities, leisure }

class SpendingCategoryEntity {
  final SpendingCategoryType type;
  final String label;
  final double spent;
  final double limit;

  const SpendingCategoryEntity({required this.type, required this.label, required this.spent, required this.limit});

  double get progress => limit <= 0 ? 0 : (spent / limit).clamp(0.0, 1.0);
}
