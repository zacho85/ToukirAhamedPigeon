import '../entities/budget_insight_entity.dart';
import '../entities/budget_summary_entity.dart';
import '../entities/savings_goal_entity.dart';
import '../entities/spending_category_entity.dart';

abstract class BudgetRepository {
  Future<BudgetSummaryEntity> getSummary();

  Future<BudgetInsightEntity> getInsight();

  Future<List<SpendingCategoryEntity>> getSpendingCategories();

  Future<List<SavingsGoalEntity>> getSavingsGoals();
}
