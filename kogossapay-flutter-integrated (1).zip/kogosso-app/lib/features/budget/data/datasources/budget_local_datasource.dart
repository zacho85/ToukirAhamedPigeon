import 'package:kogosso_app/features/budget/domain/domain.dart';

abstract class BudgetLocalDataSource {
  Future<BudgetSummaryEntity> fetchSummary();

  Future<BudgetInsightEntity> fetchInsight();

  Future<List<SpendingCategoryEntity>> fetchSpendingCategories();

  Future<List<SavingsGoalEntity>> fetchSavingsGoals();
}

class BudgetLocalDataSourceImpl implements BudgetLocalDataSource {
  @override
  Future<BudgetSummaryEntity> fetchSummary() async =>
      const BudgetSummaryEntity(progress: 0.75, spent: 1850.00, remaining: 650.00);

  @override
  Future<BudgetInsightEntity> fetchInsight() async => const BudgetInsightEntity(
    message:
        "You've spent 22% more on Food & Dining this month than usual. "
        'Consider setting a tighter weekly limit to stay on track.',
    ctaLabel: 'Adjust Budget',
  );

  @override
  Future<List<SpendingCategoryEntity>> fetchSpendingCategories() async => const [
    SpendingCategoryEntity(type: SpendingCategoryType.foodAndDining, label: 'Food & Dining', spent: 600, limit: 800),
    SpendingCategoryEntity(type: SpendingCategoryType.transport, label: 'Transport', spent: 150, limit: 200),
    SpendingCategoryEntity(type: SpendingCategoryType.rentAndUtilities, label: 'Rent & Utilities', spent: 950, limit: 1000),
    SpendingCategoryEntity(type: SpendingCategoryType.leisure, label: 'Leisure', spent: 90, limit: 300),
  ];

  @override
  Future<List<SavingsGoalEntity>> fetchSavingsGoals() async => const [
    SavingsGoalEntity(title: 'New Laptop', savedAmount: 600, targetAmount: 1200),
    SavingsGoalEntity(title: 'Vacation', savedAmount: 300, targetAmount: 1500),
  ];
}
