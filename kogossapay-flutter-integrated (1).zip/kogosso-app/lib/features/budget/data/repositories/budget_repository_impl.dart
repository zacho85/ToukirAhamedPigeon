import 'package:kogosso_app/features/budget/domain/domain.dart';

import '../datasources/budget_local_datasource.dart';

class BudgetRepositoryImpl implements BudgetRepository {
  final BudgetLocalDataSource localDataSource;

  const BudgetRepositoryImpl(this.localDataSource);

  @override
  Future<BudgetSummaryEntity> getSummary() => localDataSource.fetchSummary();

  @override
  Future<BudgetInsightEntity> getInsight() => localDataSource.fetchInsight();

  @override
  Future<List<SpendingCategoryEntity>> getSpendingCategories() => localDataSource.fetchSpendingCategories();

  @override
  Future<List<SavingsGoalEntity>> getSavingsGoals() => localDataSource.fetchSavingsGoals();
}
