import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/budget/data/data.dart';
import 'package:kogosso_app/features/budget/domain/domain.dart';

import 'budget_state.dart';

export 'budget_state.dart';

part 'budget_provider.g.dart';

@riverpod
class Budget extends _$Budget {
  GetBudgetDashboard get _getBudgetDashboard =>
      GetBudgetDashboard(BudgetRepositoryImpl(BudgetLocalDataSourceImpl()));

  @override
  BudgetState build() => const BudgetState();

  Future<void> load() async {
    state = state.copyWith(status: BudgetStatus.loading);
    try {
      final dashboard = await _getBudgetDashboard();
      state = state.copyWith(
        status: BudgetStatus.loaded,
        summary: dashboard.summary,
        insight: dashboard.insight,
        spendingCategories: dashboard.spendingCategories,
        savingsGoals: dashboard.savingsGoals,
      );
    } catch (_) {
      state = state.copyWith(status: BudgetStatus.error);
    }
  }
}
