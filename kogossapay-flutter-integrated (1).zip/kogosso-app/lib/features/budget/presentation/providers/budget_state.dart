import 'package:kogosso_app/features/budget/domain/domain.dart';

import 'budget_status.dart';

export 'budget_status.dart';

class BudgetState {
  final BudgetStatus status;
  final BudgetSummaryEntity? summary;
  final BudgetInsightEntity? insight;
  final List<SpendingCategoryEntity> spendingCategories;
  final List<SavingsGoalEntity> savingsGoals;

  const BudgetState({
    this.status = BudgetStatus.initial,
    this.summary,
    this.insight,
    this.spendingCategories = const [],
    this.savingsGoals = const [],
  });

  BudgetState copyWith({
    BudgetStatus? status,
    BudgetSummaryEntity? summary,
    BudgetInsightEntity? insight,
    List<SpendingCategoryEntity>? spendingCategories,
    List<SavingsGoalEntity>? savingsGoals,
  }) {
    return BudgetState(
      status: status ?? this.status,
      summary: summary ?? this.summary,
      insight: insight ?? this.insight,
      spendingCategories: spendingCategories ?? this.spendingCategories,
      savingsGoals: savingsGoals ?? this.savingsGoals,
    );
  }
}
