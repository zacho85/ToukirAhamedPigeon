enum BudgetStatus { initial, loading, loaded, error }
