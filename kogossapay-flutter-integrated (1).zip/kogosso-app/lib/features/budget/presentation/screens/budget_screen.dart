import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/theme/theme.dart';

import '../providers/budget_provider.dart';
import '../widgets/advanced_security_banner.dart';
import '../widgets/budget_insight_card.dart';
import '../widgets/budget_ring_card.dart';
import '../widgets/savings_goals_grid.dart';
import '../widgets/spending_categories_list.dart';

class BudgetScreen extends ConsumerStatefulWidget {
  const BudgetScreen({super.key});

  @override
  ConsumerState<BudgetScreen> createState() => _BudgetScreenState();
}

class _BudgetScreenState extends ConsumerState<BudgetScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(budgetProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(budgetProvider);

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.pop(),
                    child: const Icon(
                      Icons.arrow_back_ios_new_rounded,
                      size: 18,
                      color: AppColors.darkNavy,
                    ),
                  ),
                  const SizedBox(width: 16),
                  const Text('KongossoPay', style: AppTextStyles.appTitle),
                ],
              ),
            ),
            Expanded(child: _buildBody(state)),
          ],
        ),
      ),
    );
  }

  Widget _buildBody(BudgetState state) {
    if (state.status == BudgetStatus.loading || state.status == BudgetStatus.initial) {
      return const Center(child: CircularProgressIndicator(color: AppColors.primaryGreen));
    }

    if (state.status == BudgetStatus.error || state.summary == null || state.insight == null) {
      return const Center(
        child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
      );
    }

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          BudgetRingCard(summary: state.summary!),
          const SizedBox(height: 20),
          BudgetInsightCard(insight: state.insight!),
          const SizedBox(height: 28),
          SpendingCategoriesList(categories: state.spendingCategories),
          const SizedBox(height: 28),
          SavingsGoalsGrid(goals: state.savingsGoals),
          const SizedBox(height: 28),
          const AdvancedSecurityBanner(),
        ],
      ),
    );
  }
}
