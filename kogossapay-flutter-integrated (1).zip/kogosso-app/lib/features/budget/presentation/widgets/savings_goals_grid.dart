import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/budget/domain/domain.dart';

class SavingsGoalsGrid extends StatelessWidget {
  final List<SavingsGoalEntity> goals;

  const SavingsGoalsGrid({super.key, required this.goals});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Savings Goals', style: AppTextStyles.sectionHeading),
        const SizedBox(height: 16),
        Row(
          children: [
            for (var i = 0; i < goals.length; i++) ...[
              Expanded(child: _GoalCard(goal: goals[i])),
              if (i < goals.length - 1) const SizedBox(width: 16),
            ],
          ],
        ),
      ],
    );
  }
}

class _GoalCard extends StatelessWidget {
  final SavingsGoalEntity goal;

  const _GoalCard({required this.goal});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(goal.title, style: AppTextStyles.transactionTitle.copyWith(fontSize: 14)),
          const SizedBox(height: 4),
          Text(
            '\$${goal.savedAmount.toStringAsFixed(0)} / \$${goal.targetAmount.toStringAsFixed(0)}',
            style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
          ),
          const SizedBox(height: 12),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: goal.progress,
              minHeight: 6,
              backgroundColor: AppColors.progressTrack,
              valueColor: const AlwaysStoppedAnimation(AppColors.primaryGreen),
            ),
          ),
        ],
      ),
    );
  }
}
