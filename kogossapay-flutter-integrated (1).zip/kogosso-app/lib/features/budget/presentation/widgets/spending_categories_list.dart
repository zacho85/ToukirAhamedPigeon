import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/budget/domain/domain.dart';

class SpendingCategoriesList extends StatelessWidget {
  final List<SpendingCategoryEntity> categories;

  const SpendingCategoriesList({super.key, required this.categories});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Spending Categories', style: AppTextStyles.sectionHeading),
            Text(
              'View All',
              style: AppTextStyles.quickActionLabel.copyWith(color: AppColors.primaryGreen),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                offset: const Offset(0, 1),
                blurRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              for (int i = 0; i < categories.length; i++) ...[
                _CategoryTile(category: categories[i]),
                if (i < categories.length - 1) Container(height: 1, color: AppColors.divider),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _CategoryTile extends StatelessWidget {
  final SpendingCategoryEntity category;

  const _CategoryTile({required this.category});

  // TODO: replace with the downloaded Figma category icons.
  static const _styles = {
    SpendingCategoryType.foodAndDining: (icon: Icons.restaurant_outlined, color: AppColors.gold),
    SpendingCategoryType.transport: (icon: Icons.directions_bus_filled_outlined, color: Color(0xFF2FA8BF)),
    SpendingCategoryType.rentAndUtilities: (icon: Icons.home_work_outlined, color: AppColors.darkNavy),
    SpendingCategoryType.leisure: (icon: Icons.local_activity_outlined, color: Color(0xFF8C7BF6)),
  };

  @override
  Widget build(BuildContext context) {
    final style = _styles[category.type]!;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: style.color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(style.icon, size: 18, color: style.color),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(category.label, style: AppTextStyles.transactionTitle.copyWith(fontSize: 14)),
                    Text(
                      '\$${category.spent.toStringAsFixed(0)}/\$${category.limit.toStringAsFixed(0)}',
                      style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: LinearProgressIndicator(
                    value: category.progress,
                    minHeight: 6,
                    backgroundColor: AppColors.progressTrack,
                    valueColor: AlwaysStoppedAnimation(style.color),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
