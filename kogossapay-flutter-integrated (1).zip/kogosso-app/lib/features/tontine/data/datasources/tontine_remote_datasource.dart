import 'package:kogosso_app/core/network/network.dart';
import 'package:kogosso_app/core/utils/formatters.dart';
import 'package:kogosso_app/features/tontine/domain/domain.dart';

import 'tontine_local_datasource.dart';

/// Progression de l'utilisateur [meId] dans une tontine (JSON de GET /tontines) :
/// nombre et montant de SES contributions payées, sur durée × cotisation.
({int paid, int duration, double paidAmount, double target}) myTontineProgress(Map<String, dynamic> t, num meId) {
  final duration = parseNum(t['durationMonths']).toInt();
  final amount = parseNum(t['contributionAmount']).toDouble();
  var paid = 0;
  var paidAmount = 0.0;
  for (final m in (t['members'] as List? ?? const [])) {
    if (m is! Map || parseNum(m['userId']) != meId) continue;
    for (final c in (m['contributions'] as List? ?? const [])) {
      if (c is Map && c['status'] == 'paid') {
        paid++;
        paidAmount += parseNum(c['amount']).toDouble();
      }
    }
  }
  return (paid: paid, duration: duration, paidAmount: paidAmount, target: amount * duration);
}

/// Tontines alimentées par l'API réelle (/tontines, /dashboard).
class TontineRemoteDataSource implements TontineLocalDataSource {
  TontineRemoteDataSource(this._api);
  final KongossaApi _api;

  @override
  Future<List<ActiveCircleEntity>> fetchActiveCircles() async {
    final meId = parseNum((await _api.me())['id']);
    final circles = <ActiveCircleEntity>[];
    for (final t in await _api.tontines()) {
      if (t['status'] != 'active') continue;
      final p = myTontineProgress(t, meId);
      final progress = p.duration == 0 ? 0.0 : (p.paid / p.duration).clamp(0.0, 1.0);
      final freq = (t['frequency'] as String? ?? '');
      circles.add(
        ActiveCircleEntity(
          id: '${t['id']}',
          title: t['name'] as String? ?? 'Tontine',
          subtitle: 'Contribution: ${formatXaf(parseNum(t['contributionAmount']))}',
          badgeLabel: freq.isEmpty ? 'Active' : '${freq[0].toUpperCase()}${freq.substring(1)}',
          badgeType: CircleBadgeType.upcoming,
          progress: progress,
          progressLabel: '${p.paid}/${p.duration} paid',
          // Pas d'action « Pay » tant que le paiement de contribution n'est pas branché.
        ),
      );
    }
    return circles;
  }

  /// L'API n'expose pas de cercles publics : pas de section « Discover ».
  @override
  Future<FeaturedCircleEntity?> fetchFeaturedCircle() async => null;

  @override
  Future<List<TontineStatEntity>> fetchStats() async {
    final t = (await _api.dashboard())['tontines'];
    final m = t is Map ? t : const {};
    return [
      TontineStatEntity(label: 'Total Contributed', value: formatXaf(parseNum(m['totalContributed']))),
      TontineStatEntity(label: 'Total Received', value: formatXaf(parseNum(m['totalReceived']))),
      TontineStatEntity(label: 'Active Circles', value: '${parseNum(m['active']).toInt()}'),
      TontineStatEntity(label: 'Pending Invites', value: '${parseNum(m['pendingInvites']).toInt()}'),
    ];
  }
}
