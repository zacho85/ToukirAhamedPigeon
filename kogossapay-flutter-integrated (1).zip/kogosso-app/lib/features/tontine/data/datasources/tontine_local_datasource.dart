import 'package:kogosso_app/features/tontine/domain/domain.dart';

abstract class TontineLocalDataSource {
  Future<List<ActiveCircleEntity>> fetchActiveCircles();
  Future<FeaturedCircleEntity?> fetchFeaturedCircle();
  Future<List<TontineStatEntity>> fetchStats();
}

class TontineLocalDataSourceImpl implements TontineLocalDataSource {
  // TODO: swap the icon placeholders below for the real circle/stat SVGs
  // once they're downloaded from Figma (see AppIcons for the pattern).
  @override
  Future<List<ActiveCircleEntity>> fetchActiveCircles() async => const [
    ActiveCircleEntity(
      id: 'c1',
      title: 'Family Holiday Fund',
      subtitle: 'Payout: 2,500,000 XAF',
      badgeLabel: 'In 3 days',
      badgeType: CircleBadgeType.upcoming,
      progress: 0.75,
      progressLabel: '75%',
    ),
    ActiveCircleEntity(
      id: 'c2',
      title: 'SME Growth Circle',
      subtitle: 'Contribution: 50,000 XAF',
      badgeLabel: 'Collection Day',
      badgeType: CircleBadgeType.collection,
      progress: 0.4,
      progressLabel: 'Collection Progress 40%',
      actionLabel: 'Pay Contribution',
      contributionAmount: 50000,
    ),
  ];

  @override
  Future<FeaturedCircleEntity> fetchFeaturedCircle() async => const FeaturedCircleEntity(
    tag: 'Featured Opportunity',
    title: 'Elite Real Estate Pool',
    description:
        'Join a community of 50 verified members saving for land acquisition. '
        'High reliability score and escrow protected.',
    targetLabel: 'Target',
    targetValue: '15.0M XAF',
    monthlyLabel: 'Monthly',
    monthlyValue: '100k XAF',
    buttonLabel: 'Join Circle',
  );

  @override
  Future<List<TontineStatEntity>> fetchStats() async => const [
    TontineStatEntity(label: 'Total Saved', value: '850k'),
    TontineStatEntity(label: 'Trust Score', value: 'A+'),
    TontineStatEntity(label: 'Payouts Rec.', value: '12'),
    TontineStatEntity(label: 'Member Since', value: '2mo'),
  ];
}
