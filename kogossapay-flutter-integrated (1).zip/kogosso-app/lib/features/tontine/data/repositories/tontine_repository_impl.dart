import 'package:kogosso_app/features/tontine/domain/domain.dart';

import '../datasources/tontine_local_datasource.dart';

class TontineRepositoryImpl implements TontineRepository {
  final TontineLocalDataSource localDataSource;

  const TontineRepositoryImpl(this.localDataSource);

  @override
  Future<List<ActiveCircleEntity>> getActiveCircles() => localDataSource.fetchActiveCircles();

  @override
  Future<FeaturedCircleEntity?> getFeaturedCircle() => localDataSource.fetchFeaturedCircle();

  @override
  Future<List<TontineStatEntity>> getStats() => localDataSource.fetchStats();
}
