import '../entities/active_circle_entity.dart';
import '../entities/featured_circle_entity.dart';
import '../entities/tontine_stat_entity.dart';

abstract class TontineRepository {
  Future<List<ActiveCircleEntity>> getActiveCircles();
  Future<FeaturedCircleEntity?> getFeaturedCircle();
  Future<List<TontineStatEntity>> getStats();
}
