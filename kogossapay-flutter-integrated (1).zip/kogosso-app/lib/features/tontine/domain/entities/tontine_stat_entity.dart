class TontineStatEntity {
  final String label;
  final String value;

  // TODO: replace with the downloaded Figma stat icon (asset path) once available.
  final String? iconAsset;

  const TontineStatEntity({required this.label, required this.value, this.iconAsset});
}
