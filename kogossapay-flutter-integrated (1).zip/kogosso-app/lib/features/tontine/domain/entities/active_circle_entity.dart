enum CircleBadgeType { upcoming, collection }

class ActiveCircleEntity {
  final String id;
  final String title;
  final String subtitle;
  final String badgeLabel;
  final CircleBadgeType badgeType;
  final double progress;
  final String progressLabel;
  final String? actionLabel;
  final double? contributionAmount;

  // TODO: replace with the downloaded Figma circle icon (asset path) once available.
  final String? iconAsset;

  const ActiveCircleEntity({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.badgeLabel,
    required this.badgeType,
    required this.progress,
    required this.progressLabel,
    this.actionLabel,
    this.contributionAmount,
    this.iconAsset,
  });
}
