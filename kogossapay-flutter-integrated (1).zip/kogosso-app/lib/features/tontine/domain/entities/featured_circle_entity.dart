class FeaturedCircleEntity {
  final String tag;
  final String title;
  final String description;
  final String targetLabel;
  final String targetValue;
  final String monthlyLabel;
  final String monthlyValue;
  final String buttonLabel;

  const FeaturedCircleEntity({
    required this.tag,
    required this.title,
    required this.description,
    required this.targetLabel,
    required this.targetValue,
    required this.monthlyLabel,
    required this.monthlyValue,
    required this.buttonLabel,
  });
}
