import '../entities/active_circle_entity.dart';
import '../entities/featured_circle_entity.dart';
import '../entities/tontine_stat_entity.dart';
import '../repositories/tontine_repository.dart';

class TontineDashboard {
  final List<ActiveCircleEntity> activeCircles;
  final FeaturedCircleEntity? featuredCircle;
  final List<TontineStatEntity> stats;

  const TontineDashboard({
    required this.activeCircles,
    required this.featuredCircle,
    required this.stats,
  });
}

class GetTontineDashboard {
  final TontineRepository repository;

  const GetTontineDashboard(this.repository);

  Future<TontineDashboard> call() async {
    final results = await Future.wait([
      repository.getActiveCircles(),
      repository.getFeaturedCircle(),
      repository.getStats(),
    ]);

    return TontineDashboard(
      activeCircles: results[0] as List<ActiveCircleEntity>,
      featuredCircle: results[1] as FeaturedCircleEntity?,
      stats: results[2] as List<TontineStatEntity>,
    );
  }
}
