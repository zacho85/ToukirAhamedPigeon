import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/tontine/domain/domain.dart';

class ActiveCircleCard extends StatelessWidget {
  final ActiveCircleEntity circle;
  final VoidCallback? onActionTap;

  const ActiveCircleCard({super.key, required this.circle, this.onActionTap});

  @override
  Widget build(BuildContext context) {
    final isCollection = circle.badgeType == CircleBadgeType.collection;
    final badgeColor = isCollection ? AppColors.primaryGreen : AppColors.gold;
    final badgeBg = isCollection
        ? AppColors.primaryGreenLight.withValues(alpha: 0.3)
        : AppColors.goldLight.withValues(alpha: 0.5);
    final progressColor = isCollection ? AppColors.primaryGreen : AppColors.gold;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // TODO: replace with the downloaded Figma circle icon (circle.iconAsset).
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: progressColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Icon(Icons.groups_outlined, size: 20, color: progressColor),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: badgeBg,
                  borderRadius: BorderRadius.circular(9999),
                ),
                child: Text(
                  circle.badgeLabel,
                  style: AppTextStyles.badge.copyWith(color: badgeColor, fontSize: 11),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Text(circle.title, style: AppTextStyles.transactionTitle.copyWith(fontSize: 18)),
          const SizedBox(height: 4),
          Text(
            circle.subtitle,
            style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
          ),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                isCollection ? 'Collection Progress' : 'Progress',
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
              ),
              if (!isCollection)
                Text(
                  circle.progressLabel,
                  style: AppTextStyles.badge.copyWith(color: progressColor, letterSpacing: 0),
                ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: circle.progress.clamp(0.0, 1.0),
              minHeight: 8,
              backgroundColor: AppColors.progressTrack,
              valueColor: AlwaysStoppedAnimation(progressColor),
            ),
          ),
          if (isCollection) ...[
            const SizedBox(height: 4),
            Text(
              circle.progressLabel,
              style: AppTextStyles.badge.copyWith(color: progressColor, letterSpacing: 0),
            ),
          ],
          if (circle.actionLabel != null) ...[
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: onActionTap,
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.primaryGreen,
                  side: const BorderSide(color: AppColors.primaryGreen),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                ),
                child: Text(
                  circle.actionLabel!,
                  style: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600, fontSize: 14),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
