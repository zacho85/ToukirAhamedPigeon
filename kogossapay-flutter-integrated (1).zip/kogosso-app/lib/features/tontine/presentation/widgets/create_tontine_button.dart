import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';

class CreateTontineButton extends StatelessWidget {
  final VoidCallback? onTap;

  const CreateTontineButton({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: onTap ?? () {},
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryGreen,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
          elevation: 0,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // TODO: replace with the downloaded Figma create-circle icon.
            const Icon(Icons.group_add_outlined, size: 20),
            const SizedBox(width: 8),
            Text(
              'Create Tontine',
              style: AppTextStyles.transactionTitle.copyWith(color: Colors.white),
            ),
          ],
        ),
      ),
    );
  }
}
