import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/tontine/domain/domain.dart';

class FeaturedCircleCard extends StatelessWidget {
  final FeaturedCircleEntity circle;
  final VoidCallback? onTap;

  const FeaturedCircleCard({super.key, required this.circle, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: AppColors.balanceCardGradient,
        boxShadow: [
          BoxShadow(color: const Color(0xFF000B25).withValues(alpha: 0.15), offset: const Offset(0, 12), blurRadius: 24),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // TODO: replace with the downloaded Figma bolt/lightning icon.
              const Icon(Icons.bolt_rounded, size: 16, color: AppColors.goldLight),
              const SizedBox(width: 6),
              Text(
                circle.tag,
                style: AppTextStyles.badge.copyWith(color: AppColors.goldLight, letterSpacing: 0.3),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            circle.title,
            style: const TextStyle(
              fontFamily: 'PlusJakartaSans',
              fontWeight: FontWeight.w700,
              fontSize: 24,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            circle.description,
            style: TextStyle(
              fontFamily: 'Inter',
              fontSize: 13,
              height: 1.4,
              color: Colors.white.withValues(alpha: 0.7),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(child: _Stat(label: circle.targetLabel, value: circle.targetValue)),
              Expanded(child: _Stat(label: circle.monthlyLabel, value: circle.monthlyValue)),
            ],
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: onTap,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.goldLight,
                foregroundColor: AppColors.darkNavy,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                elevation: 0,
              ),
              child: Text(
                circle.buttonLabel,
                style: const TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w700, fontSize: 14),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label;
  final String value;

  const _Stat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label.toUpperCase(),
          style: AppTextStyles.badge.copyWith(color: Colors.white.withValues(alpha: 0.6), fontSize: 10),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontFamily: 'PlusJakartaSans',
            fontWeight: FontWeight.w700,
            fontSize: 16,
            color: Colors.white,
          ),
        ),
      ],
    );
  }
}
