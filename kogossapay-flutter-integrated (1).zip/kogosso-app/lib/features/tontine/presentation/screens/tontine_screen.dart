import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/router/router.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/core/widgets/widgets.dart';
import 'package:kogosso_app/features/contribute/presentation/presentation.dart';

import '../providers/tontine_provider.dart';
import '../widgets/active_circle_card.dart';
import '../widgets/create_tontine_button.dart';
import '../widgets/featured_circle_card.dart';
import '../widgets/tontine_stats_grid.dart';

class TontineScreen extends ConsumerStatefulWidget {
  const TontineScreen({super.key});

  @override
  ConsumerState<TontineScreen> createState() => _TontineScreenState();
}

class _TontineScreenState extends ConsumerState<TontineScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(tontineProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(tontineProvider);

    if (state.status == TontineStatus.loading || state.status == TontineStatus.initial) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: CircularProgressIndicator(color: AppColors.primaryGreen)),
      );
    }

    if (state.status == TontineStatus.error) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        bottom: false,
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 96),
          child: Column(
            children: [
              const AppTopBar(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'E-tontine',
                      style: TextStyle(
                        fontFamily: 'PlusJakartaSans',
                        fontWeight: FontWeight.w700,
                        fontSize: 24,
                        color: AppColors.darkNavy,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Manage communal wealth with your circle',
                      style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                    ),
                    const SizedBox(height: 20),
                    const CreateTontineButton(),
                    const SizedBox(height: 32),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('Your Active Circles', style: AppTextStyles.sectionHeading),
                        Text(
                          '${state.activeCircles.length} Active',
                          style: AppTextStyles.quickActionLabel.copyWith(color: AppColors.primaryGreen),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    for (final circle in state.activeCircles) ...[
                      ActiveCircleCard(
                        circle: circle,
                        onActionTap: circle.contributionAmount == null
                            ? null
                            : () {
                                context.push(
                                  AppRoutes.contribute,
                                  extra: ContributeRouteArgs(
                                    circleTitle: circle.title,
                                    badgeLabel: circle.badgeLabel,
                                    progress: circle.progress,
                                    progressLabel: circle.progressLabel,
                                    scheduledAmount: circle.contributionAmount!,
                                  ),
                                );
                              },
                      ),
                      const SizedBox(height: 16),
                    ],
                    const SizedBox(height: 16),
                    if (state.activeCircles.isEmpty)
                      const Padding(
                        padding: EdgeInsets.only(bottom: 16),
                        child: Text('You have no active circles yet.', style: TextStyle(color: AppColors.greyText)),
                      ),
                    if (state.featuredCircle != null) ...[
                      const Text('Discover Public Circles', style: AppTextStyles.sectionHeading),
                      const SizedBox(height: 16),
                      FeaturedCircleCard(
                        circle: state.featuredCircle!,
                        onTap: () => context.push(AppRoutes.projectDetails),
                      ),
                      const SizedBox(height: 32),
                    ],
                    TontineStatsGrid(stats: state.stats),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
