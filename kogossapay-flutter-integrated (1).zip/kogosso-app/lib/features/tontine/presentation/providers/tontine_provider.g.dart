// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tontine_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(Tontine)
final tontineProvider = TontineProvider._();

final class TontineProvider extends $NotifierProvider<Tontine, TontineState> {
  TontineProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'tontineProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$tontineHash();

  @$internal
  @override
  Tontine create() => Tontine();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(TontineState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<TontineState>(value),
    );
  }
}

String _$tontineHash() => r'08fb4c0e2b6eb45e3dfa9969f0685f1e488909eb';

abstract class _$Tontine extends $Notifier<TontineState> {
  TontineState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<TontineState, TontineState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<TontineState, TontineState>,
              TontineState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
