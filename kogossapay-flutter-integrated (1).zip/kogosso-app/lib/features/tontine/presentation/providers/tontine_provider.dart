import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/auth/presentation/providers/auth_provider.dart';

import 'package:kogosso_app/features/tontine/data/data.dart';
import 'package:kogosso_app/features/tontine/domain/domain.dart';

import 'tontine_state.dart';

export 'tontine_state.dart';

part 'tontine_provider.g.dart';

@riverpod
class Tontine extends _$Tontine {
  GetTontineDashboard get _getTontineDashboard =>
      GetTontineDashboard(TontineRepositoryImpl(TontineRemoteDataSource(ref.read(kongossaApiProvider))));

  @override
  TontineState build() => const TontineState();

  Future<void> load() async {
    state = state.copyWith(status: TontineStatus.loading);
    try {
      final dashboard = await _getTontineDashboard();
      state = state.copyWith(
        status: TontineStatus.loaded,
        activeCircles: dashboard.activeCircles,
        featuredCircle: dashboard.featuredCircle,
        stats: dashboard.stats,
      );
    } catch (_) {
      state = state.copyWith(status: TontineStatus.error);
    }
  }
}
