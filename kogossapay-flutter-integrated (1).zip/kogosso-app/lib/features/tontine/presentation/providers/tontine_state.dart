import 'package:kogosso_app/features/tontine/domain/domain.dart';

import 'tontine_status.dart';

export 'tontine_status.dart';

class TontineState {
  final TontineStatus status;
  final List<ActiveCircleEntity> activeCircles;
  final FeaturedCircleEntity? featuredCircle;
  final List<TontineStatEntity> stats;

  const TontineState({
    this.status = TontineStatus.initial,
    this.activeCircles = const [],
    this.featuredCircle,
    this.stats = const [],
  });

  TontineState copyWith({
    TontineStatus? status,
    List<ActiveCircleEntity>? activeCircles,
    FeaturedCircleEntity? featuredCircle,
    List<TontineStatEntity>? stats,
  }) {
    return TontineState(
      status: status ?? this.status,
      activeCircles: activeCircles ?? this.activeCircles,
      featuredCircle: featuredCircle ?? this.featuredCircle,
      stats: stats ?? this.stats,
    );
  }
}
