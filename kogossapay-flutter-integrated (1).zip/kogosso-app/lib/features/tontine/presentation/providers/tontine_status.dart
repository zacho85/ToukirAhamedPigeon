enum TontineStatus { initial, loading, loaded, error }
