enum ActivityDetailCategory { food, bills, transfers, investment }

class ActivityDetailEntity {
  final ActivityDetailCategory category;
  final String label;
  final double amount;
  final bool isCredit;

  const ActivityDetailEntity({
    required this.category,
    required this.label,
    required this.amount,
    required this.isCredit,
  });
}
