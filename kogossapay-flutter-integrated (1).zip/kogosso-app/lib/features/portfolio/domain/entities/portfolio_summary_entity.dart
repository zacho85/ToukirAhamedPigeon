class PortfolioSummaryEntity {
  final double balance;
  final double changePercent;
  final String changeLabel;

  const PortfolioSummaryEntity({
    required this.balance,
    required this.changePercent,
    required this.changeLabel,
  });
}
