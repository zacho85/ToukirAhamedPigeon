enum AssetShareType { cash, crypto, tontine }

class AssetShareEntity {
  final String label;
  final double percent;
  final AssetShareType type;

  const AssetShareEntity({required this.label, required this.percent, required this.type});
}
