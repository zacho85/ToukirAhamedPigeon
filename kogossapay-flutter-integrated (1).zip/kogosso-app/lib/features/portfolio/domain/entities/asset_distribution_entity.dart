import 'asset_share_entity.dart';

class AssetDistributionEntity {
  final double liquidPercent;
  final List<AssetShareEntity> shares;

  const AssetDistributionEntity({required this.liquidPercent, required this.shares});
}
