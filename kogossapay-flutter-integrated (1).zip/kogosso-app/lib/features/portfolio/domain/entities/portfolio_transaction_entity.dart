enum PortfolioTransactionType { income, spend }

class PortfolioTransactionEntity {
  final String id;
  final String title;
  final String date;
  final String category;
  final double amount;
  final PortfolioTransactionType type;

  const PortfolioTransactionEntity({
    required this.id,
    required this.title,
    required this.date,
    required this.category,
    required this.amount,
    required this.type,
  });
}
