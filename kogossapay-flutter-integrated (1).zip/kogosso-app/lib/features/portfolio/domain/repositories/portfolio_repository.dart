import '../entities/activity_detail_entity.dart';
import '../entities/asset_distribution_entity.dart';
import '../entities/portfolio_summary_entity.dart';
import '../entities/portfolio_transaction_entity.dart';

abstract class PortfolioRepository {
  Future<PortfolioSummaryEntity> getSummary();
  Future<AssetDistributionEntity> getAssetDistribution();
  Future<List<ActivityDetailEntity>> getActivityDetails();
  Future<List<PortfolioTransactionEntity>> getRecentTransactions();
}
