import '../entities/activity_detail_entity.dart';
import '../entities/asset_distribution_entity.dart';
import '../entities/portfolio_summary_entity.dart';
import '../entities/portfolio_transaction_entity.dart';
import '../repositories/portfolio_repository.dart';

class PortfolioDashboard {
  final PortfolioSummaryEntity summary;
  final AssetDistributionEntity assetDistribution;
  final List<ActivityDetailEntity> activityDetails;
  final List<PortfolioTransactionEntity> recentTransactions;

  const PortfolioDashboard({
    required this.summary,
    required this.assetDistribution,
    required this.activityDetails,
    required this.recentTransactions,
  });
}

class GetPortfolioDashboard {
  final PortfolioRepository repository;

  const GetPortfolioDashboard(this.repository);

  Future<PortfolioDashboard> call() async {
    final results = await Future.wait([
      repository.getSummary(),
      repository.getAssetDistribution(),
      repository.getActivityDetails(),
      repository.getRecentTransactions(),
    ]);

    return PortfolioDashboard(
      summary: results[0] as PortfolioSummaryEntity,
      assetDistribution: results[1] as AssetDistributionEntity,
      activityDetails: results[2] as List<ActivityDetailEntity>,
      recentTransactions: results[3] as List<PortfolioTransactionEntity>,
    );
  }
}
