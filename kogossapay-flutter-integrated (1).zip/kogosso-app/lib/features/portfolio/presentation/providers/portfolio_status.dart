enum PortfolioStatus { initial, loading, loaded, error }
