import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/portfolio/data/data.dart';
import 'package:kogosso_app/features/portfolio/domain/domain.dart';

import 'portfolio_state.dart';

export 'portfolio_state.dart';

part 'portfolio_provider.g.dart';

@riverpod
class Portfolio extends _$Portfolio {
  GetPortfolioDashboard get _getPortfolioDashboard =>
      GetPortfolioDashboard(PortfolioRepositoryImpl(PortfolioLocalDataSourceImpl()));

  @override
  PortfolioState build() => const PortfolioState();

  Future<void> load() async {
    state = state.copyWith(status: PortfolioStatus.loading);
    try {
      final dashboard = await _getPortfolioDashboard();
      state = state.copyWith(
        status: PortfolioStatus.loaded,
        summary: dashboard.summary,
        assetDistribution: dashboard.assetDistribution,
        activityDetails: dashboard.activityDetails,
        recentTransactions: dashboard.recentTransactions,
      );
    } catch (_) {
      state = state.copyWith(status: PortfolioStatus.error);
    }
  }
}
