// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'portfolio_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(Portfolio)
final portfolioProvider = PortfolioProvider._();

final class PortfolioProvider
    extends $NotifierProvider<Portfolio, PortfolioState> {
  PortfolioProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'portfolioProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$portfolioHash();

  @$internal
  @override
  Portfolio create() => Portfolio();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PortfolioState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PortfolioState>(value),
    );
  }
}

String _$portfolioHash() => r'60ebfe9cfdba47b2d897ee923b209b05d7f66c5a';

abstract class _$Portfolio extends $Notifier<PortfolioState> {
  PortfolioState build();
  @$mustCallSuper
  @override
  void runBuild() {
    final ref = this.ref as $Ref<PortfolioState, PortfolioState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<PortfolioState, PortfolioState>,
              PortfolioState,
              Object?,
              Object?
            >;
    element.handleCreate(ref, build);
  }
}
