import 'package:kogosso_app/features/portfolio/domain/domain.dart';

import 'portfolio_status.dart';

export 'portfolio_status.dart';

class PortfolioState {
  final PortfolioStatus status;
  final PortfolioSummaryEntity? summary;
  final AssetDistributionEntity? assetDistribution;
  final List<ActivityDetailEntity> activityDetails;
  final List<PortfolioTransactionEntity> recentTransactions;

  const PortfolioState({
    this.status = PortfolioStatus.initial,
    this.summary,
    this.assetDistribution,
    this.activityDetails = const [],
    this.recentTransactions = const [],
  });

  PortfolioState copyWith({
    PortfolioStatus? status,
    PortfolioSummaryEntity? summary,
    AssetDistributionEntity? assetDistribution,
    List<ActivityDetailEntity>? activityDetails,
    List<PortfolioTransactionEntity>? recentTransactions,
  }) {
    return PortfolioState(
      status: status ?? this.status,
      summary: summary ?? this.summary,
      assetDistribution: assetDistribution ?? this.assetDistribution,
      activityDetails: activityDetails ?? this.activityDetails,
      recentTransactions: recentTransactions ?? this.recentTransactions,
    );
  }
}
