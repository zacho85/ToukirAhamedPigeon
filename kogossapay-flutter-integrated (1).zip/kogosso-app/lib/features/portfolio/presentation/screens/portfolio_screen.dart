import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/core/widgets/widgets.dart';

import '../providers/portfolio_provider.dart';
import '../widgets/activity_detail_list.dart';
import '../widgets/asset_distribution_card.dart';
import '../widgets/portfolio_balance_card.dart';
import '../widgets/portfolio_transaction_list.dart';

class PortfolioScreen extends ConsumerStatefulWidget {
  const PortfolioScreen({super.key});

  @override
  ConsumerState<PortfolioScreen> createState() => _PortfolioScreenState();
}

class _PortfolioScreenState extends ConsumerState<PortfolioScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(portfolioProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(portfolioProvider);

    if (state.status == PortfolioStatus.loading || state.status == PortfolioStatus.initial) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: CircularProgressIndicator(color: AppColors.primaryGreen)),
      );
    }

    if (state.status == PortfolioStatus.error ||
        state.summary == null ||
        state.assetDistribution == null) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.only(bottom: 32),
          child: Column(
            children: [
              const AppTopBar(),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    PortfolioBalanceCard(summary: state.summary!),
                    const SizedBox(height: 24),
                    AssetDistributionCard(distribution: state.assetDistribution!),
                    const SizedBox(height: 24),
                    ActivityDetailList(details: state.activityDetails),
                    const SizedBox(height: 24),
                    PortfolioTransactionList(transactions: state.recentTransactions),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
