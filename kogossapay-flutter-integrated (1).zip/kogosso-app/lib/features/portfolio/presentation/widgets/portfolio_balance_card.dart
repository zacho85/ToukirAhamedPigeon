import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/portfolio/domain/domain.dart';

class PortfolioBalanceCard extends StatefulWidget {
  final PortfolioSummaryEntity summary;

  const PortfolioBalanceCard({super.key, required this.summary});

  @override
  State<PortfolioBalanceCard> createState() => _PortfolioBalanceCardState();
}

class _PortfolioBalanceCardState extends State<PortfolioBalanceCard> {
  bool _isVisible = true;

  @override
  Widget build(BuildContext context) {
    final isPositive = widget.summary.changePercent >= 0;
    final changeColor = isPositive ? AppColors.primaryGreen : AppColors.errorRed;
    final balanceLabel = _isVisible
        ? 'FCFA ${widget.summary.balance.toStringAsFixed(0)}'
        : 'FCFA ••••••';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'Total Portfolio Balance',
                  style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0.3),
                ),
              ),
              // TODO: replace with the downloaded Figma portfolio/wallet icon.
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: AppColors.background,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(Icons.credit_card_outlined, size: 16, color: AppColors.greyText),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Text(
                  balanceLabel,
                  style: const TextStyle(
                    fontFamily: 'PlusJakartaSans',
                    fontWeight: FontWeight.w700,
                    fontSize: 32,
                    color: AppColors.darkNavy,
                  ),
                ),
              ),
              GestureDetector(
                onTap: () => setState(() => _isVisible = !_isVisible),
                child: Icon(
                  _isVisible ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                  size: 20,
                  color: AppColors.greyText,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Icon(
                isPositive ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded,
                size: 14,
                color: changeColor,
              ),
              const SizedBox(width: 4),
              Text(
                '${isPositive ? '+' : ''}${widget.summary.changePercent.toStringAsFixed(1)}% ${widget.summary.changeLabel}',
                style: AppTextStyles.badge.copyWith(color: changeColor, letterSpacing: 0),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            children: [
              Expanded(
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGreen,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                    elevation: 0,
                  ),
                  child: const Text(
                    '+ Add Funds',
                    style: TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: OutlinedButton(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(
                    foregroundColor: AppColors.darkNavy,
                    side: BorderSide(color: Colors.grey.withValues(alpha: 0.3)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9999)),
                  ),
                  child: const Text(
                    'Transfer',
                    style: TextStyle(fontFamily: 'Inter', fontWeight: FontWeight.w600, fontSize: 14),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
