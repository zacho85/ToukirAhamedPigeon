import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/portfolio/domain/domain.dart';

enum _TransactionFilter { all, income, spend }

class PortfolioTransactionList extends StatefulWidget {
  final List<PortfolioTransactionEntity> transactions;

  const PortfolioTransactionList({super.key, required this.transactions});

  @override
  State<PortfolioTransactionList> createState() => _PortfolioTransactionListState();
}

class _PortfolioTransactionListState extends State<PortfolioTransactionList> {
  _TransactionFilter _filter = _TransactionFilter.all;

  @override
  Widget build(BuildContext context) {
    final filtered = widget.transactions.where((t) {
      if (_filter == _TransactionFilter.income) return t.type == PortfolioTransactionType.income;
      if (_filter == _TransactionFilter.spend) return t.type == PortfolioTransactionType.spend;
      return true;
    }).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Recent Transactions', style: AppTextStyles.sectionHeading),
            Row(
              children: [
                _FilterPill(
                  label: 'All',
                  isActive: _filter == _TransactionFilter.all,
                  onTap: () => setState(() => _filter = _TransactionFilter.all),
                ),
                const SizedBox(width: 8),
                _FilterPill(
                  label: 'Income',
                  isActive: _filter == _TransactionFilter.income,
                  onTap: () => setState(() => _filter = _TransactionFilter.income),
                ),
                const SizedBox(width: 8),
                _FilterPill(
                  label: 'Spend',
                  isActive: _filter == _TransactionFilter.spend,
                  onTap: () => setState(() => _filter = _TransactionFilter.spend),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                offset: const Offset(0, 1),
                blurRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              for (int i = 0; i < filtered.length; i++) ...[
                _TransactionTile(transaction: filtered[i]),
                if (i < filtered.length - 1) Container(height: 1, color: AppColors.divider),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _FilterPill extends StatelessWidget {
  final String label;
  final bool isActive;
  final VoidCallback onTap;

  const _FilterPill({required this.label, required this.isActive, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Text(
        label,
        style: AppTextStyles.quickActionLabel.copyWith(
          color: isActive ? AppColors.primaryGreen : AppColors.greyText,
          fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
        ),
      ),
    );
  }
}

class _TransactionTile extends StatelessWidget {
  final PortfolioTransactionEntity transaction;

  const _TransactionTile({required this.transaction});

  @override
  Widget build(BuildContext context) {
    final isCredit = transaction.type == PortfolioTransactionType.income;
    final amountColor = isCredit ? AppColors.primaryGreen : AppColors.errorRed;
    final sign = isCredit ? '+' : '-';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      child: Row(
        children: [
          // TODO: replace with the downloaded Figma merchant/category icon.
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.darkNavy.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Center(
              child: Text(
                transaction.title.substring(0, 1),
                style: const TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontWeight: FontWeight.w700,
                  fontSize: 16,
                  color: AppColors.darkNavy,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(transaction.title, style: AppTextStyles.transactionTitle),
                const SizedBox(height: 4),
                Text(
                  transaction.date,
                  style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '$sign${transaction.amount.toStringAsFixed(0)} FCFA',
                style: AppTextStyles.transactionAmount.copyWith(color: amountColor),
              ),
              const SizedBox(height: 4),
              Text(
                transaction.category,
                style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
