import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/portfolio/domain/domain.dart';

import 'donut_chart.dart';

class AssetDistributionCard extends StatelessWidget {
  final AssetDistributionEntity distribution;

  const AssetDistributionCard({super.key, required this.distribution});

  static Color _colorFor(AssetShareType type) => switch (type) {
    AssetShareType.cash => AppColors.darkNavy,
    AssetShareType.crypto => AppColors.primaryGreen,
    AssetShareType.tontine => AppColors.gold,
  };

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            offset: const Offset(0, 1),
            blurRadius: 2,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Asset Distribution', style: AppTextStyles.sectionHeading),
          const SizedBox(height: 20),
          Center(
            child: DonutChart(
              values: [for (final s in distribution.shares) s.percent],
              colors: [for (final s in distribution.shares) _colorFor(s.type)],
              center: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '${distribution.liquidPercent.toStringAsFixed(0)}%',
                    style: const TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontWeight: FontWeight.w700,
                      fontSize: 22,
                      color: AppColors.darkNavy,
                    ),
                  ),
                  Text(
                    'Liquid',
                    style: AppTextStyles.badge.copyWith(color: AppColors.greyText, letterSpacing: 0),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          for (final share in distribution.shares) ...[
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: _colorFor(share.type),
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      share.label,
                      style: AppTextStyles.transactionTitle.copyWith(fontSize: 14),
                    ),
                  ),
                  Text(
                    '${share.percent.toStringAsFixed(0)}%',
                    style: AppTextStyles.transactionTitle.copyWith(fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
