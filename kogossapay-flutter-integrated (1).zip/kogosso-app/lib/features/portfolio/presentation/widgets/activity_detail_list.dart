import 'package:flutter/material.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/portfolio/domain/domain.dart';

class ActivityDetailList extends StatelessWidget {
  final List<ActivityDetailEntity> details;

  const ActivityDetailList({super.key, required this.details});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('Activity Detail', style: AppTextStyles.sectionHeading),
            Text(
              'View All',
              style: AppTextStyles.quickActionLabel.copyWith(color: AppColors.primaryGreen),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                offset: const Offset(0, 1),
                blurRadius: 2,
              ),
            ],
          ),
          child: Column(
            children: [
              for (int i = 0; i < details.length; i++) ...[
                _ActivityDetailTile(detail: details[i]),
                if (i < details.length - 1) Container(height: 1, color: AppColors.divider),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

class _ActivityDetailTile extends StatelessWidget {
  final ActivityDetailEntity detail;

  const _ActivityDetailTile({required this.detail});

  // TODO: replace with the downloaded Figma category icons.
  static const _icons = {
    ActivityDetailCategory.food: Icons.restaurant_outlined,
    ActivityDetailCategory.bills: Icons.receipt_long_outlined,
    ActivityDetailCategory.transfers: Icons.swap_horiz_rounded,
    ActivityDetailCategory.investment: Icons.trending_up_rounded,
  };

  @override
  Widget build(BuildContext context) {
    final amountColor = detail.isCredit ? AppColors.primaryGreen : AppColors.errorRed;
    final sign = detail.isCredit ? '+' : '-';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppColors.background,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(_icons[detail.category], size: 18, color: AppColors.darkNavy),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(detail.label, style: AppTextStyles.transactionTitle.copyWith(fontSize: 15)),
          ),
          Text(
            '$sign${detail.amount.toStringAsFixed(0)} FCFA',
            style: AppTextStyles.transactionAmount.copyWith(color: amountColor, fontSize: 14),
          ),
        ],
      ),
    );
  }
}
