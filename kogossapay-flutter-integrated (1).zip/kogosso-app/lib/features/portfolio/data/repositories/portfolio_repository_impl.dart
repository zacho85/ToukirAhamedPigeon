import 'package:kogosso_app/features/portfolio/domain/domain.dart';

import '../datasources/portfolio_local_datasource.dart';

class PortfolioRepositoryImpl implements PortfolioRepository {
  final PortfolioLocalDataSource localDataSource;

  const PortfolioRepositoryImpl(this.localDataSource);

  @override
  Future<PortfolioSummaryEntity> getSummary() => localDataSource.fetchSummary();

  @override
  Future<AssetDistributionEntity> getAssetDistribution() =>
      localDataSource.fetchAssetDistribution();

  @override
  Future<List<ActivityDetailEntity>> getActivityDetails() =>
      localDataSource.fetchActivityDetails();

  @override
  Future<List<PortfolioTransactionEntity>> getRecentTransactions() =>
      localDataSource.fetchRecentTransactions();
}
