import 'package:kogosso_app/features/portfolio/domain/domain.dart';

abstract class PortfolioLocalDataSource {
  Future<PortfolioSummaryEntity> fetchSummary();
  Future<AssetDistributionEntity> fetchAssetDistribution();
  Future<List<ActivityDetailEntity>> fetchActivityDetails();
  Future<List<PortfolioTransactionEntity>> fetchRecentTransactions();
}

class PortfolioLocalDataSourceImpl implements PortfolioLocalDataSource {
  @override
  Future<PortfolioSummaryEntity> fetchSummary() async => const PortfolioSummaryEntity(
    balance: 4850200,
    changePercent: 12.4,
    changeLabel: 'this month',
  );

  @override
  Future<AssetDistributionEntity> fetchAssetDistribution() async => const AssetDistributionEntity(
    liquidPercent: 85,
    shares: [
      AssetShareEntity(label: 'Cash', percent: 60, type: AssetShareType.cash),
      AssetShareEntity(label: 'Crypto', percent: 25, type: AssetShareType.crypto),
      AssetShareEntity(label: 'Tontine', percent: 15, type: AssetShareType.tontine),
    ],
  );

  // TODO: swap the icon placeholders below for the real category SVGs
  // once they're downloaded from Figma (see AppIcons for the pattern).
  @override
  Future<List<ActivityDetailEntity>> fetchActivityDetails() async => const [
    ActivityDetailEntity(
      category: ActivityDetailCategory.food,
      label: 'Food',
      amount: 12500,
      isCredit: false,
    ),
    ActivityDetailEntity(
      category: ActivityDetailCategory.bills,
      label: 'Bills',
      amount: 45000,
      isCredit: false,
    ),
    ActivityDetailEntity(
      category: ActivityDetailCategory.transfers,
      label: 'Transfers',
      amount: 150000,
      isCredit: true,
    ),
    ActivityDetailEntity(
      category: ActivityDetailCategory.investment,
      label: 'Investment',
      amount: 8200,
      isCredit: true,
    ),
  ];

  @override
  Future<List<PortfolioTransactionEntity>> fetchRecentTransactions() async => const [
    PortfolioTransactionEntity(
      id: 'p1',
      title: 'Supermarche Casino',
      date: 'Today, 2:45 PM',
      category: 'Food & Dining',
      amount: 18200,
      type: PortfolioTransactionType.spend,
    ),
    PortfolioTransactionEntity(
      id: 'p2',
      title: 'Binance Withdrawal',
      date: 'Yesterday, 10:12 AM',
      category: 'Investment',
      amount: 425000,
      type: PortfolioTransactionType.income,
    ),
    PortfolioTransactionEntity(
      id: 'p3',
      title: "Tontine 'Les Amis'",
      date: 'Oct 24, 2023',
      category: 'Savings',
      amount: 50000,
      type: PortfolioTransactionType.spend,
    ),
  ];
}
