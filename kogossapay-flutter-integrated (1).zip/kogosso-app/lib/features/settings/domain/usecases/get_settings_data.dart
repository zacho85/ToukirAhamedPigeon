import '../entities/settings_menu_item_entity.dart';
import '../entities/user_profile_entity.dart';
import '../repositories/settings_repository.dart';

class SettingsData {
  final UserProfileEntity profile;
  final List<SettingsMenuItemEntity> menuItems;
  final String appVersion;

  const SettingsData({required this.profile, required this.menuItems, required this.appVersion});
}

class GetSettingsData {
  final SettingsRepository repository;

  const GetSettingsData(this.repository);

  Future<SettingsData> call() async {
    final results = await Future.wait([
      repository.getUserProfile(),
      repository.getMenuItems(),
      repository.getAppVersion(),
    ]);

    return SettingsData(
      profile: results[0] as UserProfileEntity,
      menuItems: results[1] as List<SettingsMenuItemEntity>,
      appVersion: results[2] as String,
    );
  }
}