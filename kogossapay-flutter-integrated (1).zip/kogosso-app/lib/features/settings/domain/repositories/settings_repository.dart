import '../entities/settings_menu_item_entity.dart';
import '../entities/user_profile_entity.dart';

abstract class SettingsRepository {
  Future<UserProfileEntity> getUserProfile();

  Future<List<SettingsMenuItemEntity>> getMenuItems();

  Future<String> getAppVersion();
}