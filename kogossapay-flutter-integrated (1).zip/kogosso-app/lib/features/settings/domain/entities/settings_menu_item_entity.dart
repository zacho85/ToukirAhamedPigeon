enum SettingsMenuIcon { personalInfo, security, verification, budget, subscription }

class SettingsMenuItemEntity {
  final String id;
  final String title;
  final String subtitle;
  final SettingsMenuIcon icon;
  final String? badgeLabel;

  const SettingsMenuItemEntity({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    this.badgeLabel,
  });
}
