class UserProfileEntity {
  final String name;
  final String phoneNumber;
  final String verificationTier;
  final double mainBalance;
  final int rewardsPoints;

  const UserProfileEntity({
    required this.name,
    required this.phoneNumber,
    required this.verificationTier,
    required this.mainBalance,
    required this.rewardsPoints,
  });
}
