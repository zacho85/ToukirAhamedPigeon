import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kogosso_app/core/router/router.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/core/widgets/widgets.dart';

import 'package:kogosso_app/features/auth/presentation/providers/auth_provider.dart';
import '../providers/settings_provider.dart';
import '../widgets/logout_card.dart';
import '../widgets/profile_header_card.dart';
import '../widgets/settings_footer.dart';
import '../widgets/settings_menu_list.dart';
import '../widgets/stat_summary_row.dart';

class SettingsScreen extends ConsumerStatefulWidget {
  const SettingsScreen({super.key});

  @override
  ConsumerState<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends ConsumerState<SettingsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(settingsProvider.notifier).load();
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(settingsProvider);

    if (state.status == SettingsStatus.loading || state.status == SettingsStatus.initial) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(child: CircularProgressIndicator(color: AppColors.primaryGreen)),
      );
    }

    if (state.status == SettingsStatus.error || state.profile == null) {
      return const Scaffold(
        backgroundColor: AppColors.background,
        body: Center(
          child: Text('Something went wrong', style: TextStyle(color: AppColors.greyText)),
        ),
      );
    }

    final profile = state.profile!;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SingleChildScrollView(
        padding: EdgeInsets.only(bottom: 96, top: MediaQuery.of(context).padding.top + 8),
        child: Column(
          children: [
            const Padding(padding: EdgeInsets.symmetric(horizontal: 20), child: AppTopBar()),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 24),
                  ProfileHeaderCard(profile: profile),
                  const SizedBox(height: 32),
                  StatSummaryRow(
                    mainBalance: profile.mainBalance,
                    rewardsPoints: profile.rewardsPoints,
                  ),
                  const SizedBox(height: 32),
                  const Padding(
                    padding: EdgeInsets.only(left: 8),
                    child: Text(
                      'Account Settings',
                      style: TextStyle(fontSize: 16, color: Color(0xFF44474E)),
                    ),
                  ),
                  const SizedBox(height: 16),
                  SettingsMenuList(
                    items: state.menuItems,
                    onItemTap: (item) {
                      if (item.id == 'budget') {
                        context.push(AppRoutes.budget);
                      } else if (item.id == 'subscription') {
                        context.push(AppRoutes.subscription);
                      }
                    },
                  ),
                  const SizedBox(height: 16),
                  LogoutCard(onTap: () => ref.read(authProvider.notifier).logout()),
                  const SizedBox(height: 32),
                  Center(child: SettingsFooter(appVersion: state.appVersion)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
