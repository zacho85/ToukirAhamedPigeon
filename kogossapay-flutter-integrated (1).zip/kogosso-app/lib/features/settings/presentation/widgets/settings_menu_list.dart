import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kogosso_app/core/theme/src/app_icons.dart';

import '../../domain/entities/settings_menu_item_entity.dart';

class SettingsMenuList extends StatelessWidget {
  final List<SettingsMenuItemEntity> items;
  final ValueChanged<SettingsMenuItemEntity>? onItemTap;

  const SettingsMenuList({super.key, required this.items, this.onItemTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: Colors.grey.withValues(alpha: 0.08),
        ),
      ),
      child: Column(
        children: [
          for (var i = 0; i < items.length; i++) ...[
            _SettingsMenuTile(
              item: items[i],
              isLast: i == items.length - 1,
              onTap: onItemTap == null ? null : () => onItemTap!(items[i]),
            ),
            if (i != items.length - 1)
              Divider(
                height: 1,
                color: Colors.grey.withValues(alpha: 0.12),
                indent: 20,
                endIndent: 20,
              ),
          ],
        ],
      ),
    );
  }
}

class _SettingsMenuTile extends StatelessWidget {
  final SettingsMenuItemEntity item;
  final bool isLast;
  final VoidCallback? onTap;

  const _SettingsMenuTile({
    required this.item,
    required this.isLast,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final style = switch (item.icon) {
      SettingsMenuIcon.personalInfo => (
          bgColor: const Color(0xFFD8E2FF),
          icon: AppIcons.user,
          iconColor: const Color(0xFF3B5998),
        ),
      SettingsMenuIcon.security => (
          bgColor: const Color(0xFF56FBAB),
          icon: AppIcons.security,
          iconColor: const Color(0xFF006D43),
        ),
      SettingsMenuIcon.verification => (
          bgColor: const Color(0xFFFFE16D),
          icon: AppIcons.verification,
          iconColor: const Color(0xFF705D00),
        ),
      SettingsMenuIcon.budget => (
          bgColor: const Color(0xFFD8E2FF),
          icon: AppIcons.reward,
          iconColor: const Color(0xFF3B5998),
        ),
      SettingsMenuIcon.subscription => (
          bgColor: const Color(0xFFFFE16D),
          icon: AppIcons.reward,
          iconColor: const Color(0xFF705D00),
        ),
    };

    return InkWell(
      onTap: onTap ?? () {},
      borderRadius: isLast
          ? const BorderRadius.vertical(bottom: Radius.circular(24))
          : BorderRadius.circular(24),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: style.bgColor,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Center(
                child: SvgPicture.asset(
                  style.icon,
                  width: 20,
                  height: 20,
                  colorFilter: ColorFilter.mode(style.iconColor, BlendMode.srcIn),
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.title,
                    style: const TextStyle(
                      fontSize: 16,
                      color: Color(0xFF000B25),
                    ),
                  ),
                  Text(
                    item.subtitle,
                    style: const TextStyle(
                      fontFamily: 'PlusJakartaSans',
                      fontSize: 12,
                      color: Color(0xFF44474E),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (item.badgeLabel != null) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 8,
                      vertical: 2,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFF56FBAB),
                      borderRadius: BorderRadius.circular(9999),
                    ),
                    child: Text(
                      item.badgeLabel!,
                      style: const TextStyle(
                        fontFamily: 'PlusJakartaSans',
                        fontWeight: FontWeight.w700,
                        fontSize: 10,
                        color: Color(0xFF007146),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
                SvgPicture.asset(
                  AppIcons.arrowRight,
                  width: 16,
                  height: 16,
                  colorFilter: const ColorFilter.mode(Color(0xFF75777F), BlendMode.srcIn),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

