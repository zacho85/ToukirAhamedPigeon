import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kogosso_app/core/theme/src/app_icons.dart';

class LogoutCard extends StatelessWidget {
  final VoidCallback? onTap;

  const LogoutCard({super.key, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.06),
            blurRadius: 12,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: Colors.grey.withValues(alpha: 0.08),
        ),
      ),
      child: InkWell(
        onTap: onTap ?? () {},
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFDAD6),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Center(
                  child: SvgPicture.asset(
                    AppIcons.logout,
                    width: 20,
                    height: 20,
                    colorFilter: const ColorFilter.mode(Color(0xFFBA1A1A), BlendMode.srcIn),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Logout',
                      style: TextStyle(
                        fontSize: 16,
                        color: Color(0xFF000B25),
                      ),
                    ),
                    Text(
                      'Sign out of your account',
                      style: TextStyle(
                        fontFamily: 'PlusJakartaSans',
                        fontSize: 12,
                        color: Color(0xFF44474E),
                      ),
                    ),
                  ],
                ),
              ),
              SvgPicture.asset(
                AppIcons.logoutAlt,
                width: 18,
                height: 18,
                colorFilter: const ColorFilter.mode(Color(0xFFBA1A1A), BlendMode.srcIn),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

