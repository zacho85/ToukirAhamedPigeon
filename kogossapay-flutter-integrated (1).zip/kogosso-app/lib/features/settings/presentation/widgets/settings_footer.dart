import 'package:flutter/material.dart';

class SettingsFooter extends StatelessWidget {
  final String appVersion;

  const SettingsFooter({super.key, required this.appVersion});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          appVersion,
          style: const TextStyle(
            fontFamily: 'PlusJakartaSans',
            fontSize: 12,
            color: Color(0xFF75777F),
          ),
        ),
        const SizedBox(height: 4),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GestureDetector(
              onTap: () {},
              child: const Text(
                'Privacy Policy',
                style: TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontWeight: FontWeight.w500,
                  fontSize: 12,
                  color: Color(0xFF000B25),
                ),
              ),
            ),
            const SizedBox(width: 16),
            GestureDetector(
              onTap: () {},
              child: const Text(
                'Terms of Service',
                style: TextStyle(
                  fontFamily: 'PlusJakartaSans',
                  fontWeight: FontWeight.w500,
                  fontSize: 12,
                  color: Color(0xFF000B25),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

