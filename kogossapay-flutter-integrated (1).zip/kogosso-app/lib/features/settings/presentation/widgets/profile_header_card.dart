import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:kogosso_app/core/theme/theme.dart';
import 'package:kogosso_app/features/settings/domain/domain.dart';

class ProfileHeaderCard extends StatelessWidget {
  final UserProfileEntity profile;

  const ProfileHeaderCard({super.key, required this.profile});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: AppColors.balanceCardGradient,
        boxShadow: [
          BoxShadow(color: const Color(0xFF000B25).withValues(alpha: 0.15), offset: const Offset(0, 20), blurRadius: 40),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
        child: Column(
          children: [
            Container(
              width: 96,
              height: 96,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white.withValues(alpha: 0.3), width: 3),
              ),
              child: CircleAvatar(
                radius: 40,
                backgroundColor: const Color(0xFF000B25),
                child: SvgPicture.asset(
                  AppIcons.user,
                  width: 40,
                  height: 40,
                  colorFilter: const ColorFilter.mode(Colors.white70, BlendMode.srcIn),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              profile.name,
              style: const TextStyle(
                fontFamily: 'PlusJakartaSans',
                fontWeight: FontWeight.w700,
                fontSize: 24,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 4),
            Text(profile.phoneNumber, style: const TextStyle(fontSize: 16, color: Colors.white)),
            if (profile.verificationTier.isNotEmpty) ...[
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(color: const Color(0xFF006D43), borderRadius: BorderRadius.circular(9999)),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SvgPicture.asset(
                    AppIcons.verified,
                    width: 16,
                    height: 16,
                    colorFilter: const ColorFilter.mode(Color(0xFF59FEAD), BlendMode.srcIn),
                  ),
                  const SizedBox(width: 8),
                  Text(profile.verificationTier, style: const TextStyle(fontSize: 16, color: Color(0xFF59FEAD))),
                ],
              ),
            ),
            ],
          ],
        ),
      ),
    );
  }
}
