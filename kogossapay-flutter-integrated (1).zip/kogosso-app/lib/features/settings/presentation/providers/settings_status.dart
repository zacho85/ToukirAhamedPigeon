enum SettingsStatus { initial, loading, loaded, error }
