import 'package:riverpod_annotation/riverpod_annotation.dart';

import 'package:kogosso_app/features/auth/presentation/providers/auth_provider.dart';

import 'package:kogosso_app/features/settings/data/data.dart';
import 'package:kogosso_app/features/settings/domain/domain.dart';

import 'settings_state.dart';

export 'settings_state.dart';

part 'settings_provider.g.dart';

@riverpod
class Settings extends _$Settings {
  GetSettingsData get _getSettingsData =>
      GetSettingsData(SettingsRepositoryImpl(SettingsRemoteDataSource(ref.read(kongossaApiProvider))));

  @override
  SettingsState build() => const SettingsState();

  Future<void> load() async {
    state = state.copyWith(status: SettingsStatus.loading);
    try {
      final data = await _getSettingsData();
      state = state.copyWith(
        status: SettingsStatus.loaded,
        profile: data.profile,
        menuItems: data.menuItems,
        appVersion: data.appVersion,
      );
    } catch (_) {
      state = state.copyWith(status: SettingsStatus.error);
    }
  }
}
