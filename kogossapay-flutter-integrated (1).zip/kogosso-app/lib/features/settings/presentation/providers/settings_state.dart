import 'package:kogosso_app/features/settings/domain/domain.dart';

import 'settings_status.dart';

export 'settings_status.dart';

class SettingsState {
  final SettingsStatus status;
  final UserProfileEntity? profile;
  final List<SettingsMenuItemEntity> menuItems;
  final String appVersion;

  const SettingsState({
    this.status = SettingsStatus.initial,
    this.profile,
    this.menuItems = const [],
    this.appVersion = '',
  });

  SettingsState copyWith({
    SettingsStatus? status,
    UserProfileEntity? profile,
    List<SettingsMenuItemEntity>? menuItems,
    String? appVersion,
  }) {
    return SettingsState(
      status: status ?? this.status,
      profile: profile ?? this.profile,
      menuItems: menuItems ?? this.menuItems,
      appVersion: appVersion ?? this.appVersion,
    );
  }
}
