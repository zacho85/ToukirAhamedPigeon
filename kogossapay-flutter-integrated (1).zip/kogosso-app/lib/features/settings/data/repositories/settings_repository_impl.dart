import 'package:kogosso_app/features/settings/domain/domain.dart';

import '../datasources/settings_local_datasource.dart';

class SettingsRepositoryImpl implements SettingsRepository {
  final SettingsLocalDataSource localDataSource;

  const SettingsRepositoryImpl(this.localDataSource);

  @override
  Future<UserProfileEntity> getUserProfile() => localDataSource.fetchUserProfile();

  @override
  Future<List<SettingsMenuItemEntity>> getMenuItems() => localDataSource.fetchMenuItems();

  @override
  Future<String> getAppVersion() => localDataSource.fetchAppVersion();
}