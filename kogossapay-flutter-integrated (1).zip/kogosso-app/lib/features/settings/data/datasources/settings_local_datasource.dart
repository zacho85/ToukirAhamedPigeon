import 'package:kogosso_app/features/settings/domain/domain.dart';

abstract class SettingsLocalDataSource {
  Future<UserProfileEntity> fetchUserProfile();

  Future<List<SettingsMenuItemEntity>> fetchMenuItems();

  Future<String> fetchAppVersion();
}

class SettingsLocalDataSourceImpl implements SettingsLocalDataSource {
  @override
  Future<UserProfileEntity> fetchUserProfile() async => const UserProfileEntity(
    name: 'Alex Kongossa',
    phoneNumber: '+237 670 000 000',
    verificationTier: 'Verified Tier 2',
    mainBalance: 450000,
    rewardsPoints: 2450,
  );

  @override
  Future<List<SettingsMenuItemEntity>> fetchMenuItems() async => const [
    SettingsMenuItemEntity(
      id: 'personal_info',
      title: 'Personal Info',
      subtitle: 'Name, email, and address',
      icon: SettingsMenuIcon.personalInfo,
    ),
    SettingsMenuItemEntity(
      id: 'security',
      title: 'Security',
      subtitle: 'Password, 2FA, Biometrics',
      icon: SettingsMenuIcon.security,
    ),
    SettingsMenuItemEntity(
      id: 'verification',
      title: 'Verification (KYC)',
      subtitle: 'Update identity documents',
      icon: SettingsMenuIcon.verification,
    ),
    SettingsMenuItemEntity(
      id: 'budget',
      title: 'Budget & Insights',
      subtitle: 'Spending limits, savings goals',
      icon: SettingsMenuIcon.budget,
    ),
    SettingsMenuItemEntity(
      id: 'subscription',
      title: 'Subscription Plan',
      subtitle: 'Manage or upgrade your plan',
      icon: SettingsMenuIcon.subscription,
    ),
  ];

  @override
  Future<String> fetchAppVersion() async => 'v2.4.1 stable build';
}