import 'package:kogosso_app/core/network/network.dart';
import 'package:kogosso_app/core/utils/formatters.dart';
import 'package:kogosso_app/features/settings/domain/domain.dart';

import 'settings_local_datasource.dart';

/// Profil réel via GET /auth/me. Le menu et la version restent ceux de l'app.
class SettingsRemoteDataSource implements SettingsLocalDataSource {
  SettingsRemoteDataSource(this._api, [SettingsLocalDataSource? menu]) : _menu = menu ?? SettingsLocalDataSourceImpl();
  final KongossaApi _api;
  final SettingsLocalDataSource _menu;

  /// L'API n'expose ni téléphone ni niveau KYC : on affiche l'email, et le
  /// niveau de vérification reste vide (masqué par l'écran).
  @override
  Future<UserProfileEntity> fetchUserProfile() async {
    final me = await _api.me();
    return UserProfileEntity(
      name: me['fullName'] as String? ?? '',
      phoneNumber: me['email'] as String? ?? '',
      verificationTier: '',
      mainBalance: parseNum(me['walletBalance']).toDouble(),
      rewardsPoints: parseNum(me['rewardsPoints']).toInt(),
    );
  }

  @override
  Future<List<SettingsMenuItemEntity>> fetchMenuItems() => _menu.fetchMenuItems();

  @override
  Future<String> fetchAppVersion() => _menu.fetchAppVersion();
}
